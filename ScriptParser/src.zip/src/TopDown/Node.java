package TopDown;

import java.util.ArrayList;

public class Node {
	
	public static String ATOM = "ATOM";
	public static String NODE = "NODE";
	public static String ROOT = "ROOT";
	public static String OPCODE = "OPCODE";
	
	private String descriptor = "NO_DESC";
	private String name = "NO_NAME";
	private String layer = "-1";
	private ArrayList<Node> nodes;
	
	public Node(String n, String desc, String l){
		name = n;
		descriptor = desc;
		layer = l;
	}
	public Node(String n, String desc){
		name = n;
		descriptor = desc;
		layer = "-1";
	}
	public void SetLayer(String l){
		layer = l;
	}
	public void AddNode(Node n){
		if (nodes == null)
			nodes = new ArrayList<Node>();
		nodes.add(n);
		
		// add atom leafs 
		//if (index == -1) {			
		//	matcher = cleanPattern.matcher(input.GetName());			
		//	if (matcher.find())
		//		input.AddNode(new Node(matcher.group(1), Node.NODE, Node.ATOM));
	}
	public String GetName(){
		return name;
	}
	public String GetDescriptor(){
		return descriptor;
	}
	public int GetSize(){
		if (nodes == null)
			return 0;
		return nodes.size();
	}
	public String GetLayer(){
		return layer;
	}
	public void PrintNode(String prepend){
		if (descriptor == OPCODE)
			return;
		StringBuilder builder = new StringBuilder(prepend + getPrintable(this));
		if (nodes != null) {
			builder.append(" = ");
			for(Node node : nodes){
				// descent
				node.PrintNode(prepend+"\t");
				builder.append(getPrintable(node));
			}
		}
		System.out.println(builder.toString());
	}
	private static String getPrintable(Node n) {
		StringBuilder builder = new StringBuilder("[" + n.GetDescriptor() + "|" + n.GetName());
		if (n.GetLayer() != "-1")
			builder.append("|" + n.GetLayer());

		builder.append("]");
		return builder.toString();
	}

}
