package Tests;

import ScriptGenerator.Generator;
import TopDown.Node;
import TopDown.TopDownParser;

//TODO:
// - needs a tokenizer, verify that alphabet matches and remove white spaces


public class Tester {
	
	public static void main(String[] args) {

		run2();
	}

	private static void run2() {
	
		// 2
		String input2 = "((ye~+yo~)yo~bla~!+A~B~C~!)@(d~e~f~!+i~j~k~!)@(l~m~n~!+o~p~q~!)@";
		//String input2 = "((ye~+yo~)yo~bla~!+A~B~C~!)E~E~E~!E~E~E~!@";

		// 1
		//String input1 = "yx:yx:yx:.";
		//String input1 = "yx~yx~(yy~+yz~)!";
		//String input1 = "yx~(yy~+yz~)yx~!";
		//String input1 = "yx~(yy~+yz~)(yy~+yz~)!";
		//String input1 = "(yy~+yz~)yx~yx~!";
		//String input1 = "(yy~+yz~)yx~(yy~+yz~)!";
		//String input1 = "(yy~+yz~)(yy~+yz~)yx~!";
		String input1 = "(yy:+yz:)(yy:+yz:)(yy:+yz:).";
		//String input1 = "(yy~+yz~)(yy~+yz~)(yy~+yz~)!+yx~yx~yx~!+(yy~+yz~)yx~(yy~+yz~)!";

		//0
		//String input0 = "yx:";
		String input0 = "yy:+yz:";
		
		String test = "*O:M:(U:+B:). + M:O:(A:+T:).**";
		
		try {
			
			String input = Generator.GetScript(4);
			
			//input = "*T:F:A:.O:A:O:.((F:+B:+E:+T:)U:E:.+(A:+B:)(E:+T:)O:.)-**"; //does not work with ?					
			//input = "*(A:I:B:.+E:B:O:.+E:M:(S:+S:+S:).)**"; //works with ?
			
			Node result = TopDownParser.Parse(input);
			result.PrintNode("");
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
