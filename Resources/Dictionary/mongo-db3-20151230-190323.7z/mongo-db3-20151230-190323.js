
/** terms indexes **/
db.getCollection("terms").ensureIndex({
  "_id": NumberInt(1)
},[
  
]);

/** terms indexes **/
db.getCollection("terms").ensureIndex({
  "IEML": 1,
  "FR": 1,
  "EN": 1
},{
  "unique": true
});

/** terms records **/
db.getCollection("terms").insert({
  "CANONICAL": [
    "beacbaaaa"
  ],
  "CLASS": "2",
  "EN": "assume one's personal identity",
  "FR": "assumer son identité personnelle",
  "IEML": "y.wu.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a576")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "beacfaaaa"
  ],
  "CLASS": "2",
  "EN": "learn",
  "FR": "apprendre",
  "IEML": "y.a.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a57d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ceacgaaaa"
  ],
  "CLASS": "2",
  "EN": "lend",
  "FR": "prêter",
  "IEML": "u.i.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a58a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfacaaaaa"
  ],
  "CLASS": "2",
  "EN": "excrete",
  "FR": "excréter",
  "IEML": "a.A:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5fc")
});
db.getCollection("terms").insert({
  "IEML": "j.O:S:.-",
  "FR": "cadre structurel abstrait",
  "EN": "abstract structural framework",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "ebadeaaaa"
  ],
  "_id": ObjectId("56830ef5b83eaf1ceef1fde3")
});
db.getCollection("terms").insert({
  "IEML": "j.O:T:.-",
  "FR": "cadre structurel concret",
  "EN": "concrete structural framework",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "ebadgaaaa"
  ],
  "_id": ObjectId("56830f3bb83eaf1ceef1fdea")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "adaghaaaa"
  ],
  "CLASS": "1",
  "EN": "low",
  "FR": "bas",
  "IEML": "E:O:.T:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dc6653c32453c0a58e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dhafeaaaa"
  ],
  "CLASS": "2",
  "EN": "undo society",
  "FR": "défaire la société",
  "IEML": "O:M:.k.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dc6653c32453c0a575")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ccacgaaaa"
  ],
  "CLASS": "2",
  "EN": "renew equipment",
  "FR": "renouveler l'équipement",
  "IEML": "we.i.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a594")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ceahhaaaa"
  ],
  "CLASS": "2",
  "EN": "destroy meaning",
  "FR": "détruire la signification",
  "IEML": "u.M:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("55d220dc6653c32453c0a5b0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cgabaaaaa"
  ],
  "CLASS": "2",
  "EN": "hit",
  "FR": "frapper",
  "IEML": "i.U:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5b7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cgaecaaaa"
  ],
  "CLASS": "2",
  "EN": "elaborate a statement",
  "FR": "élaborer une démarche",
  "IEML": "i.g.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5bc")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bfaceaaaa"
  ],
  "CLASS": "2",
  "EN": "campaign",
  "FR": "faire campagne",
  "IEML": "o.u.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5c1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bgafaaaaa"
  ],
  "CLASS": "2",
  "EN": "gather",
  "FR": "rassembler",
  "IEML": "e.B:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5d2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cgagcaaaa"
  ],
  "CLASS": "2",
  "EN": "work with matter",
  "FR": "travailler la matière",
  "IEML": "i.x.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5db")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bfageaaaa"
  ],
  "CLASS": "2",
  "EN": "lie",
  "FR": "mentir",
  "IEML": "o.d.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5f4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bbacbaaaa"
  ],
  "CLASS": "2",
  "EN": "get used",
  "FR": "s'habituer",
  "IEML": "wo.wu.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a618")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bfacaaaaa"
  ],
  "CLASS": "2",
  "EN": "send",
  "FR": "envoyer",
  "IEML": "o.A:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a640")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaaaaaaaeaacaaaaaaaaaaaaaabaagaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "pinkish white",
  "FR": "blanc rosé",
  "IEML": "b.-S:.A:.-'U:.T:.-',",
  "LAYER": "4",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("5679beb0b9fe1f5ab16a2c9f")
});
db.getCollection("terms").insert({
  "IEML": "h.O:B:.-",
  "FR": "cadre sémantique affectif",
  "EN": "affective semantic framework",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "fbadfaaaa"
  ],
  "_id": ObjectId("568310e5b83eaf1ceef1fe30")
});
db.getCollection("terms").insert({
  "IEML": "h.O:T:.-",
  "FR": "cadre sémantique concret",
  "EN": "concrete semantic framewo",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "fbadgaaaa"
  ],
  "_id": ObjectId("56831109b83eaf1ceef1fe37")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cbagaaaaa"
  ],
  "CLASS": "2",
  "EN": "recognize forms of movement | of manipulation",
  "FR": "reconnaître des formes de mouvements | de manipulations",
  "IEML": "wu.T:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6f7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfabbaaaa"
  ],
  "CLASS": "2",
  "EN": "create a scientific | artistic work",
  "FR": "créer une œuvre scientifique | artistique",
  "IEML": "a.wo.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7ac")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bbafaaaaa"
  ],
  "CLASS": "2",
  "EN": "create a taste | a smell, cook | brew, lead chemical processes",
  "FR": "créer un goût | une odeur, cuisiner | brasser, mener des processus chimiques",
  "IEML": "wo.B:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8d8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ahafdaaaa"
  ],
  "CLASS": "1",
  "EN": "systemic cause",
  "FR": "cause systémique",
  "IEML": "E:M:.B:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dd6653c32453c0a905")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bfafbaaaa"
  ],
  "CLASS": "2",
  "EN": "choose an interpretation",
  "FR": "choisir une interprétation",
  "IEML": "o.h.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a567")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ceaiaaaaa"
  ],
  "CLASS": "2",
  "EN": "move oneself",
  "FR": "se déplacer",
  "IEML": "u.F:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "5",
  "_id": ObjectId("55d220dc6653c32453c0a5e7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bgaeeaaaa"
  ],
  "CLASS": "2",
  "EN": "neglect codes",
  "FR": "négliger les codes",
  "IEML": "e.s.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a659")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ddaddaaaa"
  ],
  "CLASS": "2",
  "EN": "live",
  "FR": "vivre",
  "IEML": "O:O:.O:O:.-",
  "LAYER": "2",
  "PARADIGM": "1",
  "TAILLE": "16",
  "_id": ObjectId("55d220dc6653c32453c0a66a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bfagbaaaa"
  ],
  "CLASS": "2",
  "EN": "choose a subject",
  "FR": "choisir un sujet",
  "IEML": "o.p.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a671")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfabfaaaa"
  ],
  "CLASS": "2",
  "EN": "follow",
  "FR": "suivre",
  "IEML": "a.o.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a678")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ccaccaaaa"
  ],
  "CLASS": "2",
  "EN": "die",
  "FR": "mourir",
  "IEML": "we.we.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a685")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dhadhaaaa"
  ],
  "CLASS": "2",
  "EN": "perform",
  "FR": "performer",
  "IEML": "O:M:.O:M:.-",
  "LAYER": "2",
  "PARADIGM": "1",
  "TAILLE": "36",
  "_id": ObjectId("55d220dc6653c32453c0a68c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ddabbaaaa"
  ],
  "CLASS": "2",
  "EN": "sprout",
  "FR": "germer",
  "IEML": "O:O:.wo.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220dc6653c32453c0a693")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "beabgaaaa"
  ],
  "CLASS": "2",
  "EN": "analyze",
  "FR": "analyser",
  "IEML": "y.e.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a727")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bcacgaaaa"
  ],
  "CLASS": "2",
  "EN": "use equipment",
  "FR": "utiliser l'équipement",
  "IEML": "wa.i.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6dd")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cgaegaaaa"
  ],
  "CLASS": "2",
  "EN": "break | smash",
  "FR": "briser | fracasser",
  "IEML": "i.t.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a77e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bfabeaaaa"
  ],
  "CLASS": "2",
  "EN": "choose",
  "FR": "choisir",
  "IEML": "o.y.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a76c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfagaaaaa"
  ],
  "CLASS": "2",
  "EN": "eat",
  "FR": "manger",
  "IEML": "a.T:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a79f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bbaegaaaa"
  ],
  "CLASS": "2",
  "EN": "remember",
  "FR": "se remémorer",
  "IEML": "wo.t.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7bf")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ceabeaaaa"
  ],
  "CLASS": "2",
  "EN": "respond",
  "FR": "répondre",
  "IEML": "u.y.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7cd")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cgagfaaaa"
  ],
  "CLASS": "2",
  "EN": "be sick | injured",
  "FR": "être malade | blessé",
  "IEML": "i.f.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7d1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bgacaaaaa"
  ],
  "CLASS": "2",
  "EN": "push",
  "FR": "pousser",
  "IEML": "e.A:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7d6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ceaggaaaa"
  ],
  "CLASS": "2",
  "EN": "soil",
  "FR": "salir",
  "IEML": "u.l.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7f7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfabgaaaa"
  ],
  "CLASS": "2",
  "EN": "offer | supply",
  "FR": "offrir | fournir",
  "IEML": "a.e.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7f9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dhabeaaaa"
  ],
  "CLASS": "2",
  "EN": "into knowledge (perform)",
  "FR": "dans le savoir (performer)",
  "IEML": "O:M:.y.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dd6653c32453c0a81b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bgaeaaaaa"
  ],
  "CLASS": "2",
  "EN": "disperse",
  "FR": "disperser",
  "IEML": "e.S:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a834")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfafaaaaa"
  ],
  "CLASS": "2",
  "EN": "drink",
  "FR": "boire",
  "IEML": "a.B:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a848")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cbageaaaa"
  ],
  "CLASS": "2",
  "EN": "observe",
  "FR": "observer",
  "IEML": "wu.d.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a977")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cgafaaaaa"
  ],
  "CLASS": "2",
  "EN": "jump",
  "FR": "sauter",
  "IEML": "i.B:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a97c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaaaaaaaeaacaaaaaaaaaaaaaabaaiaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "white",
  "FR": "blanc",
  "IEML": "b.-S:.A:.-'U:.F:.-',",
  "LAYER": "4",
  "PARADIGM": "0",
  "TAILLE": "5",
  "_id": ObjectId("5679bb2bb9fe1f5ab16a2c2f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaaaaaaaeaacaaaaaaaaaaaaaacaaiaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "black",
  "FR": "noir",
  "IEML": "b.-S:.A:.-'A:.F:.-',",
  "LAYER": "4",
  "PARADIGM": "0",
  "TAILLE": "5",
  "_id": ObjectId("5679bb3db9fe1f5ab16a2c36")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaaaaaaaeaacaaaaaaaaaaaaaaeaaiaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "blue",
  "FR": "bleu",
  "IEML": "b.-S:.A:.-'S:.F:.-',",
  "LAYER": "4",
  "PARADIGM": "0",
  "TAILLE": "5",
  "_id": ObjectId("5679bb51b9fe1f5ab16a2c3d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaaaaaaaeaacaaaaaaaaaaaaaafaaiaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "yellow",
  "FR": "jaune",
  "IEML": "b.-S:.A:.-'B:.F:.-',",
  "LAYER": "4",
  "PARADIGM": "0",
  "TAILLE": "5",
  "_id": ObjectId("5679bb64b9fe1f5ab16a2c44")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaaaaaaaeaacaaaaaaaaaaaaaagaaiaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "red",
  "FR": "rouge",
  "IEML": "b.-S:.A:.-'T:.F:.-',",
  "LAYER": "4",
  "PARADIGM": "0",
  "TAILLE": "5",
  "_id": ObjectId("5679bb72b9fe1f5ab16a2c4b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeaaaaaaagcaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "programming tool",
  "FR": "outil de programmation",
  "IEML": "s.-x.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("56806405b83eaf1ceef1fc62")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfaaaaaaagcaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "sensor network",
  "FR": "réseau de capteurs",
  "IEML": "f.-x.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("56806bfbb83eaf1ceef1fc93")
});
db.getCollection("terms").insert({
  "IEML": "j.U:O:.-",
  "FR": "changement virtuel de langage",
  "EN": "virtual language change",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "ebabdaaaa"
  ],
  "_id": ObjectId("5681b7c2b83eaf1ceef1fca1")
});
db.getCollection("terms").insert({
  "IEML": "p.U:O:.-",
  "FR": "changement d'objet virtuel",
  "EN": "virtual object change",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "gbabdaaaa"
  ],
  "_id": ObjectId("5681be71b83eaf1ceef1fd11")
});
db.getCollection("terms").insert({
  "IEML": "p.A:O:.-",
  "FR": "changement d'objet actuel",
  "EN": "actual object change",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "gbacdaaaa"
  ],
  "_id": ObjectId("5681be8fb83eaf1ceef1fd18")
});
db.getCollection("terms").insert({
  "IEML": "j.U:M:.-",
  "FR": "cadre structurel virtuel",
  "EN": "virtual structural framwork",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "3",
  "CANONICAL": [
    "ebabhaaaa"
  ],
  "_id": ObjectId("56830e8cb83eaf1ceef1fdd5")
});
db.getCollection("terms").insert({
  "IEML": "j.A:M:.-",
  "FR": "cadre structurel actuel",
  "EN": "actual structural framework",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "3",
  "CANONICAL": [
    "ebachaaaa"
  ],
  "_id": ObjectId("56830eabb83eaf1ceef1fddc")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bcacaaaaa"
  ],
  "CLASS": "2",
  "EN": "display a signature | track | footprint",
  "FR": "exhiber une signature | une trace | une empreinte",
  "IEML": "wa.A:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab92")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ccafaaaaa"
  ],
  "CLASS": "2",
  "EN": "chemically insulate",
  "FR": "isoler chimiquement",
  "IEML": "we.B:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0acb3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ahagdaaaa"
  ],
  "CLASS": "1",
  "EN": "existential cause",
  "FR": "cause existentielle",
  "IEML": "E:M:.T:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220df6653c32453c0acd3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeaaaaaaadaadaaaaahaadaaaaa"
  ],
  "CLASS": "4",
  "EN": "noetic levels and functions",
  "FR": "niveaux et fonctions noétiques",
  "ID": null,
  "IEML": "s.-O:.O:.-M:.O:.-'",
  "LAYER": "3",
  "PARADIGM": "1",
  "TAILLE": "24",
  "_id": ObjectId("55d220dc6653c32453c0a5b1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aaf"
  ],
  "CLASS": "1",
  "EN": "dative | beneficiary | to",
  "FR": "datif | bénéficiaire | à",
  "ID": null,
  "IEML": "E:E:B:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8bd")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eea"
  ],
  "CLASS": "4",
  "EN": "thought",
  "FR": "pensée",
  "ID": null,
  "IEML": "s.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("563295f30cbbc66ed7c31571")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhaceaaaa"
  ],
  "CLASS": "4",
  "EN": "making sense",
  "FR": "faire sens",
  "ID": null,
  "IEML": "M:M:.u.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("55d220df6653c32453c0ace6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "agaecaaaa"
  ],
  "CLASS": "1",
  "EN": "matter | material",
  "FR": "matière | matériau",
  "ID": null,
  "IEML": "E:T:.g.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a76b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffabgaaaa"
  ],
  "CLASS": "4",
  "EN": "negotiation ability",
  "FR": "capacité de négocier",
  "ID": null,
  "IEML": "m.e.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad38")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hbaebaaaa"
  ],
  "CLASS": "4",
  "EN": "test m",
  "FR": "test andre",
  "ID": null,
  "IEML": "M:U:.j.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("56367515e7dd3f2df538dfad")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hcaebaaaa"
  ],
  "CLASS": "4",
  "EN": "test maj",
  "FR": "test maj",
  "IEML": "M:A:.j.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("5636752ae7dd3f2df538dfae")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "edaebaaaa"
  ],
  "CLASS": "4",
  "EN": "Are you crazy? test",
  "FR": "Es-tu fou? test",
  "IEML": "S:O:.j.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("563675d3e7dd3f2df538dfaf")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "heabgaaaa"
  ],
  "CLASS": "4",
  "EN": "grammar of know how",
  "FR": "grammaire des savoir faire",
  "IEML": "M:S:.e.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("56367b68e7dd3f2df538dfb0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hfabgaaaa"
  ],
  "CLASS": "4",
  "EN": "dialectic of know how",
  "FR": "dialectique des savoir faire",
  "IEML": "M:B:.e.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("56367bc1e7dd3f2df538dfb1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hgabgaaaa"
  ],
  "CLASS": "4",
  "EN": "rhetorics of know how",
  "FR": "rhétorique des savoir faire",
  "ID": null,
  "IEML": "M:T:.e.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("56367bece7dd3f2df538dfb2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "d"
  ],
  "CLASS": "2",
  "EN": "process | grammatical \"verbishness\" | bi-polarity | (U:+A:)",
  "FR": "processus | \"verbalité\" grammaticale | bi-polarité | (U:+A:)",
  "ID": null,
  "IEML": "O:",
  "LAYER": "0",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("55d220de6653c32453c0aaeb")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "h"
  ],
  "CLASS": "4",
  "EN": "structure | grammatical \"nounishness\" | ternarity (S:+B:+T:)",
  "FR": "structure | \"nominalité\" grammaticale | ternarité | (S:+B:+T:)",
  "ID": null,
  "IEML": "M:",
  "LAYER": "0",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("55d220de6653c32453c0aac4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "afb"
  ],
  "CLASS": "1",
  "EN": "probability",
  "FR": "probabilité",
  "IEML": "E:B:U:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("5637bee7a10af9558a63ea83")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "agd"
  ],
  "CLASS": "1",
  "EN": "conclusion | then | therefore",
  "FR": "conclusion | alors | donc",
  "ID": null,
  "IEML": "E:T:O:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("55d220de6653c32453c0aafb")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "acc"
  ],
  "CLASS": "1",
  "EN": "affirmative construction",
  "FR": "construction affirmative",
  "ID": null,
  "IEML": "E:A:A:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a885")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "abb"
  ],
  "CLASS": "1",
  "EN": "interrogative construction",
  "FR": "construction interrogative",
  "ID": null,
  "IEML": "E:U:U:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0a9c7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "abc"
  ],
  "CLASS": "1",
  "EN": "negative construction",
  "FR": "construction négative",
  "ID": null,
  "IEML": "E:U:A:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("5637c08fa10af9558a63ea85")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aac"
  ],
  "CLASS": "1",
  "EN": "genitive | of",
  "FR": "génitif | de",
  "ID": null,
  "IEML": "E:E:A:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a777")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ahh"
  ],
  "CLASS": "1",
  "EN": "distribution (adverbs of)",
  "FR": "distribution (adverbes de)",
  "ID": null,
  "IEML": "E:M:M:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("55d220df6653c32453c0acca")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "adh"
  ],
  "CLASS": "1",
  "EN": "variation (adverbs of)",
  "FR": "variation (adverbes de)",
  "ID": null,
  "IEML": "E:O:M:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220de6653c32453c0ab39")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bea"
  ],
  "CLASS": "2",
  "EN": "know",
  "FR": "savoir",
  "ID": null,
  "IEML": "y.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0adc1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bfa"
  ],
  "CLASS": "2",
  "EN": "want",
  "FR": "vouloir",
  "ID": null,
  "IEML": "o.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0acfe")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bga"
  ],
  "CLASS": "2",
  "EN": "be able",
  "FR": "pouvoir",
  "ID": null,
  "IEML": "e.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac4d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cga"
  ],
  "CLASS": "2",
  "EN": "do",
  "FR": "faire",
  "ID": null,
  "IEML": "i.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac8f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfa"
  ],
  "CLASS": "2",
  "EN": "be commited",
  "FR": "s'engager",
  "ID": null,
  "IEML": "a.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ac07")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cea"
  ],
  "CLASS": "2",
  "EN": "state",
  "FR": "énoncer",
  "ID": null,
  "IEML": "u.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad6e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dha"
  ],
  "CLASS": "2",
  "EN": "act",
  "FR": "agir",
  "ID": null,
  "IEML": "O:M:.",
  "LAYER": "1",
  "PARADIGM": "1",
  "TAILLE": "6",
  "_id": ObjectId("55d220dc6653c32453c0a6f6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bha"
  ],
  "CLASS": "2",
  "EN": "act virtually",
  "FR": "agir virtuellement",
  "ID": null,
  "IEML": "U:M:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("55d220dd6653c32453c0a958")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cha"
  ],
  "CLASS": "2",
  "EN": "act actually",
  "FR": "agir actuellement",
  "ID": null,
  "IEML": "A:M:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("55d220df6653c32453c0ad54")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dfa"
  ],
  "CLASS": "2",
  "EN": "act according to being",
  "FR": "agir selon l'être",
  "ID": null,
  "IEML": "O:B:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("55d220de6653c32453c0aa91")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dga"
  ],
  "CLASS": "2",
  "EN": "act according to thing",
  "FR": "agir selon la chose",
  "ID": null,
  "IEML": "O:T:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("55d220dd6653c32453c0a7ec")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dda"
  ],
  "CLASS": "2",
  "EN": "generate",
  "FR": "générer",
  "ID": null,
  "IEML": "O:O:.",
  "LAYER": "1",
  "PARADIGM": "1",
  "TAILLE": "4",
  "_id": ObjectId("55d220de6653c32453c0ab42")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dba"
  ],
  "CLASS": "2",
  "EN": "generate toward the virtual",
  "FR": "générer vers le virtuel",
  "ID": null,
  "IEML": "O:U:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("55d220dc6653c32453c0a5da")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cda"
  ],
  "CLASS": "2",
  "EN": "generate from the actual",
  "FR": "générer à  partir de l'actuel",
  "ID": null,
  "IEML": "A:O:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("55d220dd6653c32453c0a8fd")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bba"
  ],
  "CLASS": "2",
  "EN": "generate possibilities",
  "FR": "générer des possibilités",
  "ID": null,
  "IEML": "wo.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac3f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bca"
  ],
  "CLASS": "2",
  "EN": "operate",
  "FR": "opérer",
  "ID": null,
  "IEML": "wa.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab62")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cca"
  ],
  "CLASS": "2",
  "EN": "generate feed-back",
  "FR": "générer de la rétroaction",
  "ID": null,
  "IEML": "we.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aba1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cba"
  ],
  "CLASS": "2",
  "EN": "perceive",
  "FR": "percevoir",
  "ID": null,
  "IEML": "wu.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0acb1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dca"
  ],
  "CLASS": "2",
  "EN": "generate toward the actual",
  "FR": "générer vers l'actuel",
  "ID": null,
  "IEML": "O:A:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("5637c534a10af9558a63ea86")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "j"
  ],
  "CLASS": "7",
  "EN": "information in general | (E:+F:) | (E:+O:+M:) | (E:+U:+A:+S:+B:+T:)",
  "FR": "information en général | (E:+F:) | (E:+O:+M:) | (E:+U:+A:+S:+B:+T:)",
  "ID": null,
  "IEML": "I:",
  "LAYER": "0",
  "PARADIGM": "1",
  "TAILLE": "6",
  "_id": ObjectId("55d220de6653c32453c0aa69")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "i"
  ],
  "CLASS": "6",
  "EN": "fullness | non-fiction | (O:+M:) | (U:+A:+S:+B:+T:)",
  "FR": "plénitude | non-fiction | (O:+M:) | (U:+A:+S:+B:+T:)",
  "ID": null,
  "IEML": "F:",
  "LAYER": "0",
  "PARADIGM": "0",
  "TAILLE": "5",
  "_id": ObjectId("55d220de6653c32453c0aa33")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bhe"
  ],
  "CLASS": "2",
  "EN": "grow the abstract virtual development",
  "FR": "cultiver le développement virtuel abstrait",
  "ID": null,
  "IEML": "U:M:S:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("5637ecd5a10af9558a63ea8b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dhh"
  ],
  "CLASS": "2",
  "EN": "grow collective intelligence in the service of human development",
  "FR": "cultiver l'intelligence collective au service du développement humain",
  "ID": null,
  "IEML": "O:M:M:.",
  "LAYER": "1",
  "PARADIGM": "1",
  "TAILLE": "18",
  "_id": ObjectId("5637ea6aa10af9558a63ea87")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "che"
  ],
  "CLASS": "2",
  "EN": "grow the abstract actual development",
  "FR": "cultiver le développement actuel abstrait",
  "ID": null,
  "IEML": "A:M:S:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("5637ed98a10af9558a63ea8c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bfe"
  ],
  "CLASS": "2",
  "EN": "maintain and refine the governance",
  "FR": "maintenir et raffiner la gouvernance",
  "ID": null,
  "IEML": "U:B:S:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("5637ef1ea10af9558a63ea8e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfe"
  ],
  "CLASS": "2",
  "EN": "play and develop social roles",
  "FR": "jouer et développer des rôles sociaux",
  "ID": null,
  "IEML": "A:B:S:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("5637f5bea10af9558a63ea91")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bhf"
  ],
  "CLASS": "2",
  "EN": "grow the affective virtual development",
  "FR": "cultiver le développement virtuel affectif",
  "ID": null,
  "IEML": "U:M:B:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("5637f87da10af9558a63ea93")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "chf"
  ],
  "CLASS": "2",
  "EN": "grow the affective actual development",
  "FR": "cultiver le développement actuel affectif",
  "ID": null,
  "IEML": "A:M:B:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("5637f8c3a10af9558a63ea94")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bff"
  ],
  "CLASS": "2",
  "EN": "maintain and refine values",
  "FR": "maintenir et raffiner les valeurs",
  "ID": null,
  "IEML": "U:B:B:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("563a52a0c67975d385e78a8b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bef"
  ],
  "CLASS": "2",
  "EN": "study and practice arts",
  "FR": "étudier et pratiquer les arts",
  "ID": null,
  "IEML": "U:S:B:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("563a51eec67975d385e78a8a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bgf"
  ],
  "CLASS": "2",
  "EN": "maintain and strengthen morale",
  "FR": "maintenir et renforcer le moral",
  "ID": null,
  "IEML": "U:T:B:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("563a5347c67975d385e78a8c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cef"
  ],
  "CLASS": "2",
  "EN": "study and practice communication",
  "FR": "étudier et pratiquer la communication",
  "ID": null,
  "IEML": "A:S:B:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("563a53c2c67975d385e78a8d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cff"
  ],
  "CLASS": "2",
  "EN": "maintain and develop trust",
  "FR": "maintenir et développer la confiance",
  "ID": null,
  "IEML": "A:B:B:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("563a5445c67975d385e78a8e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cgf"
  ],
  "CLASS": "2",
  "EN": "maintain and improve health",
  "FR": "maintenir et améliorer la santé",
  "ID": null,
  "IEML": "A:T:B:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("563a548bc67975d385e78a8f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cge"
  ],
  "CLASS": "2",
  "EN": "maintain and develop technology",
  "FR": "maintenir et développer les techniques",
  "ID": null,
  "IEML": "A:T:S:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("5637f610a10af9558a63ea92")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bge"
  ],
  "CLASS": "2",
  "EN": "maintain and develop skills",
  "FR": "maintenir et développer les compétences",
  "ID": null,
  "IEML": "U:T:S:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("5637efa2a10af9558a63ea8f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bee"
  ],
  "CLASS": "2",
  "EN": "study and practice sciences",
  "FR": "étudier et pratiquer les sciences",
  "ID": null,
  "IEML": "U:S:S:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("5637ee5fa10af9558a63ea8d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cee"
  ],
  "CLASS": "2",
  "EN": "study and practice content creation",
  "FR": "étudier et pratiquer la création de contenu",
  "ID": null,
  "IEML": "A:S:S:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("5637f3baa10af9558a63ea90")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "beg"
  ],
  "CLASS": "2",
  "EN": "study and practice wisdoms",
  "FR": "étudier et pratiquer les sagesses",
  "ID": null,
  "IEML": "U:S:T:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("563a56c2deaa98969abb437a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ceg"
  ],
  "CLASS": "2",
  "EN": "master and develop media",
  "FR": "maîtriser et développer les médias",
  "IEML": "A:S:T:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("563a5703deaa98969abb437b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bhg"
  ],
  "CLASS": "2",
  "EN": "grow the concrete virtual development",
  "FR": "cultiver le développement virtuel concret",
  "ID": null,
  "IEML": "U:M:T:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("563a57a9deaa98969abb437f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "chg"
  ],
  "CLASS": "2",
  "EN": "grow the concrete actual development",
  "FR": "cultiver le développement actuel concret",
  "ID": null,
  "IEML": "A:M:T:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("563a57ccdeaa98969abb4380")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bfg"
  ],
  "CLASS": "2",
  "EN": "maintain and refine rights and obligations",
  "FR": "respecter et raffiner droits et obligations",
  "ID": null,
  "IEML": "U:B:T:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("563a5879deaa98969abb4381")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bgg"
  ],
  "CLASS": "2",
  "EN": "gather and use resources",
  "FR": "réunir et utiliser des ressources",
  "IEML": "U:T:T:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("563a58a5deaa98969abb4382")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfg"
  ],
  "CLASS": "2",
  "EN": "maintain and develop social connections",
  "FR": "maintenir et développer les connexions sociales",
  "ID": null,
  "IEML": "A:B:T:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("563a58eedeaa98969abb4383")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cgg"
  ],
  "CLASS": "2",
  "EN": "maintain and develop the bio-physical environment",
  "FR": "maintenir et développer l'environnement bio-physique",
  "IEML": "A:T:T:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("563a5940deaa98969abb4384")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bhh"
  ],
  "CLASS": "2",
  "EN": "grow the virtual human development",
  "FR": "cultiver le développement humain virtuel",
  "ID": null,
  "IEML": "U:M:M:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("563a6ae9deaa98969abb4385")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "chh"
  ],
  "CLASS": "2",
  "EN": "grow the actual human development",
  "FR": "cultiver le développement humain actuel",
  "ID": null,
  "IEML": "A:M:M:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("563a6b18deaa98969abb4386")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "deh"
  ],
  "CLASS": "2",
  "EN": "grow the formal collective intelligence",
  "FR": "cultiver l'intelligence collective formelle",
  "ID": null,
  "IEML": "O:S:M:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("563a6bc7deaa98969abb4387")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bfh"
  ],
  "CLASS": "2",
  "EN": "grow ethics",
  "FR": "cultiver l'éthique",
  "ID": null,
  "IEML": "U:B:M:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("563a6cd0bc3a93f0684d94a7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfh"
  ],
  "CLASS": "2",
  "EN": "grow people | society",
  "FR": "cultiver les personnes | la société",
  "ID": null,
  "IEML": "A:B:M:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("563a6cfdbc3a93f0684d94a8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dgh"
  ],
  "CLASS": "2",
  "EN": "grow the practical collective intelligence",
  "FR": "cultiver l'intelligence collective pratique",
  "ID": null,
  "IEML": "O:T:M:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("563a6e20bc3a93f0684d94a9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bgh"
  ],
  "CLASS": "2",
  "EN": "grow empowerment",
  "FR": "cultiver la puissance",
  "ID": null,
  "IEML": "U:T:M:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("563a6e99bc3a93f0684d94aa")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dff"
  ],
  "CLASS": "2",
  "EN": "grow the affective emotional collective intelligence",
  "FR": "cultiver l'intelligence collective émotionnelle affective",
  "ID": null,
  "IEML": "O:B:B:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("563a5116c67975d385e78a88")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dfh"
  ],
  "CLASS": "2",
  "EN": "grow the emotional collective intelligence",
  "FR": "cultiver l'intelligence collective émotionnelle",
  "ID": null,
  "IEML": "O:B:M:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("563a6c0edeaa98969abb4388")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dfe"
  ],
  "CLASS": "2",
  "EN": "grow the abstract emotional collective intelligence",
  "FR": "cultiver l'intelligence collective émotionnelle abstraite",
  "ID": null,
  "IEML": "O:B:S:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("5637eb1da10af9558a63ea89")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "beh"
  ],
  "CLASS": "2",
  "EN": "grow knowledge",
  "FR": "cultiver la connaissance",
  "ID": null,
  "IEML": "U:S:M:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("563a7280bc3a93f0684d94ac")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ceh"
  ],
  "CLASS": "2",
  "EN": "grow messages",
  "FR": "cultiver les messages",
  "ID": null,
  "IEML": "A:S:M:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("563a72aabc3a93f0684d94ad")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dge"
  ],
  "CLASS": "2",
  "EN": "grow the abstract practical collective intelligence",
  "FR": "cultiver l'intelligence collective pratique abstraite",
  "ID": null,
  "IEML": "O:T:S:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("5637eb5ba10af9558a63ea8a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dgf"
  ],
  "CLASS": "2",
  "EN": "grow the affective practical collective intelligence",
  "FR": "cultiver l'intelligence collective pratique affective",
  "ID": null,
  "IEML": "O:T:B:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("563a51afc67975d385e78a89")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cgh"
  ],
  "CLASS": "2",
  "EN": "grow equipment",
  "FR": "cultiver l'équipement",
  "ID": null,
  "IEML": "A:T:M:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("563a6ebdbc3a93f0684d94ab")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dgg"
  ],
  "CLASS": "2",
  "EN": "grow the concrete practical collective intelligence",
  "FR": "cultiver l'intelligence collective pratique concrète",
  "ID": null,
  "IEML": "O:T:T:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("563a5778deaa98969abb437e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dee"
  ],
  "CLASS": "2",
  "EN": "grow the abstract formal collective intelligence",
  "FR": "cultiver l'intelligence collective formelle abstraite",
  "ID": null,
  "IEML": "O:S:S:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("5637eaf9a10af9558a63ea88")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "def"
  ],
  "CLASS": "2",
  "EN": "grow the affective formal collective intelligence",
  "FR": "cultiver l'intelligence collective formelle affective",
  "ID": null,
  "IEML": "O:S:B:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("563a50e4c67975d385e78a87")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dfg"
  ],
  "CLASS": "2",
  "EN": "grow the concrete emotional collective inteligence",
  "FR": "cultiver l'intelligence collective émotionnelle concrète",
  "ID": null,
  "IEML": "O:B:T:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("563a5755deaa98969abb437d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "deg"
  ],
  "CLASS": "2",
  "EN": "grow the concrete formal collective intelligence",
  "FR": "cultiver l'intelligence collective formelle concrète",
  "ID": null,
  "IEML": "O:S:T:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("563a5734deaa98969abb437c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hha"
  ],
  "CLASS": "4",
  "EN": "becomings",
  "FR": "devenirs",
  "ID": null,
  "IEML": "M:M:.",
  "LAYER": "1",
  "PARADIGM": "1",
  "TAILLE": "9",
  "_id": ObjectId("55d220dc6653c32453c0a76d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efa"
  ],
  "CLASS": "4",
  "EN": "language",
  "FR": "langage",
  "IEML": "b.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("563a7f2dbc3a93f0684d94ae")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ega"
  ],
  "CLASS": "4",
  "EN": "memory",
  "FR": "mémoire",
  "IEML": "t.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("563a7f3dbc3a93f0684d94af")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fea"
  ],
  "CLASS": "4",
  "EN": "society",
  "FR": "société",
  "IEML": "k.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("563a7f55bc3a93f0684d94b0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffa"
  ],
  "CLASS": "4",
  "EN": "affect",
  "FR": "affect",
  "IEML": "m.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("563a7f64bc3a93f0684d94b1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fga"
  ],
  "CLASS": "4",
  "EN": "world",
  "FR": "monde",
  "IEML": "n.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("563a7f72bc3a93f0684d94b2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gea"
  ],
  "CLASS": "4",
  "EN": "truth",
  "FR": "vérité",
  "IEML": "d.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("563a7f81bc3a93f0684d94b3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfa"
  ],
  "CLASS": "4",
  "EN": "life",
  "FR": "vie",
  "IEML": "f.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("563a7fabbc3a93f0684d94b4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gga"
  ],
  "CLASS": "4",
  "EN": "space",
  "FR": "espace",
  "IEML": "l.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("563a7fbbbc3a93f0684d94b5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eha"
  ],
  "CLASS": "4",
  "EN": "becoming of the sign",
  "FR": "devenir du signe",
  "ID": null,
  "IEML": "S:M:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("55d220dc6653c32453c0a570")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fha"
  ],
  "CLASS": "4",
  "EN": "becoming of the being",
  "FR": "devenir de l'être",
  "ID": null,
  "IEML": "B:M:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("55d220dd6653c32453c0a902")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gha"
  ],
  "CLASS": "4",
  "EN": "becoming of the thing",
  "FR": "devenir de la chose",
  "ID": null,
  "IEML": "T:M:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("55d220de6653c32453c0aa2a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hea"
  ],
  "CLASS": "4",
  "EN": "becoming sign",
  "FR": "devenir signe",
  "IEML": "M:S:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("563a8053bc3a93f0684d94b6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hfa"
  ],
  "CLASS": "4",
  "EN": "becoming being",
  "FR": "devenir être",
  "IEML": "M:B:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("563a806abc3a93f0684d94b7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hga"
  ],
  "CLASS": "4",
  "EN": "becoming thing",
  "FR": "devenir chose",
  "IEML": "M:T:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("563a8085bc3a93f0684d94b8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hda"
  ],
  "CLASS": "4",
  "EN": "mutations",
  "FR": "mutations",
  "ID": null,
  "IEML": "M:O:.",
  "LAYER": "1",
  "PARADIGM": "1",
  "TAILLE": "6",
  "_id": ObjectId("563a8102bc3a93f0684d94b9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dea"
  ],
  "CLASS": "2",
  "EN": "act according to sign",
  "FR": "agir selon le signe",
  "IEML": "O:S:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("563a81cebc3a93f0684d94ba")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aad"
  ],
  "CLASS": "1",
  "EN": "case indicators for noun clauses",
  "FR": "indicateurs de cas pour clauses nominales",
  "ID": null,
  "IEML": "E:E:O:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("55d220dd6653c32453c0a96d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aah"
  ],
  "CLASS": "1",
  "EN": "case indicators for verb clauses",
  "FR": "indicateurs de cas pour clauses verbales",
  "ID": null,
  "IEML": "E:E:M:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("55d220dc6653c32453c0a5e2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aai"
  ],
  "CLASS": "1",
  "EN": "case indicators",
  "FR": "indicateur de cas",
  "IEML": "E:E:F:.",
  "LAYER": "1",
  "PARADIGM": "1",
  "TAILLE": "5",
  "_id": ObjectId("563a8323bc3a93f0684d94bb")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "acb"
  ],
  "CLASS": "1",
  "EN": "construction between quotation marks",
  "FR": "construction entre guillemets",
  "ID": null,
  "IEML": "E:A:U:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("5637c045a10af9558a63ea84")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "add"
  ],
  "CLASS": "1",
  "EN": "logical construction",
  "FR": "construction logique",
  "ID": null,
  "IEML": "E:O:O:.",
  "LAYER": "1",
  "PARADIGM": "1",
  "TAILLE": "4",
  "_id": ObjectId("55d220dc6653c32453c0a771")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "agb"
  ],
  "CLASS": "1",
  "EN": "by logical necessity | by deduction",
  "FR": "par nécessité logique | par déduction",
  "ID": null,
  "IEML": "E:T:U:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae0f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aed"
  ],
  "CLASS": "1",
  "EN": "hypothetic construction | if",
  "FR": "construction hypothétique | si",
  "ID": null,
  "IEML": "E:S:O:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("55d220dc6653c32453c0a5f1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ahd"
  ],
  "CLASS": "1",
  "EN": "inference mode",
  "FR": "mode d'inférence",
  "ID": null,
  "IEML": "E:M:O:.",
  "LAYER": "1",
  "PARADIGM": "1",
  "TAILLE": "6",
  "_id": ObjectId("55d220dc6653c32453c0a702")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ahahhaaaa"
  ],
  "CLASS": "1",
  "EN": "situation: tracking",
  "FR": "situation: cheminement",
  "ID": null,
  "IEML": "E:M:.M:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "27",
  "_id": ObjectId("55d220df6653c32453c0ad72")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aiaddaaaa"
  ],
  "CLASS": "1",
  "EN": "pronoun | who",
  "FR": "pronom | qui",
  "ID": null,
  "IEML": "E:F:.O:O:.-",
  "LAYER": "2",
  "PARADIGM": "1",
  "TAILLE": "20",
  "_id": ObjectId("55d220dd6653c32453c0a93e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "adahhaaaa"
  ],
  "CLASS": "1",
  "EN": "place: axial orientation",
  "FR": "lieu: orientation axiale",
  "ID": null,
  "IEML": "E:O:.M:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "18",
  "_id": ObjectId("55d220dd6653c32453c0a940")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ahahdaaaa"
  ],
  "CLASS": "1",
  "EN": "causal role | why",
  "FR": "rôle causal | pourquoi",
  "ID": null,
  "IEML": "E:M:.M:O:.-",
  "LAYER": "2",
  "PARADIGM": "1",
  "TAILLE": "18",
  "_id": ObjectId("55d220dd6653c32453c0a873")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "adahdaaaa"
  ],
  "CLASS": "1",
  "EN": "manner | how",
  "FR": "manière | comment",
  "ID": null,
  "IEML": "E:O:.M:O:.-",
  "LAYER": "2",
  "PARADIGM": "1",
  "TAILLE": "12",
  "_id": ObjectId("55d220de6653c32453c0aa49")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aiadhaaaa"
  ],
  "CLASS": "1",
  "EN": "conjugations | when",
  "FR": "conjugaisons | quand",
  "ID": null,
  "IEML": "E:F:.O:M:.-",
  "LAYER": "2",
  "PARADIGM": "1",
  "TAILLE": "30",
  "_id": ObjectId("55d220df6653c32453c0ac41")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aiahhaaaa"
  ],
  "CLASS": "1",
  "EN": "spatial situation | where",
  "FR": "situation spatiale | où",
  "ID": null,
  "IEML": "E:F:.M:M:.-",
  "LAYER": "2",
  "PARADIGM": "1",
  "TAILLE": "45",
  "_id": ObjectId("55d220dc6653c32453c0a6bd")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aeahhaaaa"
  ],
  "CLASS": "1",
  "EN": "path roles",
  "FR": "rôles de chemin",
  "ID": null,
  "IEML": "E:S:.M:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("55d220de6653c32453c0ab25")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "afahhaaaa"
  ],
  "CLASS": "1",
  "EN": "position",
  "FR": "position",
  "ID": null,
  "IEML": "E:B:.M:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("55d220df6653c32453c0acf6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "agahhaaaa"
  ],
  "CLASS": "1",
  "EN": "movement",
  "FR": "mouvement",
  "ID": null,
  "IEML": "E:T:.M:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("55d220dd6653c32453c0a96c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "abadhaaaa"
  ],
  "CLASS": "1",
  "EN": "passive voice",
  "FR": "voix passive",
  "ID": null,
  "IEML": "E:U:.O:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220df6653c32453c0ae0e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "abahfaaaa"
  ],
  "CLASS": "1",
  "EN": "relative position in relation to a vertical axis",
  "FR": "position relative par rapport à un axe vertical",
  "ID": null,
  "IEML": "E:U:.M:B:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("563e521ec75e36652027fa5e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "abahgaaaa"
  ],
  "CLASS": "1",
  "EN": "absolute position in relation to a vertical axis",
  "FR": "position absolue par rapport à un axe vertical",
  "ID": null,
  "IEML": "E:U:.M:T:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("563e5275c75e36652027fa5f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "abaheaaaa"
  ],
  "CLASS": "1",
  "EN": "absolute direction in relation to a vertical axis",
  "FR": "direction absolue par rapport à un axe vertical",
  "ID": null,
  "IEML": "E:U:.M:S:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("563e5316c75e36652027fa60")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "abaeeaaaa"
  ],
  "CLASS": "1",
  "EN": "to the top",
  "FR": "vers le haut",
  "ID": null,
  "IEML": "E:U:.s.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a732")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "abageaaaa"
  ],
  "CLASS": "1",
  "EN": "downward",
  "FR": "vers le bas",
  "ID": null,
  "IEML": "E:U:.d.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aba2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "abafeaaaa"
  ],
  "CLASS": "1",
  "EN": "horizontally",
  "FR": "horizontalement",
  "ID": null,
  "IEML": "E:U:.k.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a861")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "abaegaaaa"
  ],
  "CLASS": "1",
  "EN": "summit",
  "FR": "sommet",
  "ID": null,
  "IEML": "E:U:.t.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a94b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "abaggaaaa"
  ],
  "CLASS": "1",
  "EN": "bottom | basis",
  "FR": "fond | base",
  "ID": null,
  "IEML": "E:U:.l.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa89")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "abafgaaaa"
  ],
  "CLASS": "1",
  "EN": "half-height",
  "FR": "mi-hauteur",
  "ID": null,
  "IEML": "E:U:.n.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5b8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "abahhaaaa"
  ],
  "CLASS": "1",
  "EN": "situation relative to a vertical axis",
  "FR": "situation par rapport à un axe vertical",
  "ID": null,
  "IEML": "E:U:.M:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("55d220dc6653c32453c0a759")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "acahhaaaa"
  ],
  "CLASS": "1",
  "EN": "situation relative to a horizontal axis",
  "FR": "situation par rapport à un axe horizontal",
  "ID": null,
  "IEML": "E:A:.M:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("55d220de6653c32453c0aaa5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "acaheaaaa"
  ],
  "CLASS": "1",
  "EN": "movement in relation to a horizontal axis",
  "FR": "mouvement par rapport à un axe horizontal",
  "ID": null,
  "IEML": "E:A:.M:S:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("563e5628c75e36652027fa64")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "acahfaaaa"
  ],
  "CLASS": "1",
  "EN": "relative position in relation to a horizontal axis",
  "FR": "position relative par rapport à un axe horizontal",
  "IEML": "E:A:.M:B:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("563e578bc75e36652027fa65")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "acahgaaaa"
  ],
  "CLASS": "1",
  "EN": "absolute position in relation to a horizontal axis",
  "FR": "position absolue par rapport à un axe horizontal",
  "IEML": "E:A:.M:T:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("563e57ccc75e36652027fa66")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "acaeeaaaa"
  ],
  "CLASS": "1",
  "EN": "ahead | to the front",
  "FR": "vers l'avant",
  "ID": null,
  "IEML": "E:A:.s.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa63")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "acafeaaaa"
  ],
  "CLASS": "1",
  "EN": "vertically",
  "FR": "verticalement",
  "ID": null,
  "IEML": "E:A:.k.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a91f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "acaegaaaa"
  ],
  "CLASS": "1",
  "EN": "face (situation)",
  "FR": "face",
  "ID": null,
  "IEML": "E:A:.t.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7fc")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "acaggaaaa"
  ],
  "CLASS": "1",
  "EN": "back",
  "FR": "dos",
  "ID": null,
  "IEML": "E:A:.l.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6d2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "acafgaaaa"
  ],
  "CLASS": "1",
  "EN": "half way",
  "FR": "mi-chemin",
  "ID": null,
  "IEML": "E:A:.n.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab17")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "acaehaaaa"
  ],
  "CLASS": "1",
  "EN": "front",
  "FR": "en avant",
  "ID": null,
  "IEML": "E:A:.S:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("563e5a70c75e36652027fa67")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "acaffaaaa"
  ],
  "CLASS": "1",
  "EN": "on the same side",
  "FR": "du même côté",
  "ID": null,
  "IEML": "E:A:.m.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad74")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "acafhaaaa"
  ],
  "CLASS": "1",
  "EN": "median (horizontal axis)",
  "FR": "médian (axe horizontal)",
  "ID": null,
  "IEML": "E:A:.B:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("563e5be8c75e36652027fa69")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "abafhaaaa"
  ],
  "CLASS": "1",
  "EN": "median (vertical axis)",
  "FR": "médian (axe vertical)",
  "ID": null,
  "IEML": "E:U:.B:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("563e555fc75e36652027fa63")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aeaheaaaa"
  ],
  "CLASS": "1",
  "EN": "moving",
  "FR": "moteur (situation spatiale)",
  "ID": null,
  "IEML": "E:S:.M:S:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("563e6e99c75e36652027fa6a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aeahfaaaa"
  ],
  "CLASS": "1",
  "EN": "path",
  "FR": "chemin",
  "ID": null,
  "IEML": "E:S:.M:B:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("563e6fbbc75e36652027fa6b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aeahgaaaa"
  ],
  "CLASS": "1",
  "EN": "traversal",
  "FR": "traversée",
  "IEML": "E:S:.M:T:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("563e6fe2c75e36652027fa6c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aeaeeaaaa"
  ],
  "CLASS": "1",
  "EN": "source",
  "FR": "source",
  "ID": null,
  "IEML": "E:S:.s.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0adc8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aeaghaaaa"
  ],
  "CLASS": "1",
  "EN": "objective end",
  "FR": "fin objective",
  "IEML": "E:S:.T:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("563e7233c75e36652027fa6e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aeafhaaaa"
  ],
  "CLASS": "1",
  "EN": "course",
  "FR": "parcours",
  "ID": null,
  "IEML": "E:S:.B:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("563e7275c75e36652027fa6f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "afaffaaaa"
  ],
  "CLASS": "1",
  "EN": "between",
  "FR": "entre",
  "ID": null,
  "IEML": "E:B:.m.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a90a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "afaefaaaa"
  ],
  "CLASS": "1",
  "EN": "at the left",
  "FR": "à gauche",
  "ID": null,
  "IEML": "E:B:.b.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a55e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "afagfaaaa"
  ],
  "CLASS": "1",
  "EN": "at the right",
  "FR": "à  droite",
  "ID": null,
  "IEML": "E:B:.f.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5eb")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "afahfaaaa"
  ],
  "CLASS": "1",
  "EN": "lateral orientation",
  "FR": "orientation latérale",
  "ID": null,
  "IEML": "E:B:.M:B:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("563e741cc75e36652027fa70")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "afahgaaaa"
  ],
  "CLASS": "1",
  "EN": "distance orientation",
  "FR": "orientation de distance",
  "ID": null,
  "IEML": "E:B:.M:T:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("563e7472c75e36652027fa71")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "afaheaaaa"
  ],
  "CLASS": "1",
  "EN": "inside-outside orientation",
  "FR": "orientation dedans-dehors",
  "IEML": "E:B:.M:S:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("563e752ac75e36652027fa72")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "afafeaaaa"
  ],
  "CLASS": "1",
  "EN": "limiting",
  "FR": "limitant",
  "ID": null,
  "IEML": "E:B:.k.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad67")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "afaehaaaa"
  ],
  "CLASS": "1",
  "EN": "subjective origin",
  "FR": "origine subjective",
  "ID": null,
  "IEML": "E:B:.S:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("563e75c8c75e36652027fa73")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "afaghaaaa"
  ],
  "CLASS": "1",
  "EN": "subjective end",
  "FR": "fin subjective",
  "IEML": "E:B:.T:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("563e75ddc75e36652027fa74")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "afafhaaaa"
  ],
  "CLASS": "1",
  "EN": "proximity",
  "FR": "proximité",
  "ID": null,
  "IEML": "E:B:.B:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("563e75f9c75e36652027fa75")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aeafcaaaa"
  ],
  "CLASS": "1",
  "EN": "operator",
  "FR": "opérateur",
  "ID": null,
  "IEML": "E:S:.c.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("563e7c5dc75e36652027fa76")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ahafcaaaa"
  ],
  "CLASS": "1",
  "EN": "actual systemic cause",
  "FR": "cause systémique actuelle",
  "ID": null,
  "IEML": "E:M:.c.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("55d220dc6653c32453c0a5c7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ahagbaaaa"
  ],
  "CLASS": "1",
  "EN": "virtual existential cause",
  "FR": "cause existentielle virtuelle",
  "IEML": "E:M:.p.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("563e7ca3c75e36652027fa77")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ahagcaaaa"
  ],
  "CLASS": "1",
  "EN": "actual existential cause",
  "FR": "cause existentielle actuelle",
  "IEML": "E:M:.x.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("563e7cbfc75e36652027fa78")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgaaaaaaahaadaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "elements",
  "FR": "éléments",
  "ID": null,
  "IEML": "n.-M:.O:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dc6653c32453c0a786")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aeaecaaaa"
  ],
  "CLASS": "1",
  "EN": "element",
  "FR": "élément",
  "IEML": "E:S:.g.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("563e7e47c75e36652027fa79")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "agageaaaa"
  ],
  "CLASS": "1",
  "EN": "toward",
  "FR": "en direction de",
  "ID": null,
  "IEML": "E:T:.d.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac12")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "agafeaaaa"
  ],
  "CLASS": "1",
  "EN": "by",
  "FR": "par",
  "ID": null,
  "IEML": "E:T:.k.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6ea")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "agaefaaaa"
  ],
  "CLASS": "1",
  "EN": "out of",
  "FR": "hors de",
  "ID": null,
  "IEML": "E:T:.b.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7e3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "agagfaaaa"
  ],
  "CLASS": "1",
  "EN": "in",
  "FR": "dans",
  "ID": null,
  "IEML": "E:T:.f.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a978")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "agaegaaaa"
  ],
  "CLASS": "1",
  "EN": "centrifugal",
  "FR": "centrifuge",
  "ID": null,
  "IEML": "E:T:.t.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5e3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "agaggaaaa"
  ],
  "CLASS": "1",
  "EN": "centripetal",
  "FR": "centripète",
  "ID": null,
  "IEML": "E:T:.l.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad41")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "agafhaaaa"
  ],
  "CLASS": "1",
  "EN": "tangent",
  "FR": "tangent",
  "ID": null,
  "IEML": "E:T:.B:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("563e8293c75e36652027fa7b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "agahgaaaa"
  ],
  "CLASS": "1",
  "EN": "relative to a center",
  "FR": "relatif à un centre",
  "IEML": "E:T:.M:T:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("563e831ac75e36652027fa7c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "agahfaaaa"
  ],
  "CLASS": "1",
  "EN": "relative to a place",
  "FR": "relatif à un lieu",
  "IEML": "E:T:.M:B:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("563e833bc75e36652027fa7d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "agaheaaaa"
  ],
  "CLASS": "1",
  "EN": "relative to a point",
  "FR": "relatif à un point",
  "IEML": "E:T:.M:S:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("563e834dc75e36652027fa7e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "agaehaaaa"
  ],
  "CLASS": "1",
  "EN": "to the outside",
  "FR": "vers l'extérieur",
  "IEML": "E:T:.S:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("563e83bac75e36652027fa7f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "agaghaaaa"
  ],
  "CLASS": "1",
  "EN": "to the inside",
  "FR": "vers l'intérieur",
  "IEML": "E:T:.T:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("563e8403c75e36652027fa80")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "abaehaaaa"
  ],
  "CLASS": "1",
  "EN": "high",
  "FR": "en haut",
  "ID": null,
  "IEML": "E:U:.S:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("563e54d9c75e36652027fa61")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "abaghaaaa"
  ],
  "CLASS": "1",
  "EN": "down",
  "FR": "en bas",
  "ID": null,
  "IEML": "E:U:.T:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("563e54eac75e36652027fa62")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "acaghaaaa"
  ],
  "CLASS": "1",
  "EN": "back-",
  "FR": "en arrière",
  "ID": null,
  "IEML": "E:A:.T:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("563e5b36c75e36652027fa68")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "adaegaaaa"
  ],
  "CLASS": "1",
  "EN": "absolute position",
  "FR": "position absolue",
  "ID": null,
  "IEML": "E:O:.t.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("55d220dd6653c32453c0a8f2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "adaefaaaa"
  ],
  "CLASS": "1",
  "EN": "relative position",
  "FR": "position relative",
  "ID": null,
  "IEML": "E:O:.b.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("55d220de6653c32453c0ab18")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "adaeeaaaa"
  ],
  "CLASS": "1",
  "EN": "absolute direction",
  "FR": "direction absolue",
  "ID": null,
  "IEML": "E:O:.s.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("55d220de6653c32453c0ab38")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "adafeaaaa"
  ],
  "CLASS": "1",
  "EN": "perpendicular to the axis",
  "FR": "perpendiculaire à l'axe",
  "ID": null,
  "IEML": "E:O:.k.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("55d220dd6653c32453c0a7c7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "adaffaaaa"
  ],
  "CLASS": "1",
  "EN": "same side | level",
  "FR": "même côté | niveau",
  "ID": null,
  "IEML": "E:O:.m.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("55d220df6653c32453c0ac97")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "adafgaaaa"
  ],
  "CLASS": "1",
  "EN": "half-length",
  "FR": "mi-longueur",
  "ID": null,
  "IEML": "E:O:.n.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("55d220de6653c32453c0aa81")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "adageaaaa"
  ],
  "CLASS": "1",
  "EN": "absolute direction : to the bottom, the back",
  "FR": "direction absolue : vers le bas, l'arrière",
  "ID": null,
  "IEML": "E:O:.d.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("55d220dc6653c32453c0a6cf")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "adagfaaaa"
  ],
  "CLASS": "1",
  "EN": "relative position: lower, behind",
  "FR": "position relative: en bas, derrière",
  "ID": null,
  "IEML": "E:O:.f.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("55d220de6653c32453c0aba7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "adaggaaaa"
  ],
  "CLASS": "1",
  "EN": "absolute position: bottom, back",
  "FR": "position absolue: base, dos",
  "ID": null,
  "IEML": "E:O:.l.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("55d220dc6653c32453c0a5a9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "afageaaaa"
  ],
  "CLASS": "1",
  "EN": "closing",
  "FR": "fermeture",
  "ID": null,
  "IEML": "E:B:.d.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa1a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aeaffaaaa"
  ],
  "CLASS": "1",
  "EN": "route",
  "FR": "trajet",
  "ID": null,
  "IEML": "E:S:.m.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a95f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aeafgaaaa"
  ],
  "CLASS": "1",
  "EN": "channel | tunnel",
  "FR": "canal | tunnel",
  "ID": null,
  "IEML": "E:S:.n.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a74e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "afaeeaaaa"
  ],
  "CLASS": "1",
  "EN": "openning",
  "FR": "ouverture",
  "ID": null,
  "IEML": "E:B:.s.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a57c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ahaeeaaaa"
  ],
  "CLASS": "1",
  "EN": "dynamic origin",
  "FR": "origine dynamique",
  "ID": null,
  "IEML": "E:M:.s.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("55d220df6653c32453c0ac8c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ahaefaaaa"
  ],
  "CLASS": "1",
  "EN": "relative origin",
  "FR": "origine relative",
  "ID": null,
  "IEML": "E:M:.b.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("55d220df6653c32453c0ac17")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aeageaaaa"
  ],
  "CLASS": "1",
  "EN": "well",
  "FR": "puits",
  "ID": null,
  "IEML": "E:S:.d.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a82c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "afaegaaaa"
  ],
  "CLASS": "1",
  "EN": "here | same place",
  "FR": "ici | même lieu",
  "ID": null,
  "IEML": "E:B:.t.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac63")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "afaggaaaa"
  ],
  "CLASS": "1",
  "EN": "over there | far away",
  "FR": "là-bas | loin",
  "ID": null,
  "IEML": "E:B:.l.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab54")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "afafgaaaa"
  ],
  "CLASS": "1",
  "EN": "near | there",
  "FR": "là | près",
  "ID": null,
  "IEML": "E:B:.n.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a709")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ahafgaaaa"
  ],
  "CLASS": "1",
  "EN": "absolute intermediary",
  "FR": "intermédiaire absolu",
  "ID": null,
  "IEML": "E:M:.n.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("55d220de6653c32453c0aa78")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ahaegaaaa"
  ],
  "CLASS": "1",
  "EN": "absolute origin",
  "FR": "origine absolue",
  "ID": null,
  "IEML": "E:M:.t.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("55d220dc6653c32453c0a59e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "agaeeaaaa"
  ],
  "CLASS": "1",
  "EN": "from",
  "FR": "à partir de",
  "ID": null,
  "IEML": "E:T:.s.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a801")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aeaehaaaa"
  ],
  "CLASS": "1",
  "EN": "objective origin",
  "FR": "origine objective",
  "ID": null,
  "IEML": "E:S:.S:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("563e70bec75e36652027fa6d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dcabaaaaa"
  ],
  "CLASS": "2",
  "EN": "broadcast and cut off the sound",
  "FR": "diffuser et couper le son",
  "IEML": "O:A:.U:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("566074374798d70493eef702")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ddabaaaaa"
  ],
  "CLASS": "2",
  "EN": "control auditory experience",
  "FR": "contrôler l'expérience auditive",
  "IEML": "O:O:.U:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220dd6653c32453c0a9a9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bbabaaaaa"
  ],
  "CLASS": "2",
  "EN": "create sound forms",
  "FR": "créer des formes sonores",
  "IEML": "wo.U:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a721")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dbabaaaaa"
  ],
  "CLASS": "2",
  "EN": "create and recognize sound forms",
  "FR": "créer et reconnaître des formes sonores",
  "IEML": "O:U:.U:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("566075ab4798d70493eef707")
});
db.getCollection("terms").insert({
  "IEML": "U:O:.U:.-",
  "FR": "créer et diffuser du son",
  "EN": "create and broadcast sound",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "bdabaaaaa"
  ],
  "_id": ObjectId("5660760e4798d70493eef70c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cdabaaaaa"
  ],
  "CLASS": "2",
  "EN": "hear and cut off the sound",
  "FR": "entendre et couper le son",
  "IEML": "A:O:.U:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("5660777e4798d70493eef711")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bbacaaaaa"
  ],
  "CLASS": "2",
  "EN": "make a pressure",
  "FR": "faire une pression",
  "IEML": "wo.A:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ac0b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bdacaaaaa"
  ],
  "CLASS": "2",
  "EN": "shape and show the pressure",
  "FR": "former et exhiber la pression",
  "IEML": "U:O:.A:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("56607a3b4798d70493eef716")
});
db.getCollection("terms").insert({
  "IEML": "A:O:.A:.-",
  "FR": "toucher et protéger du contact",
  "EN": "touch and protect from contact",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "cdacaaaaa"
  ],
  "_id": ObjectId("56607a884798d70493eef71b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dbacaaaaa"
  ],
  "CLASS": "2",
  "EN": "shape and recognize a tactile form",
  "FR": "former et reconnaître une forme tactile",
  "IEML": "O:U:.A:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("56607b204798d70493eef720")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cbacaaaaa"
  ],
  "CLASS": "2",
  "EN": "touch | recognize a tactile form",
  "FR": "toucher | reconnaître une forme tactile",
  "IEML": "wu.A:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a66e")
});
db.getCollection("terms").insert({
  "IEML": "O:A:.A:.-",
  "FR": "montrer et couper le contact",
  "EN": "show and cut off contact",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dcacaaaaa"
  ],
  "_id": ObjectId("56607bec4798d70493eef725")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dbaeaaaaa"
  ],
  "CLASS": "2",
  "EN": "shape and see an image",
  "FR": "former et voir une image",
  "IEML": "O:U:.S:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("566083004798d70493eef72f")
});
db.getCollection("terms").insert({
  "IEML": "U:O:.S:.-",
  "FR": "former et afficher une image",
  "EN": "shape and display an image",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "bdaeaaaaa"
  ],
  "_id": ObjectId("5660844d4798d70493eef734")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cdaeaaaaa"
  ],
  "CLASS": "2",
  "EN": "see and hide an image",
  "FR": "voir et cacher une image",
  "IEML": "A:O:.S:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("566082444798d70493eef72a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bbaeaaaaa"
  ],
  "CLASS": "2",
  "EN": "shape a visual image (size | figure | color)",
  "FR": "former une image visuelle (taille | figure | couleur)",
  "IEML": "wo.S:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac5a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bcaeaaaaa"
  ],
  "CLASS": "2",
  "EN": "display | broadcast a visual image",
  "FR": "afficher | diffuser une image visuelle",
  "IEML": "wa.S:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad1e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cbaeaaaaa"
  ],
  "CLASS": "2",
  "EN": "see | recognize a visual form",
  "FR": "voir | reconnaître une forme visuelle",
  "IEML": "wu.S:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad4a")
});
db.getCollection("terms").insert({
  "IEML": "O:A:.S:.-",
  "FR": "afficher et cacher une image visuelle",
  "EN": "display and hide a visual image",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dcaeaaaaa"
  ],
  "_id": ObjectId("5660856e4798d70493eef739")
});
db.getCollection("terms").insert({
  "IEML": "O:U:.B:.-",
  "FR": "créer et sentir un goût | une odeur",
  "EN": "create and sense a taste | a smell",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dbafaaaaa"
  ],
  "_id": ObjectId("566095d74798d70493eef73e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bcafaaaaa"
  ],
  "CLASS": "2",
  "EN": "display a smell | a taste",
  "FR": "diffuser un goût | une odeur",
  "IEML": "wa.B:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a990")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ddafaaaaa"
  ],
  "CLASS": "2",
  "EN": "control the chemical sensation",
  "FR": "contrôler la sensation chimique",
  "IEML": "O:O:.B:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220dc6653c32453c0a5bf")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dcafaaaaa"
  ],
  "CLASS": "2",
  "EN": "display and block a gustative | olfactive experience",
  "FR": "diffuser et bloquer une expérience gustative | olfactive",
  "IEML": "O:A:.B:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("566096ee4798d70493eef743")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cbafaaaaa"
  ],
  "CLASS": "2",
  "EN": "smell | taste | recognize a chemical form",
  "FR": "sentir | goûter | reconnaître des formes chimiques",
  "IEML": "wu.B:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7b6")
});
db.getCollection("terms").insert({
  "IEML": "U:O:.B:.-",
  "FR": "créer et diffuser un goût | une odeur",
  "EN": "create and display a taste | a smell",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "bdafaaaaa"
  ],
  "_id": ObjectId("566097fc4798d70493eef748")
});
db.getCollection("terms").insert({
  "IEML": "A:O:.B:.-",
  "FR": "sentir et isoler une forme chimique",
  "EN": "sense and insulate a chemical form",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "cdafaaaaa"
  ],
  "_id": ObjectId("5660984b4798d70493eef74d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bbagaaaaa"
  ],
  "CLASS": "2",
  "EN": "manipulate the orientation | the position in space",
  "FR": "manipuler l'orientation | la position dans l'espace",
  "IEML": "wo.T:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa4c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bcagaaaaa"
  ],
  "CLASS": "2",
  "EN": "display a movement | drive | dance",
  "FR": "afficher un mouvement | conduire | danser",
  "IEML": "wa.T:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa0d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ddaiaaaaa"
  ],
  "CLASS": "2",
  "EN": "control sensori-motor experience",
  "FR": "contrôler l'expérience sensori-motrice",
  "IEML": "O:O:.F:.-",
  "LAYER": "2",
  "PARADIGM": "1",
  "TAILLE": "20",
  "_id": ObjectId("55d220dc6653c32453c0a616")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bfabcaaaa"
  ],
  "CLASS": "2",
  "EN": "use administrative | commercial law",
  "FR": "utiliser le droit administratif | commercial",
  "IEML": "o.wa.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a55d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bbaeeaaaa"
  ],
  "CLASS": "2",
  "EN": "brainstorm",
  "FR": "brasser les idées",
  "IEML": "wo.s.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a569")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bbahhaaaa"
  ],
  "CLASS": "2",
  "EN": "experience variation (cultivate)",
  "FR": "variation de l'expérience (cultiver la)",
  "IEML": "wo.M:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("55d220dc6653c32453c0a587")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bfaeaaaaa"
  ],
  "CLASS": "2",
  "EN": "bring | carry",
  "FR": "transporter | amener",
  "IEML": "o.S:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a593")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bfadhaaaa"
  ],
  "CLASS": "2",
  "EN": "from will (perform)",
  "FR": "à partir de la volonté (performer)",
  "IEML": "o.O:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dc6653c32453c0a59b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ddaegaaaa"
  ],
  "CLASS": "2",
  "EN": "time mastering (provide resources for action through)",
  "FR": "maîtrise du temps (fournir des ressources à  l'action par la)",
  "IEML": "O:O:.t.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220dc6653c32453c0a5a5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dhagcaaaa"
  ],
  "CLASS": "2",
  "EN": "work on a method | a project",
  "FR": "travailler une méthode | un projet",
  "IEML": "O:M:.x.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dc6653c32453c0a5b4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ccacaaaaa"
  ],
  "CLASS": "2",
  "EN": "insulate | protect from contact",
  "FR": "isoler | protéger du contact",
  "IEML": "we.A:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5ba")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cbagcaaaa"
  ],
  "CLASS": "2",
  "EN": "assess the technical system",
  "FR": "évaluer le système technique",
  "IEML": "wu.x.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5bb")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bgabfaaaa"
  ],
  "CLASS": "2",
  "EN": "design | plan",
  "FR": "concevoir | planifier",
  "IEML": "e.o.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5bd")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cbaecaaaa"
  ],
  "CLASS": "2",
  "EN": "assess the communication mode in use",
  "FR": "évaluer le mode de communication en usage",
  "IEML": "wu.g.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5be")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bbaefaaaa"
  ],
  "CLASS": "2",
  "EN": "augment linguistic resources",
  "FR": "augmenter les ressources linguistiques",
  "IEML": "wo.b.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5c2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfagfaaaa"
  ],
  "CLASS": "2",
  "EN": "physically assault",
  "FR": "agresser physiquement",
  "IEML": "a.f.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5de")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ddafcaaaa"
  ],
  "CLASS": "2",
  "EN": "govern the community",
  "FR": "gouverner la communauté",
  "IEML": "O:O:.c.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220dc6653c32453c0a5e0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "beafgaaaa"
  ],
  "CLASS": "2",
  "EN": "ignore principles",
  "FR": "ignorer les principes",
  "IEML": "y.n.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5ec")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bgaefaaaa"
  ],
  "CLASS": "2",
  "EN": "be incoherent",
  "FR": "être incohérent",
  "IEML": "e.b.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a609")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dhabfaaaa"
  ],
  "CLASS": "2",
  "EN": "into will (perform)",
  "FR": "dans la volonté (performer)",
  "IEML": "O:M:.o.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dc6653c32453c0a60e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bgadhaaaa"
  ],
  "CLASS": "2",
  "EN": "from competency (perform)",
  "FR": "à partir de la compétence (performer)",
  "IEML": "e.O:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dc6653c32453c0a615")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ceabgaaaa"
  ],
  "CLASS": "2",
  "EN": "judge (to)",
  "FR": "juger",
  "IEML": "u.e.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a623")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ccabgaaaa"
  ],
  "CLASS": "2",
  "EN": "renew competences",
  "FR": "renouveler les compétences",
  "IEML": "we.e.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a625")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bgagaaaaa"
  ],
  "CLASS": "2",
  "EN": "build | combine",
  "FR": "construire | combiner",
  "IEML": "e.T:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a62c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ccahhaaaa"
  ],
  "CLASS": "2",
  "EN": "sustainable equilibrium (cultivate a)",
  "FR": "équilibre durable (cultiver un)",
  "IEML": "we.M:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("55d220dc6653c32453c0a62e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bgabbaaaa"
  ],
  "CLASS": "2",
  "EN": "exploit a talent",
  "FR": "exploiter un talent",
  "IEML": "e.wo.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a63a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ddagbaaaa"
  ],
  "CLASS": "2",
  "EN": "govern the objectives",
  "FR": "gouverner les objectifs",
  "IEML": "O:O:.p.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220dc6653c32453c0a641")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bcaffaaaa"
  ],
  "CLASS": "2",
  "EN": "sublimate one's emotions",
  "FR": "sublimer ses émotions",
  "IEML": "wa.m.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a648")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cgafeaaaa"
  ],
  "CLASS": "2",
  "EN": "steal",
  "FR": "voler quelque chose",
  "IEML": "i.k.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a64e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfafcaaaa"
  ],
  "CLASS": "2",
  "EN": "accept one's transformation",
  "FR": "accepter sa transformation",
  "IEML": "a.c.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0adf3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bbagfaaaa"
  ],
  "CLASS": "2",
  "EN": "experiment new bodily habits",
  "FR": "expérimenter de nouvelles habitudes corporelles",
  "IEML": "wo.f.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a658")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cbafeaaaa"
  ],
  "CLASS": "2",
  "EN": "be sensitive to human relations",
  "FR": "être sensible aux rapports humains",
  "IEML": "wu.k.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a65a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bbadhaaaa"
  ],
  "CLASS": "2",
  "EN": "identify key-points of one's activity",
  "FR": "identifier les points clé de son activité",
  "IEML": "wo.O:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dc6653c32453c0a663")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfaebaaaa"
  ],
  "CLASS": "2",
  "EN": "assume one's style",
  "FR": "assumer son style",
  "IEML": "a.j.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a66b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cbahhaaaa"
  ],
  "CLASS": "2",
  "EN": "subtlety of perception (cultivate)",
  "FR": "subtilité de la perception (cultiver la)",
  "IEML": "wu.M:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("55d220dc6653c32453c0a66f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ceabbaaaa"
  ],
  "CLASS": "2",
  "EN": "publish | exhibit an original work",
  "FR": "publier | exposer une oeuvre originale",
  "IEML": "u.wo.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a67b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bbafeaaaa"
  ],
  "CLASS": "2",
  "EN": "plant the seeds of social change",
  "FR": "semer les graines du changement social",
  "IEML": "wo.k.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a67d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ceagaaaaa"
  ],
  "CLASS": "2",
  "EN": "walk | travel on land",
  "FR": "marcher | voyager sur terre",
  "IEML": "u.T:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a681")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "beacgaaaa"
  ],
  "CLASS": "2",
  "EN": "explicate | formalize",
  "FR": "expliciter | formaliser",
  "IEML": "y.i.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a697")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ddabeaaaa"
  ],
  "CLASS": "2",
  "EN": "work on knowledge",
  "FR": "travailler les savoirs",
  "IEML": "O:O:.y.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220dc6653c32453c0a6a2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dhafcaaaa"
  ],
  "CLASS": "2",
  "EN": "work on oneself",
  "FR": "travailler sur soi",
  "IEML": "O:M:.c.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dc6653c32453c0a6a4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ddagaaaaa"
  ],
  "CLASS": "2",
  "EN": "control motor experience",
  "FR": "contrôler l'expérience motrice",
  "IEML": "O:O:.T:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220dc6653c32453c0a6ab")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cgacbaaaa"
  ],
  "CLASS": "2",
  "EN": "equip a territory | a local community",
  "FR": "équiper un territoire | une collectivité locale",
  "IEML": "i.wu.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6af")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ccacfaaaa"
  ],
  "CLASS": "2",
  "EN": "renew one's commitments",
  "FR": "renouveler ses engagements",
  "IEML": "we.a.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6b5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cbagbaaaa"
  ],
  "CLASS": "2",
  "EN": "measure the distance to the objectives",
  "FR": "mesurer la distance aux objectifs",
  "IEML": "wu.p.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6bf")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bcacbaaaa"
  ],
  "CLASS": "2",
  "EN": "eat | rest | entertain oneself",
  "FR": "se restaurer | se distraire",
  "IEML": "wa.wu.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6c0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dhagbaaaa"
  ],
  "CLASS": "2",
  "EN": "work on a subject",
  "FR": "travailler un sujet",
  "IEML": "O:M:.p.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dc6653c32453c0a6c1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bgagcaaaa"
  ],
  "CLASS": "2",
  "EN": "make tools one's own",
  "FR": "s'approprier des outils",
  "IEML": "e.x.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6c2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ddahdaaaa"
  ],
  "CLASS": "2",
  "EN": "govern",
  "FR": "gouverner",
  "IEML": "O:O:.M:O:.-",
  "LAYER": "2",
  "PARADIGM": "1",
  "TAILLE": "24",
  "_id": ObjectId("55d220dc6653c32453c0a6ca")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dhahaaaaa"
  ],
  "CLASS": "2",
  "EN": "provoke a physical change",
  "FR": "provoquer un changement physique",
  "IEML": "O:M:.M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "18",
  "_id": ObjectId("55d220dc6653c32453c0a6d1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ceageaaaa"
  ],
  "CLASS": "2",
  "EN": "lack precision",
  "FR": "manquer de précision",
  "IEML": "u.d.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6d7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ddaggaaaa"
  ],
  "CLASS": "2",
  "EN": "spatial extension (provide resources for action through)",
  "FR": "extension spatiale (fournir des ressources à  l'action par l')",
  "IEML": "O:O:.l.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220dc6653c32453c0a6d8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cbabbaaaa"
  ],
  "CLASS": "2",
  "EN": "be a child",
  "FR": "être un enfant",
  "IEML": "wu.wo.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6e8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cgagbaaaa"
  ],
  "CLASS": "2",
  "EN": "construct one's subject",
  "FR": "construire son sujet",
  "IEML": "i.p.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6fc")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bgaecaaaa"
  ],
  "CLASS": "2",
  "EN": "own a statement",
  "FR": "s'approprier une démarche",
  "IEML": "e.g.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6fe")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfaeeaaaa"
  ],
  "CLASS": "2",
  "EN": "interpret literally",
  "FR": "prendre à  la lettre",
  "IEML": "a.s.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a706")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bbabfaaaa"
  ],
  "CLASS": "2",
  "EN": "establish principles",
  "FR": "établir des principes",
  "IEML": "wo.o.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a70d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bfaggaaaa"
  ],
  "CLASS": "2",
  "EN": "provoke chaos | confusion",
  "FR": "provoquer le chaos | la confusion",
  "IEML": "o.l.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a710")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dhabbaaaa"
  ],
  "CLASS": "2",
  "EN": "gain in creative power",
  "FR": "gagner en puissance créative",
  "IEML": "O:M:.wo.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dc6653c32453c0a718")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ccabcaaaa"
  ],
  "CLASS": "2",
  "EN": "make love | conceive",
  "FR": "faire l'amour | concevoir",
  "IEML": "we.wa.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a719")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bcahdaaaa"
  ],
  "CLASS": "2",
  "EN": "improve activity frameworks",
  "FR": "perfectionner les cadres de l'activité",
  "IEML": "wa.M:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dc6653c32453c0a71d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ddaceaaaa"
  ],
  "CLASS": "2",
  "EN": "work on communication",
  "FR": "travailler la communication",
  "IEML": "O:O:.u.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220dc6653c32453c0a72c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ccaeaaaaa"
  ],
  "CLASS": "2",
  "EN": "hide | protect from sight",
  "FR": "cacher | protéger de la vue",
  "IEML": "we.S:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a72f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ceaffaaaa"
  ],
  "CLASS": "2",
  "EN": "manipulate emotions",
  "FR": "manipuler les émotions",
  "IEML": "u.m.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a735")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cgafcaaaa"
  ],
  "CLASS": "2",
  "EN": "come to term with one's obstacles",
  "FR": "se réconcilier avec ses obstacles",
  "IEML": "i.c.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a73c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cgahdaaaa"
  ],
  "CLASS": "2",
  "EN": "achieve  | improve a work",
  "FR": "achever | améliorer une oeuvre",
  "IEML": "i.M:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dc6653c32453c0a73e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dhaegaaaa"
  ],
  "CLASS": "2",
  "EN": "destroy memory",
  "FR": "détruire la mémoire",
  "IEML": "O:M:.t.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dc6653c32453c0a742")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "beadhaaaa"
  ],
  "CLASS": "2",
  "EN": "from knowledge (perform)",
  "FR": "à partir du savoir (performer)",
  "IEML": "y.O:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dc6653c32453c0a74a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ceafaaaaa"
  ],
  "CLASS": "2",
  "EN": "swim | travel on water",
  "FR": "nager | voyager sur l'eau",
  "IEML": "u.B:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a74c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ddafbaaaa"
  ],
  "CLASS": "2",
  "EN": "govern the meaning (of the enterprise)",
  "FR": "gouverner le sens (de l'entreprise)",
  "IEML": "O:O:.h.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220dc6653c32453c0a75b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cbaegaaaa"
  ],
  "CLASS": "2",
  "EN": "understand causes",
  "FR": "comprendre les causes",
  "IEML": "wu.t.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a75f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bcabgaaaa"
  ],
  "CLASS": "2",
  "EN": "master competences",
  "FR": "maîtriser les compétences",
  "IEML": "wa.e.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a762")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bgafeaaaa"
  ],
  "CLASS": "2",
  "EN": "be carried away by one's passions",
  "FR": "être emporté par ses passions",
  "IEML": "e.k.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a764")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cbafcaaaa"
  ],
  "CLASS": "2",
  "EN": "assess the community",
  "FR": "évaluer la communauté",
  "IEML": "wu.c.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a766")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfaefaaaa"
  ],
  "CLASS": "2",
  "EN": "interrupt the communication",
  "FR": "interrompre la communication",
  "IEML": "a.b.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a784")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bgafgaaaa"
  ],
  "CLASS": "2",
  "EN": "blindly conform",
  "FR": "être conformiste | suiviste",
  "IEML": "e.n.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a78a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bfagcaaaa"
  ],
  "CLASS": "2",
  "EN": "find one's bearings in the steps of work",
  "FR": "s'orienter dans les étapes du travail",
  "IEML": "o.x.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a78e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dhaiaaaaa"
  ],
  "CLASS": "2",
  "EN": "move | accomplish a physical action",
  "FR": "bouger | accomplir une action physique",
  "IEML": "O:M:.F:.-",
  "LAYER": "2",
  "PARADIGM": "1",
  "TAILLE": "30",
  "_id": ObjectId("55d220dc6653c32453c0a790")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bbafcaaaa"
  ],
  "CLASS": "2",
  "EN": "think about possible communities",
  "FR": "réfléchir aux communautés possibles",
  "IEML": "wo.c.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a791")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ddaefaaaa"
  ],
  "CLASS": "2",
  "EN": "language-games (provide resources for action through)",
  "FR": "jeux de langage (fournir des ressources à  l'action par les)",
  "IEML": "O:O:.b.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220dd6653c32453c0a7a2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ccaebaaaa"
  ],
  "CLASS": "2",
  "EN": "unify the symbolic system",
  "FR": "unifier le système symbolique",
  "IEML": "we.j.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7a7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bfaecaaaa"
  ],
  "CLASS": "2",
  "EN": "choose a statement | a topic",
  "FR": "choisir une démarche | un propos",
  "IEML": "o.g.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7b8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "beaccaaaa"
  ],
  "CLASS": "2",
  "EN": "assume a family tradition | identity",
  "FR": "assumer une tradition | une identité familiale",
  "IEML": "y.we.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7b9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cbaceaaaa"
  ],
  "CLASS": "2",
  "EN": "navigate the communication channels",
  "FR": "s'orienter dans les canaux de communication",
  "IEML": "wu.u.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7cf")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cbafbaaaa"
  ],
  "CLASS": "2",
  "EN": "assess the interpretation mode",
  "FR": "évaluer les modes d'interprétation",
  "IEML": "wu.h.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7d4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dhafbaaaa"
  ],
  "CLASS": "2",
  "EN": "work on the interpretation",
  "FR": "travailler l'interprétation",
  "IEML": "O:M:.h.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dd6653c32453c0a7d7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "beageaaaa"
  ],
  "CLASS": "2",
  "EN": "ignore facts",
  "FR": "ignorer les faits",
  "IEML": "y.d.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7de")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ceacbaaaa"
  ],
  "CLASS": "2",
  "EN": "express oneself in the media",
  "FR": "s'exprimer dans les médias",
  "IEML": "u.wu.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7df")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bcabaaaaa"
  ],
  "CLASS": "2",
  "EN": "broadcast | display voice & sound",
  "FR": "diffuser | exhiber la voix & le son",
  "IEML": "wa.U:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7e0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bfabbaaaa"
  ],
  "CLASS": "2",
  "EN": "use intellectual property law",
  "FR": "utiliser les lois sur la propriété intellectuelle",
  "IEML": "o.wo.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7e7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bcacfaaaa"
  ],
  "CLASS": "2",
  "EN": "cultivate one's character",
  "FR": "cultiver son caractère",
  "IEML": "wa.a.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a800")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cgagaaaaa"
  ],
  "CLASS": "2",
  "EN": "run",
  "FR": "courir",
  "IEML": "i.T:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a80c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "beaddaaaa"
  ],
  "CLASS": "2",
  "EN": "assume an identity",
  "FR": "assumer une identité",
  "IEML": "y.O:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220dd6653c32453c0a80d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bfagaaaaa"
  ],
  "CLASS": "2",
  "EN": "keep",
  "FR": "garder",
  "IEML": "o.T:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a80e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cgaddaaaa"
  ],
  "CLASS": "2",
  "EN": "equip",
  "FR": "équiper",
  "IEML": "i.O:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220dd6653c32453c0a814")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ddaeeaaaa"
  ],
  "CLASS": "2",
  "EN": "intellectual openness (provide resources for action through)",
  "FR": "ouverture intellectuelle (fournir des ressources à  l'action par l')",
  "IEML": "O:O:.s.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220dd6653c32453c0a816")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dhahdaaaa"
  ],
  "CLASS": "2",
  "EN": "create a work of the mind",
  "FR": "créer une œuvre de l'esprit",
  "IEML": "O:M:.M:O:.-",
  "LAYER": "2",
  "PARADIGM": "1",
  "TAILLE": "36",
  "_id": ObjectId("55d220dd6653c32453c0a825")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cgabbaaaa"
  ],
  "CLASS": "2",
  "EN": "equip a scientific | artistic activity",
  "FR": "équiper une activité scientifique | artistique",
  "IEML": "i.wo.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a827")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bbaecaaaa"
  ],
  "CLASS": "2",
  "EN": "reflect on other communication modes",
  "FR": "réfléchir à d'autres modes de communication",
  "IEML": "wo.g.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a829")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bcaiaaaaa"
  ],
  "CLASS": "2",
  "EN": "display sensorimotricity",
  "FR": "exposer la sensori-motricité",
  "IEML": "wa.F:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "5",
  "_id": ObjectId("55d220dd6653c32453c0a832")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfahhaaaa"
  ],
  "CLASS": "2",
  "EN": "destroy social relations",
  "FR": "détruire les relations sociales",
  "IEML": "a.M:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("55d220dd6653c32453c0a835")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ccagfaaaa"
  ],
  "CLASS": "2",
  "EN": "satisfy one's primary needs",
  "FR": "satisfaire ses besoins primaires",
  "IEML": "we.f.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a83a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "beaffaaaa"
  ],
  "CLASS": "2",
  "EN": "ignore emotions",
  "FR": "ignorer ses émotions",
  "IEML": "y.m.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a846")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfadhaaaa"
  ],
  "CLASS": "2",
  "EN": "on a social basis (perform)",
  "FR": "sur une base sociale (performer)",
  "IEML": "a.O:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dd6653c32453c0a84d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bfafcaaaa"
  ],
  "CLASS": "2",
  "EN": "orient one's personal path",
  "FR": "orienter son cheminement personnel",
  "IEML": "o.c.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a850")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bbagcaaaa"
  ],
  "CLASS": "2",
  "EN": "ponder possible techniques",
  "FR": "réfléchir aux techniques possibles",
  "IEML": "wo.x.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a854")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cbabeaaaa"
  ],
  "CLASS": "2",
  "EN": "question accepted knowledge",
  "FR": "questionner les savoirs reçus",
  "IEML": "wu.y.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a85d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bgacfaaaa"
  ],
  "CLASS": "2",
  "EN": "demand",
  "FR": "demander",
  "IEML": "e.a.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a85e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cgaebaaaa"
  ],
  "CLASS": "2",
  "EN": "refine one's language",
  "FR": "raffiner son langage",
  "IEML": "i.j.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a862")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ceaceaaaa"
  ],
  "CLASS": "2",
  "EN": "communicate",
  "FR": "communiquer",
  "IEML": "u.u.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a863")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dhaggaaaa"
  ],
  "CLASS": "2",
  "EN": "destroy space",
  "FR": "détruire l'espace",
  "IEML": "O:M:.l.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dd6653c32453c0a868")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cbaggaaaa"
  ],
  "CLASS": "2",
  "EN": "extend one's overall view",
  "FR": "étendre sa vue d'ensemble",
  "IEML": "wu.l.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a86d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bhaiaaaaa"
  ],
  "CLASS": "2",
  "EN": "move objectively",
  "FR": "bouger objectivement",
  "IEML": "U:M:.F:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "15",
  "_id": ObjectId("55d220dd6653c32453c0a86f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ceafbaaaa"
  ],
  "CLASS": "2",
  "EN": "state a meaning",
  "FR": "énoncer un sens",
  "IEML": "u.h.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a882")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfacgaaaa"
  ],
  "CLASS": "2",
  "EN": "sell",
  "FR": "vendre",
  "IEML": "a.i.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a887")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bbaiaaaaa"
  ],
  "CLASS": "2",
  "EN": "modulate phenomena",
  "FR": "moduler les phénomènes",
  "IEML": "wo.F:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "5",
  "_id": ObjectId("55d220dd6653c32453c0a893")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ddabfaaaa"
  ],
  "CLASS": "2",
  "EN": "work on principles",
  "FR": "travailler les principes",
  "IEML": "O:O:.o.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220dd6653c32453c0a89c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bfafaaaaa"
  ],
  "CLASS": "2",
  "EN": "catch | grasp",
  "FR": "attraper | tenir",
  "IEML": "o.B:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8ab")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cgaiaaaaa"
  ],
  "CLASS": "2",
  "EN": "perform a physical movement energetically",
  "FR": "accomplir un mouvement énergique",
  "IEML": "i.F:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "5",
  "_id": ObjectId("55d220dd6653c32453c0a8b0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ccacbaaaa"
  ],
  "CLASS": "2",
  "EN": "give birth",
  "FR": "donner naissance",
  "IEML": "we.wu.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8bf")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ccaefaaaa"
  ],
  "CLASS": "2",
  "EN": "cultivate the information system",
  "FR": "cultiver le système d'information",
  "IEML": "we.b.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8c4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bgagfaaaa"
  ],
  "CLASS": "2",
  "EN": "be technically incompetent",
  "FR": "être techniquement incompétent",
  "IEML": "e.f.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8c6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cbaffaaaa"
  ],
  "CLASS": "2",
  "EN": "express one's emotions",
  "FR": "exprimer ses émotions",
  "IEML": "wu.m.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8cb")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bbaggaaaa"
  ],
  "CLASS": "2",
  "EN": "make room | reorganize",
  "FR": "faire de l'espace | réorganiser",
  "IEML": "wo.l.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8d4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bfabfaaaa"
  ],
  "CLASS": "2",
  "EN": "aim at an objective",
  "FR": "viser un objectif",
  "IEML": "o.o.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8da")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "beaggaaaa"
  ],
  "CLASS": "2",
  "EN": "ignore limits",
  "FR": "ignorer les limites",
  "IEML": "y.l.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8ec")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ceabaaaaa"
  ],
  "CLASS": "2",
  "EN": "come",
  "FR": "venir",
  "IEML": "u.U:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8ee")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ceadhaaaa"
  ],
  "CLASS": "2",
  "EN": "from expression (perform)",
  "FR": "à partir de l'expression (performer)",
  "IEML": "u.O:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dd6653c32453c0a8f9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bbabeaaaa"
  ],
  "CLASS": "2",
  "EN": "find one's bearings into knowledge",
  "FR": "s'orienter dans les savoirs",
  "IEML": "wo.y.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8fc")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ceaegaaaa"
  ],
  "CLASS": "2",
  "EN": "counterfeit | forge",
  "FR": "contrefaire | faire un faux",
  "IEML": "u.t.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a906")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cgabfaaaa"
  ],
  "CLASS": "2",
  "EN": "obtain | get a position",
  "FR": "obtenir une position",
  "IEML": "i.o.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a904")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "beacaaaaa"
  ],
  "CLASS": "2",
  "EN": "unfold | unwrap",
  "FR": "déplier | développer",
  "IEML": "y.A:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a90d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfafgaaaa"
  ],
  "CLASS": "2",
  "EN": "corrupt",
  "FR": "corrompre",
  "IEML": "a.n.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a90e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ccaeeaaaa"
  ],
  "CLASS": "2",
  "EN": "cultivate intellectual equilibrium",
  "FR": "cultiver l'équilibre intellectuel",
  "IEML": "we.s.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a91c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bgabcaaaa"
  ],
  "CLASS": "2",
  "EN": "own a capital",
  "FR": "posséder un capital",
  "IEML": "e.wa.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a922")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ceafcaaaa"
  ],
  "CLASS": "2",
  "EN": "commit oneself to change",
  "FR": "s'engager à changer",
  "IEML": "u.c.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a926")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ddafeaaaa"
  ],
  "CLASS": "2",
  "EN": "generosity (provide resources for action through)",
  "FR": "générosité (fournir des ressources à  l'action par la)",
  "IEML": "O:O:.k.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220dd6653c32453c0a927")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bcaebaaaa"
  ],
  "CLASS": "2",
  "EN": "improve the symbolic system",
  "FR": "perfectionner le système symbolique",
  "IEML": "wa.j.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a92d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bgaebaaaa"
  ],
  "CLASS": "2",
  "EN": "master a medium",
  "FR": "maîtriser un médium",
  "IEML": "e.j.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a92f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cbaddaaaa"
  ],
  "CLASS": "2",
  "EN": "go through the age cycle",
  "FR": "traverser le cycle des âges",
  "IEML": "wu.O:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220dd6653c32453c0a938")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bcaddaaaa"
  ],
  "CLASS": "2",
  "EN": "go through the daily cycle",
  "FR": "traverser le cycle quotidien",
  "IEML": "wa.O:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220dd6653c32453c0a939")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bgahhaaaa"
  ],
  "CLASS": "2",
  "EN": "lack skill",
  "FR": "manquer d'habileté",
  "IEML": "e.M:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("55d220dd6653c32453c0a948")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "beaceaaaa"
  ],
  "CLASS": "2",
  "EN": "interrogate",
  "FR": "interroger",
  "IEML": "y.u.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a950")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cgaefaaaa"
  ],
  "CLASS": "2",
  "EN": "cut off transmission",
  "FR": "interrompre la transmission",
  "IEML": "i.b.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a952")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bfafeaaaa"
  ],
  "CLASS": "2",
  "EN": "break social bonds",
  "FR": "briser les liens sociaux",
  "IEML": "o.k.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a95c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bbagbaaaa"
  ],
  "CLASS": "2",
  "EN": "redefine objectives",
  "FR": "redéfinir les objectifs",
  "IEML": "wo.p.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a95d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "beabcaaaa"
  ],
  "CLASS": "2",
  "EN": "assume a corporate identity",
  "FR": "assumer une identité corporative",
  "IEML": "y.wa.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a966")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bfaiaaaaa"
  ],
  "CLASS": "2",
  "EN": "manipulate valuable objects",
  "FR": "manipuler des objets de valeur",
  "IEML": "o.F:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "5",
  "_id": ObjectId("55d220dd6653c32453c0a973")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "beafbaaaa"
  ],
  "CLASS": "2",
  "EN": "ponder possible meanings",
  "FR": "examiner les sens possibles",
  "IEML": "y.h.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a97a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dhabaaaaa"
  ],
  "CLASS": "2",
  "EN": "move centripetally",
  "FR": "bouger de façon centripète",
  "IEML": "O:M:.U:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dd6653c32453c0a97e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dhageaaaa"
  ],
  "CLASS": "2",
  "EN": "undermine truth",
  "FR": "miner la vérité",
  "IEML": "O:M:.d.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dd6653c32453c0a989")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ddagcaaaa"
  ],
  "CLASS": "2",
  "EN": "govern the technical system",
  "FR": "gouverner le système technique",
  "IEML": "O:O:.x.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220dd6653c32453c0a98a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "beahhaaaa"
  ],
  "CLASS": "2",
  "EN": "ignore",
  "FR": "ignorer",
  "IEML": "y.M:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("55d220dd6653c32453c0a991")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ceagbaaaa"
  ],
  "CLASS": "2",
  "EN": "explain one's subject",
  "FR": "expliquer son sujet",
  "IEML": "u.p.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a993")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "beaeaaaaa"
  ],
  "CLASS": "2",
  "EN": "sort | differentiate",
  "FR": "trier | différentier",
  "IEML": "y.S:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a994")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cgaeeaaaa"
  ],
  "CLASS": "2",
  "EN": "block interfaces",
  "FR": "bloquer les interfaces",
  "IEML": "i.s.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a995")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "beabeaaaa"
  ],
  "CLASS": "2",
  "EN": "mastering knowledge",
  "FR": "connaître",
  "IEML": "y.y.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a99b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "chaiaaaaa"
  ],
  "CLASS": "2",
  "EN": "move subjectively",
  "FR": "bouger subjectivement",
  "IEML": "A:M:.F:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "15",
  "_id": ObjectId("55d220dd6653c32453c0a99c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfacfaaaa"
  ],
  "CLASS": "2",
  "EN": "contract (to)",
  "FR": "contracter",
  "IEML": "a.a.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a99e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bfahhaaaa"
  ],
  "CLASS": "2",
  "EN": "darken human existence",
  "FR": "assombrir l'existence humaine",
  "IEML": "o.M:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("55d220dd6653c32453c0a9a2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dhaceaaaa"
  ],
  "CLASS": "2",
  "EN": "into expression (perform)",
  "FR": "dans l'expression (performer)",
  "IEML": "O:M:.u.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dd6653c32453c0a9aa")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cbaiaaaaa"
  ],
  "CLASS": "2",
  "EN": "feel | recognize shapes",
  "FR": "sentir | reconnaître les formes",
  "IEML": "wu.F:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "5",
  "_id": ObjectId("55d220dd6653c32453c0a9af")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bgaccaaaa"
  ],
  "CLASS": "2",
  "EN": "control birth",
  "FR": "contrôler la reproduction",
  "IEML": "e.we.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a9bc")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ddaecaaaa"
  ],
  "CLASS": "2",
  "EN": "govern the communication",
  "FR": "gouverner la communication",
  "IEML": "O:O:.g.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220dd6653c32453c0a9bf")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ccabfaaaa"
  ],
  "CLASS": "2",
  "EN": "renew objectives",
  "FR": "renouveler les objectifs",
  "IEML": "we.o.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a9c3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bcagfaaaa"
  ],
  "CLASS": "2",
  "EN": "cultivate one's physical energy",
  "FR": "cultiver son énergie physique",
  "IEML": "wa.f.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0a9c8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bcaefaaaa"
  ],
  "CLASS": "2",
  "EN": "express oneself through acts",
  "FR": "s'exprimer par les actes",
  "IEML": "wa.b.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0a9c9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cgabgaaaa"
  ],
  "CLASS": "2",
  "EN": "take",
  "FR": "prendre",
  "IEML": "i.e.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0a9ca")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ccabaaaaa"
  ],
  "CLASS": "2",
  "EN": "make silence | insulate from sound",
  "FR": "faire silence | isoler du son",
  "IEML": "we.U:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0a9dd")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cgacaaaaa"
  ],
  "CLASS": "2",
  "EN": "throw",
  "FR": "lancer",
  "IEML": "i.A:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0a9e0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bcaeeaaaa"
  ],
  "CLASS": "2",
  "EN": "have concern for action",
  "FR": "se soucier de l'action",
  "IEML": "wa.s.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0a9e3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cbabgaaaa"
  ],
  "CLASS": "2",
  "EN": "assess competences",
  "FR": "évaluer les compétences",
  "IEML": "wu.e.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0a9ee")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfabaaaaa"
  ],
  "CLASS": "2",
  "EN": "digest | assimilate",
  "FR": "digérer | assimiler",
  "IEML": "a.U:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0a9f0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bgaffaaaa"
  ],
  "CLASS": "2",
  "EN": "threaten",
  "FR": "menacer",
  "IEML": "e.m.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0a9f1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bbageaaaa"
  ],
  "CLASS": "2",
  "EN": "meditate on different theories",
  "FR": "méditer sur différentes théories",
  "IEML": "wo.d.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0a9f8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bcadhaaaa"
  ],
  "CLASS": "2",
  "EN": "master one's activity",
  "FR": "maîtriser son activité",
  "IEML": "wa.O:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220de6653c32453c0aa02")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bcabbaaaa"
  ],
  "CLASS": "2",
  "EN": "wake up",
  "FR": "s'éveiller",
  "IEML": "wa.wo.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa0b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ddacfaaaa"
  ],
  "CLASS": "2",
  "EN": "work on commitment",
  "FR": "travailler l'engagement",
  "IEML": "O:O:.a.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220de6653c32453c0aa10")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfafbaaaa"
  ],
  "CLASS": "2",
  "EN": "defend an interpretation",
  "FR": "défendre une interprétation",
  "IEML": "a.h.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa13")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ceaccaaaa"
  ],
  "CLASS": "2",
  "EN": "start a family",
  "FR": "fonder une famille",
  "IEML": "u.we.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa1b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "beaegaaaa"
  ],
  "CLASS": "2",
  "EN": "forget",
  "FR": "oublier",
  "IEML": "y.t.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa1c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfaceaaaa"
  ],
  "CLASS": "2",
  "EN": "keep one's word",
  "FR": "tenir sa promesse",
  "IEML": "a.u.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa23")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bfagfaaaa"
  ],
  "CLASS": "2",
  "EN": "inflict suffering",
  "FR": "faire souffrir",
  "IEML": "o.f.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa28")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ddadhaaaa"
  ],
  "CLASS": "2",
  "EN": "work",
  "FR": "travailler",
  "IEML": "O:O:.O:M:.-",
  "LAYER": "2",
  "PARADIGM": "1",
  "TAILLE": "24",
  "_id": ObjectId("55d220de6653c32453c0aa34")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dhacgaaaa"
  ],
  "CLASS": "2",
  "EN": "into concrete matters (perform)",
  "FR": "dans le concret (performer)",
  "IEML": "O:M:.i.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220de6653c32453c0aa3b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bbabbaaaa"
  ],
  "CLASS": "2",
  "EN": "be initiated",
  "FR": "être initié",
  "IEML": "wo.wo.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa3c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "beafcaaaa"
  ],
  "CLASS": "2",
  "EN": "examine one's obstacles",
  "FR": "examiner ses obstacles",
  "IEML": "y.c.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa42")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ceafeaaaa"
  ],
  "CLASS": "2",
  "EN": "use jargon",
  "FR": "parler jargon",
  "IEML": "u.k.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa5c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ccafeaaaa"
  ],
  "CLASS": "2",
  "EN": "set up social bonds",
  "FR": "constituer des liens sociaux",
  "IEML": "we.k.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa60")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bbaddaaaa"
  ],
  "CLASS": "2",
  "EN": "go through the symbolic cycle",
  "FR": "traverser le cycle symbolique",
  "IEML": "wo.O:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220de6653c32453c0aa73")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bbahdaaaa"
  ],
  "CLASS": "2",
  "EN": "monitor alternative frameworks",
  "FR": "remettre en jeu les cadres de l'activité",
  "IEML": "wo.M:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220de6653c32453c0aa79")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ddafgaaaa"
  ],
  "CLASS": "2",
  "EN": "tuning to the cosmos (provide resources for action by)",
  "FR": "résonance avec le cosmos (fournir des ressources à  l'action par la)",
  "IEML": "O:O:.n.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220de6653c32453c0aa7b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bcabfaaaa"
  ],
  "CLASS": "2",
  "EN": "stick to principles",
  "FR": "s'en tenir aux principes",
  "IEML": "wa.o.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa84")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cbahdaaaa"
  ],
  "CLASS": "2",
  "EN": "assess the frameworks of an activity",
  "FR": "évaluer les cadres d'une activité",
  "IEML": "wu.M:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220de6653c32453c0aa86")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ccahdaaaa"
  ],
  "CLASS": "2",
  "EN": "unify frameworks of the activity",
  "FR": "unifier les cadres de l'activité",
  "IEML": "we.M:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220de6653c32453c0aa88")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bfabaaaaa"
  ],
  "CLASS": "2",
  "EN": "receive",
  "FR": "recevoir",
  "IEML": "o.U:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa8c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cgacgaaaa"
  ],
  "CLASS": "2",
  "EN": "manufacture",
  "FR": "fabriquer",
  "IEML": "i.i.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa90")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bfaeeaaaa"
  ],
  "CLASS": "2",
  "EN": "have prejudices",
  "FR": "avoir des préjugés",
  "IEML": "o.s.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa93")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cbabaaaaa"
  ],
  "CLASS": "2",
  "EN": "hear | recognize auditive forms",
  "FR": "entendre | reconnaître des formes acoustiques",
  "IEML": "wu.U:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa95")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cbacgaaaa"
  ],
  "CLASS": "2",
  "EN": "test equipment",
  "FR": "tester l'équipement",
  "IEML": "wu.i.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa97")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bbafbaaaa"
  ],
  "CLASS": "2",
  "EN": "question the meaning of the activity",
  "FR": "remettre en jeu le sens de l'activité",
  "IEML": "wo.h.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa9d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bfaddaaaa"
  ],
  "CLASS": "2",
  "EN": "use law",
  "FR": "utiliser le droit",
  "IEML": "o.O:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220de6653c32453c0aa9e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cgaeaaaaa"
  ],
  "CLASS": "2",
  "EN": "lift",
  "FR": "soulever",
  "IEML": "i.S:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aab1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfaggaaaa"
  ],
  "CLASS": "2",
  "EN": "transgress",
  "FR": "transgresser",
  "IEML": "a.l.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aab4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cgabcaaaa"
  ],
  "CLASS": "2",
  "EN": "equip a company | an economic activity",
  "FR": "équiper une entreprise | une activité économique",
  "IEML": "i.wa.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aabb")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ceabcaaaa"
  ],
  "CLASS": "2",
  "EN": "marketing",
  "FR": "mettre en marché",
  "IEML": "u.wa.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aabe")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "beagbaaaa"
  ],
  "CLASS": "2",
  "EN": "ponder possible subjects",
  "FR": "examiner les sujets possibles",
  "IEML": "y.p.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aabf")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfabeaaaa"
  ],
  "CLASS": "2",
  "EN": "teach",
  "FR": "enseigner",
  "IEML": "a.y.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aac0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bfaefaaaa"
  ],
  "CLASS": "2",
  "EN": "misunderstand",
  "FR": "mal comprendre",
  "IEML": "o.b.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aac6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bbaceaaaa"
  ],
  "CLASS": "2",
  "EN": "follow conversation threads",
  "FR": "suivre les fils de la conversation",
  "IEML": "wo.u.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aacd")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ccagcaaaa"
  ],
  "CLASS": "2",
  "EN": "unify the technical system",
  "FR": "unifier le système technique",
  "IEML": "we.x.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aace")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dhacbaaaa"
  ],
  "CLASS": "2",
  "EN": "gain in citizen empowerment",
  "FR": "gagner en puissance citoyenne",
  "IEML": "O:M:.wu.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220de6653c32453c0aad4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ceagcaaaa"
  ],
  "CLASS": "2",
  "EN": "explain one's work",
  "FR": "expliquer son travail",
  "IEML": "u.x.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aae0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bgageaaaa"
  ],
  "CLASS": "2",
  "EN": "neglect the body",
  "FR": "négliger le corps",
  "IEML": "e.d.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aae1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ceaddaaaa"
  ],
  "CLASS": "2",
  "EN": "exhibit",
  "FR": "exposer",
  "IEML": "u.O:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220de6653c32453c0aae4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dhaffaaaa"
  ],
  "CLASS": "2",
  "EN": "undo an affective bond",
  "FR": "défaire un lien affectif",
  "IEML": "O:M:.m.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220de6653c32453c0aae7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bgaddaaaa"
  ],
  "CLASS": "2",
  "EN": "control",
  "FR": "contrôler",
  "IEML": "e.O:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220de6653c32453c0aafa")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ceaecaaaa"
  ],
  "CLASS": "2",
  "EN": "enunciate a statement",
  "FR": "énoncer une démarche",
  "IEML": "u.g.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aafd")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ccaecaaaa"
  ],
  "CLASS": "2",
  "EN": "unify communication",
  "FR": "unifier la communication",
  "IEML": "we.g.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab01")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cbafgaaaa"
  ],
  "CLASS": "2",
  "EN": "cultivate clarity of meaning",
  "FR": "cultiver la clarté du sens",
  "IEML": "wu.n.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab0f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bgacbaaaa"
  ],
  "CLASS": "2",
  "EN": "keep watch | organize transparency",
  "FR": "surveiller | organiser la transparence",
  "IEML": "e.wu.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab16")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ddaebaaaa"
  ],
  "CLASS": "2",
  "EN": "govern the symbolic system",
  "FR": "gouverner le système symbolique",
  "IEML": "O:O:.j.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220de6653c32453c0ab1b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ceaefaaaa"
  ],
  "CLASS": "2",
  "EN": "soliloquize",
  "FR": "soliloquer",
  "IEML": "u.b.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab1c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bcafeaaaa"
  ],
  "CLASS": "2",
  "EN": "act for the sake of society | of community",
  "FR": "agir pour la société | pour la communauté",
  "IEML": "wa.k.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab1f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ddahhaaaa"
  ],
  "CLASS": "2",
  "EN": "provide resources for action",
  "FR": "fournir des ressources à  l'action",
  "IEML": "O:O:.M:M:.-",
  "LAYER": "2",
  "PARADIGM": "1",
  "TAILLE": "36",
  "_id": ObjectId("55d220de6653c32453c0ab29")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cgafgaaaa"
  ],
  "CLASS": "2",
  "EN": "provoke an accident",
  "FR": "provoquer un accident",
  "IEML": "i.n.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab48")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bgabgaaaa"
  ],
  "CLASS": "2",
  "EN": "exercise a competence",
  "FR": "exercer une compétence",
  "IEML": "e.e.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab4c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bcahhaaaa"
  ],
  "CLASS": "2",
  "EN": "strength of action (cultivate)",
  "FR": "force de l'action (cultiver la)",
  "IEML": "wa.M:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("55d220de6653c32453c0ab52")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bbacgaaaa"
  ],
  "CLASS": "2",
  "EN": "choose equipment",
  "FR": "choisir l'équipement",
  "IEML": "wo.i.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab58")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ccaiaaaaa"
  ],
  "CLASS": "2",
  "EN": "shut off sensorimotricity",
  "FR": "interrompre la sensori-motricité",
  "IEML": "we.F:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "5",
  "_id": ObjectId("55d220de6653c32453c0ab59")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bfafgaaaa"
  ],
  "CLASS": "2",
  "EN": "be narrow-minded",
  "FR": "être fermé d'esprit",
  "IEML": "o.n.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab5d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ccaegaaaa"
  ],
  "CLASS": "2",
  "EN": "manage one's timetable",
  "FR": "régler son emploi du temps",
  "IEML": "we.t.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab63")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfaffaaaa"
  ],
  "CLASS": "2",
  "EN": "give up | forsake",
  "FR": "abandonner un projet | une personne",
  "IEML": "a.m.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab69")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "beafeaaaa"
  ],
  "CLASS": "2",
  "EN": "ignore relations",
  "FR": "ignorer les relations",
  "IEML": "y.k.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab74")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfacbaaaa"
  ],
  "CLASS": "2",
  "EN": "lead a political action",
  "FR": "mener une action politique",
  "IEML": "a.wu.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab77")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dhacfaaaa"
  ],
  "CLASS": "2",
  "EN": "into social relation (perform)",
  "FR": "dans le rapport social (performer)",
  "IEML": "O:M:.a.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220de6653c32453c0ab7a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ccafcaaaa"
  ],
  "CLASS": "2",
  "EN": "bring the community together",
  "FR": "rassembler la communauté",
  "IEML": "we.c.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab89")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ceaeeaaaa"
  ],
  "CLASS": "2",
  "EN": "disfigure | deface",
  "FR": "défigurer | rendre illisible",
  "IEML": "u.s.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab8e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cgacfaaaa"
  ],
  "CLASS": "2",
  "EN": "buy",
  "FR": "acheter",
  "IEML": "i.a.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab90")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bfacbaaaa"
  ],
  "CLASS": "2",
  "EN": "use criminal law",
  "FR": "utiliser le droit pénal",
  "IEML": "o.wu.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab97")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ccaddaaaa"
  ],
  "CLASS": "2",
  "EN": "go through the reproductive cycle",
  "FR": "traverser le cycle reproducteur",
  "IEML": "we.O:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220de6653c32453c0ab9c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ddagfaaaa"
  ],
  "CLASS": "2",
  "EN": "relation to the body (provide resources for action through the)",
  "FR": "rapport au corps (fournir des ressources à  l'action par le)",
  "IEML": "O:O:.f.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220de6653c32453c0abac")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bcaecaaaa"
  ],
  "CLASS": "2",
  "EN": "improve the communication system",
  "FR": "perfectionner le système de communication",
  "IEML": "wa.g.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abb0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cbacbaaaa"
  ],
  "CLASS": "2",
  "EN": "be mature",
  "FR": "être mûr",
  "IEML": "wu.wu.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abb3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cbacfaaaa"
  ],
  "CLASS": "2",
  "EN": "discern characters",
  "FR": "discerner les caractères",
  "IEML": "wu.a.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abb6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cgahhaaaa"
  ],
  "CLASS": "2",
  "EN": "destroy technically",
  "FR": "détruire techniquement",
  "IEML": "i.M:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("55d220de6653c32453c0abb9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bcagcaaaa"
  ],
  "CLASS": "2",
  "EN": "improve the technical system",
  "FR": "perfectionner le système technique",
  "IEML": "wa.x.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abc4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dhaddaaaa"
  ],
  "CLASS": "2",
  "EN": "gain empowerment",
  "FR": "gagner en puissance",
  "IEML": "O:M:.O:O:.-",
  "LAYER": "2",
  "PARADIGM": "1",
  "TAILLE": "24",
  "_id": ObjectId("55d220de6653c32453c0abca")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bgacgaaaa"
  ],
  "CLASS": "2",
  "EN": "give",
  "FR": "donner",
  "IEML": "e.i.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abcd")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfageaaaa"
  ],
  "CLASS": "2",
  "EN": "be superficial",
  "FR": "être superficiel",
  "IEML": "a.d.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abcf")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bbaffaaaa"
  ],
  "CLASS": "2",
  "EN": "change emotional patterns",
  "FR": "changer les réflexes émotionnels",
  "IEML": "wo.m.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abdc")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bfaebaaaa"
  ],
  "CLASS": "2",
  "EN": "choose a mode of expression",
  "FR": "choisir un mode d'expression",
  "IEML": "o.j.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abdd")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ccagbaaaa"
  ],
  "CLASS": "2",
  "EN": "unify objectives",
  "FR": "unifier les objectifs",
  "IEML": "we.p.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abef")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "beaecaaaa"
  ],
  "CLASS": "2",
  "EN": "ponder possible statements",
  "FR": "envisager les démarches possibles",
  "IEML": "y.g.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abf9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "beagaaaaa"
  ],
  "CLASS": "2",
  "EN": "dig | pierce | sculpt",
  "FR": "creuser | percer | sculpter",
  "IEML": "y.T:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abfa")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "beabbaaaa"
  ],
  "CLASS": "2",
  "EN": "assume the personal responsibility of a work",
  "FR": "assumer la responsabilité personnelle d'une oeuvre",
  "IEML": "y.wo.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abfd")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dhabgaaaa"
  ],
  "CLASS": "2",
  "EN": "into competency (perform)",
  "FR": "dans la competence (performer)",
  "IEML": "O:M:.e.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220de6653c32453c0ac00")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ceabfaaaa"
  ],
  "CLASS": "2",
  "EN": "adhere to ideas",
  "FR": "adhérer à  des idées",
  "IEML": "u.o.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ac0a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "beagcaaaa"
  ],
  "CLASS": "2",
  "EN": "review possible methods",
  "FR": "passer en revue les méthodes possibles",
  "IEML": "y.x.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac0d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dhaebaaaa"
  ],
  "CLASS": "2",
  "EN": "work on the medium",
  "FR": "travailler le médium",
  "IEML": "O:M:.j.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220df6653c32453c0ac0e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cbagfaaaa"
  ],
  "CLASS": "2",
  "EN": "immerse oneself in sensations",
  "FR": "s'immerger dans les sensations",
  "IEML": "wu.f.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac10")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "beaefaaaa"
  ],
  "CLASS": "2",
  "EN": "not be able to abstract",
  "FR": "ne pas abstraire",
  "IEML": "y.b.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac19")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cgaceaaaa"
  ],
  "CLASS": "2",
  "EN": "borrow",
  "FR": "emprunter",
  "IEML": "i.u.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac2b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfaecaaaa"
  ],
  "CLASS": "2",
  "EN": "commit oneself to a statement",
  "FR": "s'engager dans une démarche",
  "IEML": "a.g.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac2e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ceaebaaaa"
  ],
  "CLASS": "2",
  "EN": "analyze one's language",
  "FR": "analyser son langage",
  "IEML": "u.j.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac2f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bcafcaaaa"
  ],
  "CLASS": "2",
  "EN": "renew the community",
  "FR": "renouveler la communauté",
  "IEML": "wa.c.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac36")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfagcaaaa"
  ],
  "CLASS": "2",
  "EN": "get involved in one's work",
  "FR": "s'impliquer dans son travail",
  "IEML": "a.x.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac39")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cbadhaaaa"
  ],
  "CLASS": "2",
  "EN": "exert critical judgement",
  "FR": "exercer son jugement critique",
  "IEML": "wu.O:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220df6653c32453c0ac45")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ccadhaaaa"
  ],
  "CLASS": "2",
  "EN": "renew the activity",
  "FR": "renouveler son activité",
  "IEML": "we.O:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220df6653c32453c0ac46")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ccabeaaaa"
  ],
  "CLASS": "2",
  "EN": "rebuild knowledge",
  "FR": "reconstruire les savoirs",
  "IEML": "we.y.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac51")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bbabcaaaa"
  ],
  "CLASS": "2",
  "EN": "celebrate",
  "FR": "célébrer",
  "IEML": "wo.wa.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac53")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bcaegaaaa"
  ],
  "CLASS": "2",
  "EN": "take risks",
  "FR": "prendre des risques",
  "IEML": "wa.t.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac54")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bgagbaaaa"
  ],
  "CLASS": "2",
  "EN": "be at the proper level for a subject",
  "FR": "être au niveau approprié pour un sujet",
  "IEML": "e.p.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac5b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dhabcaaaa"
  ],
  "CLASS": "2",
  "EN": "gain in economic power",
  "FR": "gagner en puissance économique",
  "IEML": "O:M:.wa.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220df6653c32453c0ac5c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bbacfaaaa"
  ],
  "CLASS": "2",
  "EN": "find one's rightful place",
  "FR": "trouver sa juste place",
  "IEML": "wo.a.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac5d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bfahdaaaa"
  ],
  "CLASS": "2",
  "EN": "orient a production",
  "FR": "orienter une production",
  "IEML": "o.M:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220df6653c32453c0ac5f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfaddaaaa"
  ],
  "CLASS": "2",
  "EN": "create | initiate",
  "FR": "créer | initier",
  "IEML": "a.O:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220df6653c32453c0ac67")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ddageaaaa"
  ],
  "CLASS": "2",
  "EN": "quest for truth (provide resources for action through)",
  "FR": "quête de vérité (fournir des ressources à  l'action par la)",
  "IEML": "O:O:.d.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220df6653c32453c0ac74")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ccaggaaaa"
  ],
  "CLASS": "2",
  "EN": "increase one's working capacity",
  "FR": "augmenter sa capacité de travail",
  "IEML": "we.l.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac7a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "beaeeaaaa"
  ],
  "CLASS": "2",
  "EN": "neglect intellectual discipline",
  "FR": "négliger la discipline intellectuelle",
  "IEML": "y.s.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac7e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bfabgaaaa"
  ],
  "CLASS": "2",
  "EN": "specify",
  "FR": "spécifier",
  "IEML": "o.e.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac89")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "beaiaaaaa"
  ],
  "CLASS": "2",
  "EN": "perform a topological act",
  "FR": "accomplir un acte topologique",
  "IEML": "y.F:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "5",
  "_id": ObjectId("55d220df6653c32453c0ac93")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cgafbaaaa"
  ],
  "CLASS": "2",
  "EN": "elaborate an interpretation",
  "FR": "élaborer une interprétation",
  "IEML": "i.h.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0aca3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dhafgaaaa"
  ],
  "CLASS": "2",
  "EN": "undo a world",
  "FR": "défaire un monde",
  "IEML": "O:M:.n.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220df6653c32453c0aca9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cbaebaaaa"
  ],
  "CLASS": "2",
  "EN": "assess the symbolic system in use",
  "FR": "évaluer le système symbolique en usage",
  "IEML": "wu.j.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0acb0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ceagfaaaa"
  ],
  "CLASS": "2",
  "EN": "shun one's sensations | anesthetize",
  "FR": "fuir ses sensations | anesthésier",
  "IEML": "u.f.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0acc0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cgabeaaaa"
  ],
  "CLASS": "2",
  "EN": "compute",
  "FR": "computer",
  "IEML": "i.y.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0acc1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfafeaaaa"
  ],
  "CLASS": "2",
  "EN": "stir up conflict",
  "FR": "attiser le conflit",
  "IEML": "a.k.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0acc2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bbaccaaaa"
  ],
  "CLASS": "2",
  "EN": "mourn",
  "FR": "déplorer la perte",
  "IEML": "wo.we.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0acd2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ccaceaaaa"
  ],
  "CLASS": "2",
  "EN": "update one's documentation",
  "FR": "mettre à  jour sa documentation",
  "IEML": "we.u.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0acdb")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ddaffaaaa"
  ],
  "CLASS": "2",
  "EN": "emotional fluidity (provide resources for action through)",
  "FR": "fluidité émotionnelle (fournir des ressources à  l'action par la)",
  "IEML": "O:O:.m.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220df6653c32453c0acdf")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dhadaaaaa"
  ],
  "CLASS": "2",
  "EN": "move in relation to center",
  "FR": "bouger en relation à  un centre",
  "IEML": "O:M:.O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "12",
  "_id": ObjectId("55d220df6653c32453c0ace0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "beafaaaaa"
  ],
  "CLASS": "2",
  "EN": "tie | attach",
  "FR": "nouer | attacher",
  "IEML": "y.B:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ace4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bcagbaaaa"
  ],
  "CLASS": "2",
  "EN": "meet the objectives",
  "FR": "atteindre les objectifs",
  "IEML": "wa.p.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ace7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bbabgaaaa"
  ],
  "CLASS": "2",
  "EN": "identify competences",
  "FR": "identifier les compétences",
  "IEML": "wo.e.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0acf3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bgaegaaaa"
  ],
  "CLASS": "2",
  "EN": "offend",
  "FR": "offenser",
  "IEML": "e.t.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0acf4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ccafbaaaa"
  ],
  "CLASS": "2",
  "EN": "unify the meaning of the activity",
  "FR": "unifier le sens de l'activité",
  "IEML": "we.h.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad05")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dhaccaaaa"
  ],
  "CLASS": "2",
  "EN": "gain in family empowerment",
  "FR": "gagner en puissance familiale",
  "IEML": "O:M:.we.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220df6653c32453c0ad07")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dhahhaaaa"
  ],
  "CLASS": "2",
  "EN": "undermine human development",
  "FR": "saper le développement humain",
  "IEML": "O:M:.M:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "54",
  "_id": ObjectId("55d220df6653c32453c0ad12")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "beabfaaaa"
  ],
  "CLASS": "2",
  "EN": "establish priorities",
  "FR": "établir des priorités",
  "IEML": "y.o.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad14")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bfacfaaaa"
  ],
  "CLASS": "2",
  "EN": "lead",
  "FR": "mener | diriger",
  "IEML": "o.a.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad21")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bgabaaaaa"
  ],
  "CLASS": "2",
  "EN": "pull",
  "FR": "tirer",
  "IEML": "e.U:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad29")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bcabcaaaa"
  ],
  "CLASS": "2",
  "EN": "strive",
  "FR": "s'activer",
  "IEML": "wa.wa.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad2d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cgaggaaaa"
  ],
  "CLASS": "2",
  "EN": "be caught in a trap",
  "FR": "tomber dans un piège",
  "IEML": "i.l.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad3b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bgafcaaaa"
  ],
  "CLASS": "2",
  "EN": "prepare oneself for change",
  "FR": "se préparer au changement",
  "IEML": "e.c.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad3f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bgaaaaaaabfaaaaaaaccafbaaaa"
  ],
  "CLASS": "2",
  "EN": "establish norms & standards",
  "FR": "poser des normes & standards",
  "IEML": "e.-o.-we.h.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a560")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dhaaaaaaacgaaaaaaaccafbaaaa"
  ],
  "CLASS": "2",
  "EN": "strengthen the equipment",
  "FR": "renforcer l'équipement",
  "IEML": "O:M:.-i.-we.h.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dc6653c32453c0a5d4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cgaaaaaaadhaaaaaaaccafbaaaa"
  ],
  "CLASS": "2",
  "EN": "exploit equipment",
  "FR": "exploiter les équipements",
  "IEML": "i.-O:M:.-we.h.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dc6653c32453c0a5d6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "beaaaaaaabfaaaaaaaccafbaaaa"
  ],
  "CLASS": "2",
  "EN": "define problems",
  "FR": "définir les problèmes",
  "IEML": "y.-o.-we.h.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6dc")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "beaaaaaaaceaaaaaaaccafbaaaa"
  ],
  "CLASS": "2",
  "EN": "record a work of the mind",
  "FR": "enregistrer une œuvre de l'esprit",
  "IEML": "y.-u.-we.h.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a75c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bgaaaaaaabeaaaaaaaccafbaaaa"
  ],
  "CLASS": "2",
  "EN": "provide tools for research",
  "FR": "outiller la recherche",
  "IEML": "e.-y.-we.h.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a77c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cgaaaaaaaceaaaaaaaccafbaaaa"
  ],
  "CLASS": "2",
  "EN": "speak out",
  "FR": "prendre la parole",
  "IEML": "i.-u.-we.h.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7af")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "beaaaaaaacgaaaaaaaccafbaaaa"
  ],
  "CLASS": "2",
  "EN": "transfer knowledge in the practical field",
  "FR": "transférer des connaissances en pratique",
  "IEML": "y.-i.-we.h.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7da")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bgaaaaaaaceaaaaaaaccafbaaaa"
  ],
  "CLASS": "2",
  "EN": "provide tools for information search",
  "FR": "outiller la recherche d'information",
  "IEML": "e.-u.-we.h.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a822")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bgaaaaaaacgaaaaaaaccafbaaaa"
  ],
  "CLASS": "2",
  "EN": "draw | stimulate investments",
  "FR": "attirer | favoriser l'investissement",
  "IEML": "e.-i.-we.h.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a823")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bgaaaaaaacfaaaaaaaccafbaaaa"
  ],
  "CLASS": "2",
  "EN": "enrich the community",
  "FR": "enrichir la communauté",
  "IEML": "e.-a.-we.h.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a886")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dhaaaaaaadhaaaaaaaccafbaaaa"
  ],
  "CLASS": "2",
  "EN": "weave collective intelligence",
  "FR": "tisser l'intelligence collective",
  "IEML": "O:M:.-O:M:.-we.h.-'",
  "LAYER": "3",
  "PARADIGM": "1",
  "TAILLE": "36",
  "_id": ObjectId("55d220dd6653c32453c0a89e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfaaaaaaacfaaaaaaaccafbaaaa"
  ],
  "CLASS": "2",
  "EN": "create trust",
  "FR": "créer la confiance",
  "IEML": "a.-a.-we.h.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8a3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ceaaaaaaacgaaaaaaaccafbaaaa"
  ],
  "CLASS": "2",
  "EN": "invite someone to address | listen",
  "FR": "donner la parole | écouter",
  "IEML": "u.-i.-we.h.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8ce")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bfaaaaaaaceaaaaaaaccafbaaaa"
  ],
  "CLASS": "2",
  "EN": "filter information",
  "FR": "filtrer l'information",
  "IEML": "o.-u.-we.h.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a90b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ceaaaaaaabfaaaaaaaccafbaaaa"
  ],
  "CLASS": "2",
  "EN": "summarize for governance",
  "FR": "résumer en vue de la gouvernance",
  "IEML": "u.-o.-we.h.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a92a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bfaaaaaaabfaaaaaaaccafbaaaa"
  ],
  "CLASS": "2",
  "EN": "deepen a view",
  "FR": "approfondir la vision",
  "IEML": "o.-o.-we.h.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a960")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bfaaaaaaadhaaaaaaaccafbaaaa"
  ],
  "CLASS": "2",
  "EN": "exploit governance",
  "FR": "exploiter la gouvernance",
  "IEML": "o.-O:M:.-we.h.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dd6653c32453c0a984")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfaaaaaaabeaaaaaaaccafbaaaa"
  ],
  "CLASS": "2",
  "EN": "invest in research",
  "FR": "investir dans la recherche",
  "IEML": "a.-y.-we.h.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a98b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bfaaaaaaacgaaaaaaaccafbaaaa"
  ],
  "CLASS": "2",
  "EN": "orient production",
  "FR": "orienter la production",
  "IEML": "o.-i.-we.h.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a9a0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bfaaaaaaabgaaaaaaaccafbaaaa"
  ],
  "CLASS": "2",
  "EN": "educate",
  "FR": "éduquer",
  "IEML": "o.-e.-we.h.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa08")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ceaaaaaaaceaaaaaaaccafbaaaa"
  ],
  "CLASS": "2",
  "EN": "bring consistency",
  "FR": "mettre en cohérence",
  "IEML": "u.-u.-we.h.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa0f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bfaaaaaaabeaaaaaaaccafbaaaa"
  ],
  "CLASS": "2",
  "EN": "orient research",
  "FR": "orienter la recherche",
  "IEML": "o.-y.-we.h.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa7c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfaaaaaaabfaaaaaaaccafbaaaa"
  ],
  "CLASS": "2",
  "EN": "delegate governance",
  "FR": "déléguer la gouvernance",
  "IEML": "a.-o.-we.h.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa94")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dhaaaaaaaceaaaaaaaccafbaaaa"
  ],
  "CLASS": "2",
  "EN": "strengthen communication",
  "FR": "renforcer la communication",
  "IEML": "O:M:.-u.-we.h.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220de6653c32453c0aacc")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cgaaaaaaacgaaaaaaaccafbaaaa"
  ],
  "CLASS": "2",
  "EN": "guarantee compatibility",
  "FR": "assurer la compatibilité",
  "IEML": "i.-i.-we.h.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aad8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cgaaaaaaabfaaaaaaaccafbaaaa"
  ],
  "CLASS": "2",
  "EN": "create opportunities",
  "FR": "créer des opportunités",
  "IEML": "i.-o.-we.h.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aad9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dhaaaaaaacfaaaaaaaccafbaaaa"
  ],
  "CLASS": "2",
  "EN": "strengthen social bond",
  "FR": "renforcer le lien social",
  "IEML": "O:M:.-a.-we.h.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220de6653c32453c0aade")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfaaaaaaaceaaaaaaaccafbaaaa"
  ],
  "CLASS": "2",
  "EN": "open public space",
  "FR": "ouvrir l'espace public",
  "IEML": "a.-u.-we.h.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aae8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfaaaaaaabgaaaaaaaccafbaaaa"
  ],
  "CLASS": "2",
  "EN": "cultivate human development",
  "FR": "cultiver le développement humain",
  "IEML": "a.-e.-we.h.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab93")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bfaaaaaaacfaaaaaaaccafbaaaa"
  ],
  "CLASS": "2",
  "EN": "assert cultural values",
  "FR": "affirmer des valeurs culturelles",
  "IEML": "o.-a.-we.h.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab96")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ceaaaaaaacfaaaaaaaccafbaaaa"
  ],
  "CLASS": "2",
  "EN": "cultivate collective memory",
  "FR": "cultiver la mémoire collective",
  "IEML": "u.-a.-we.h.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aba9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cgaaaaaaabgaaaaaaaccafbaaaa"
  ],
  "CLASS": "2",
  "EN": "invest in business",
  "FR": "investir dans les affaires",
  "IEML": "i.-e.-we.h.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abe7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dhaaaaaaabgaaaaaaaccafbaaaa"
  ],
  "CLASS": "2",
  "EN": "strengthen empowerment",
  "FR": "renforcer la puissance",
  "IEML": "O:M:.-e.-we.h.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220df6653c32453c0ac1a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ceaaaaaaadhaaaaaaaccafbaaaa"
  ],
  "CLASS": "2",
  "EN": "exploit communication",
  "FR": "exploiter la communication",
  "IEML": "u.-O:M:.-we.h.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220df6653c32453c0ac23")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfaaaaaaacgaaaaaaaccafbaaaa"
  ],
  "CLASS": "2",
  "EN": "organize the work",
  "FR": "organiser le travail",
  "IEML": "a.-i.-we.h.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac77")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ceaaaaaaabeaaaaaaaccafbaaaa"
  ],
  "CLASS": "2",
  "EN": "specify information",
  "FR": "préciser l'information",
  "IEML": "u.-y.-we.h.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac88")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfaaaaaaadhaaaaaaaccafbaaaa"
  ],
  "CLASS": "2",
  "EN": "appreciate people",
  "FR": "valoriser les personnes",
  "IEML": "a.-O:M:.-we.h.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220df6653c32453c0ad34")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "beaebaaaa"
  ],
  "CLASS": "2",
  "EN": "ponder possible media",
  "FR": "examiner les médias possibles",
  "IEML": "y.j.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad48")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dhaefaaaa"
  ],
  "CLASS": "2",
  "EN": "undo language",
  "FR": "défaire le  langage",
  "IEML": "O:M:.b.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220df6653c32453c0ad4c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "beaaaaaaabeaaaaaaaccafbaaaa"
  ],
  "CLASS": "2",
  "EN": "clarify knowledge",
  "FR": "clarifier la connaissance",
  "IEML": "y.-y.-we.h.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad51")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dhacaaaaa"
  ],
  "CLASS": "2",
  "EN": "move centrifugally",
  "FR": "bouger de façon centrifuge",
  "IEML": "O:M:.A:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220df6653c32453c0ad57")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cgaffaaaa"
  ],
  "CLASS": "2",
  "EN": "use weapons",
  "FR": "utiliser des armes",
  "IEML": "i.m.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad5c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfaccaaaa"
  ],
  "CLASS": "2",
  "EN": "help each other | help family",
  "FR": "s'entraider | aider sa famille",
  "IEML": "a.we.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad5f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ceaeaaaaa"
  ],
  "CLASS": "2",
  "EN": "fly | travel through air",
  "FR": "voler | voyager dans l'air",
  "IEML": "u.S:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad65")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bgaceaaaa"
  ],
  "CLASS": "2",
  "EN": "deliberate",
  "FR": "délibérer",
  "IEML": "e.u.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad69")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfagbaaaa"
  ],
  "CLASS": "2",
  "EN": "get involved in one's subject",
  "FR": "s'impliquer dans son sujet",
  "IEML": "a.p.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad6b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dhaeeaaaa"
  ],
  "CLASS": "2",
  "EN": "undermine thought",
  "FR": "miner la pensée",
  "IEML": "O:M:.s.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220df6653c32453c0ad6c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bgaiaaaaa"
  ],
  "CLASS": "2",
  "EN": "place | displace objects",
  "FR": "placer | déplacer des objets",
  "IEML": "e.F:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "5",
  "_id": ObjectId("55d220df6653c32453c0ad71")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ceacfaaaa"
  ],
  "CLASS": "2",
  "EN": "promise (to)",
  "FR": "promettre",
  "IEML": "u.a.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad73")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ddacgaaaa"
  ],
  "CLASS": "2",
  "EN": "work on equipment",
  "FR": "travailler l'équipement",
  "IEML": "O:O:.i.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220df6653c32453c0ad7a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "beaaaaaaacfaaaaaaaccafbaaaa"
  ],
  "CLASS": "2",
  "EN": "innovate in social matters",
  "FR": "innover en matière sociale",
  "IEML": "y.-a.-we.h.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad7d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfahdaaaa"
  ],
  "CLASS": "2",
  "EN": "commit to a work",
  "FR": "s'engager dans une oeuvre",
  "IEML": "a.M:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220df6653c32453c0ad7f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bgahdaaaa"
  ],
  "CLASS": "2",
  "EN": "master a production",
  "FR": "maîtriser une production",
  "IEML": "e.M:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220df6653c32453c0ad80")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "beabaaaaa"
  ],
  "CLASS": "2",
  "EN": "fold | wrap",
  "FR": "plier | envelopper",
  "IEML": "y.U:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad81")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cbabcaaaa"
  ],
  "CLASS": "2",
  "EN": "be young",
  "FR": "être jeune",
  "IEML": "wu.wa.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad82")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bcaggaaaa"
  ],
  "CLASS": "2",
  "EN": "increase one's range of action",
  "FR": "étendre la portée de son action",
  "IEML": "wa.l.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad87")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bgaaaaaaadhaaaaaaaccafbaaaa"
  ],
  "CLASS": "2",
  "EN": "exploit empowerment",
  "FR": "exploiter la puissance",
  "IEML": "e.-O:M:.-we.h.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220df6653c32453c0ad89")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ddaeaaaaa"
  ],
  "CLASS": "2",
  "EN": "control visual experience",
  "FR": "contrôler l'expérience visuelle",
  "IEML": "O:O:.S:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220df6653c32453c0ad91")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ceaaaaaaabgaaaaaaaccafbaaaa"
  ],
  "CLASS": "2",
  "EN": "produce didactic materials",
  "FR": "produire du matériel didactique",
  "IEML": "u.-e.-we.h.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad95")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cgaccaaaa"
  ],
  "CLASS": "2",
  "EN": "equip a household",
  "FR": "équiper un ménage",
  "IEML": "i.we.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad9f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bcabeaaaa"
  ],
  "CLASS": "2",
  "EN": "master the knowledge",
  "FR": "maîtriser les savoirs",
  "IEML": "wa.y.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ada6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ccageaaaa"
  ],
  "CLASS": "2",
  "EN": "adopt a measurement system",
  "FR": "adopter un système de mesure",
  "IEML": "we.d.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0adae")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "beaaaaaaadhaaaaaaaccafbaaaa"
  ],
  "CLASS": "2",
  "EN": "exploit knowledge",
  "FR": "exploiter la connaissance",
  "IEML": "y.-O:M:.-we.h.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220df6653c32453c0adb0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bgafbaaaa"
  ],
  "CLASS": "2",
  "EN": "follow a method of interpretation",
  "FR": "suivre une méthode d'interprétation",
  "IEML": "e.h.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0adb5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ddabcaaaa"
  ],
  "CLASS": "2",
  "EN": "flourish",
  "FR": "fleurir",
  "IEML": "O:O:.wa.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220df6653c32453c0adb7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cbabfaaaa"
  ],
  "CLASS": "2",
  "EN": "question oneself",
  "FR": "se remettre en question",
  "IEML": "wu.o.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0adb9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bbaebaaaa"
  ],
  "CLASS": "2",
  "EN": "consider other symbolic systems",
  "FR": "envisager d'autres systèmes symboliques",
  "IEML": "wo.j.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0adbf")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bfaffaaaa"
  ],
  "CLASS": "2",
  "EN": "lack empathy | compassion",
  "FR": "manquer d'empathie | de compassion",
  "IEML": "o.m.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0adc5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bcaccaaaa"
  ],
  "CLASS": "2",
  "EN": "fall asleep",
  "FR": "s'endormir",
  "IEML": "wa.we.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0adcf")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bfaccaaaa"
  ],
  "CLASS": "2",
  "EN": "use family law",
  "FR": "utiliser le droit de la famille",
  "IEML": "o.we.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0add2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cbaefaaaa"
  ],
  "CLASS": "2",
  "EN": "develop poetic sensitivity",
  "FR": "développer la sensibilité poétique",
  "IEML": "wu.b.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0add3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cgaaaaaaabeaaaaaaaccafbaaaa"
  ],
  "CLASS": "2",
  "EN": "provide tools for thought",
  "FR": "outiller la pensée",
  "IEML": "i.-y.-we.h.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0addc")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "beagfaaaa"
  ],
  "CLASS": "2",
  "EN": "intoxicate | deceive",
  "FR": "intoxiquer | tromper",
  "IEML": "y.f.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0addd")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dhagfaaaa"
  ],
  "CLASS": "2",
  "EN": "weaken life",
  "FR": "affaiblir la vie",
  "IEML": "O:M:.f.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220df6653c32453c0ade3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ceafgaaaa"
  ],
  "CLASS": "2",
  "EN": "take refuge in anonymity | faking an identity",
  "FR": "se réfugier dans l'anonymat | présenter une fausse identité",
  "IEML": "u.n.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0aded")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfabcaaaa"
  ],
  "CLASS": "2",
  "EN": "create a company",
  "FR": "créer une entreprise",
  "IEML": "a.wa.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0adee")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ceacaaaaa"
  ],
  "CLASS": "2",
  "EN": "go",
  "FR": "aller",
  "IEML": "u.A:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0adf6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bgabeaaaa"
  ],
  "CLASS": "2",
  "EN": "synthesize",
  "FR": "faire la synthèse",
  "IEML": "e.y.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0adfa")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfaegaaaa"
  ],
  "CLASS": "2",
  "EN": "imitate | plagiarize",
  "FR": "imiter | plagier",
  "IEML": "a.t.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0adfb")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "beahdaaaa"
  ],
  "CLASS": "2",
  "EN": "ponder possibilities",
  "FR": "examiner les possibles",
  "IEML": "y.M:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220df6653c32453c0ae07")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ddabgaaaa"
  ],
  "CLASS": "2",
  "EN": "work on skills",
  "FR": "travailler les compétences",
  "IEML": "O:O:.e.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220df6653c32453c0ae12")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cbaccaaaa"
  ],
  "CLASS": "2",
  "EN": "grow old",
  "FR": "vieillir",
  "IEML": "wu.we.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae13")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ccaffaaaa"
  ],
  "CLASS": "2",
  "EN": "cultivate emotional equilibrium",
  "FR": "cultiver l'équilibre émotionnel",
  "IEML": "we.m.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae17")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bcafbaaaa"
  ],
  "CLASS": "2",
  "EN": "deepen the meaning of the activity",
  "FR": "approfondir le sens de l'activité",
  "IEML": "wa.h.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae19")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ddacaaaaa"
  ],
  "CLASS": "2",
  "EN": "control tactile experience",
  "FR": "contrôler l'expérience tactile",
  "IEML": "O:O:.A:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220df6653c32453c0ae1b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bcageaaaa"
  ],
  "CLASS": "2",
  "EN": "experiment",
  "FR": "expérimenter",
  "IEML": "wa.d.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae1d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bgaggaaaa"
  ],
  "CLASS": "2",
  "EN": "undertake an impractical act",
  "FR": "entreprendre une action irréaliste",
  "IEML": "e.l.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae20")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfaeaaaaa"
  ],
  "CLASS": "2",
  "EN": "breathe",
  "FR": "respirer",
  "IEML": "a.S:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae21")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cgadhaaaa"
  ],
  "CLASS": "2",
  "EN": "on a concrete basis (perform)",
  "FR": "sur une base concrète (performer)",
  "IEML": "i.O:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220df6653c32453c0ae2d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ccabbaaaa"
  ],
  "CLASS": "2",
  "EN": "be born",
  "FR": "naître",
  "IEML": "we.wo.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae30")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cbaeeaaaa"
  ],
  "CLASS": "2",
  "EN": "develop intellectual sensitivity",
  "FR": "développer la sensibilité intellectuelle",
  "IEML": "wu.s.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae61")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bgaaaaaaabgaaaaaaaccafbaaaa"
  ],
  "CLASS": "2",
  "EN": "solve problems",
  "FR": "résoudre les problèmes",
  "IEML": "e.-e.-we.h.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae4d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bfacgaaaa"
  ],
  "CLASS": "2",
  "EN": "make an application",
  "FR": "poser une candidature",
  "IEML": "o.i.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae47")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bbafgaaaa"
  ],
  "CLASS": "2",
  "EN": "change world representation",
  "FR": "changer de représentation du monde",
  "IEML": "wo.n.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae40")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ccagaaaaa"
  ],
  "CLASS": "2",
  "EN": "create foundations | an unmovable base, insulate from movement",
  "FR": "poser des fondations | poser une base immuable, isoler du mouvement",
  "IEML": "we.T:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae3b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cgageaaaa"
  ],
  "CLASS": "2",
  "EN": "break down | wreck a mechanism",
  "FR": "dérégler | détraquer un mécanisme",
  "IEML": "i.d.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae39")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bcaceaaaa"
  ],
  "CLASS": "2",
  "EN": "find | show information",
  "FR": "trouver | indiquer l'information",
  "IEML": "wa.u.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae35")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dhaeaaaaa"
  ],
  "CLASS": "2",
  "EN": "move-blow",
  "FR": "bouger-souffler",
  "IEML": "O:M:.S:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("566222c64a4bb3796fdce425")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dhafaaaaa"
  ],
  "CLASS": "2",
  "EN": "move-leak",
  "FR": "bouger-couler",
  "IEML": "O:M:.B:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("566222f74a4bb3796fdce42a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dhagaaaaa"
  ],
  "CLASS": "2",
  "EN": "move-stick",
  "FR": "bouger-coller",
  "IEML": "O:M:.T:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("566223284a4bb3796fdce42f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egabgaaaaffaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "dramatic representation",
  "FR": "représentation dramatique",
  "IEML": "t.e.-m.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a55b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egacgaaaaeeacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "vehicle",
  "FR": "véhicule",
  "IEML": "t.i.-s.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a55c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gcaegaaaa"
  ],
  "CLASS": "4",
  "EN": "deficiency in coordination | deficiency in resources management",
  "FR": "défaut de coordination | défaut de gestion des ressources",
  "IEML": "x.t.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a562")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgaebaaaa"
  ],
  "CLASS": "4",
  "EN": "sustainable transformation of language",
  "FR": "transformation durable du langage",
  "IEML": "n.j.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a563")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efabgaaaaeeaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "visual culture",
  "FR": "culture visuelle",
  "IEML": "b.e.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a564")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geacgaaaaffacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "awarded | decorated",
  "FR": "primé | décoré",
  "IEML": "d.i.-m.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a565")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaceaaaa"
  ],
  "CLASS": "4",
  "EN": "speech",
  "FR": "parole",
  "IEML": "b.u.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a566")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fcaefaaaa"
  ],
  "CLASS": "4",
  "EN": "language of exclusion or hate | discrimination based on prejudice",
  "FR": "langage d'exclusion ou de haine | discrimination basée sur des préjugés",
  "IEML": "c.b.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a56a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeacgaaaaefacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "multimedia",
  "FR": "multimédia",
  "IEML": "s.i.-b.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a56b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hdaebaaaa"
  ],
  "CLASS": "4",
  "EN": "transformation in knowledge",
  "FR": "transformation dans le savoir",
  "IEML": "M:O:.j.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dc6653c32453c0a56c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egacfaaaafeacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "public service",
  "FR": "fonction publique",
  "IEML": "t.a.-k.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a56d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egabfaaaageabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "relevant",
  "FR": "pertinent",
  "IEML": "t.o.-d.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a56e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "acacbaaaa"
  ],
  "CLASS": "1",
  "EN": "possessive masculine",
  "FR": "possessif masculin",
  "IEML": "E:A:.wu.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a571")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgabfaaaageabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "evaluation",
  "FR": "évaluation",
  "IEML": "n.o.-d.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a572")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgabgaaaaefacfaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in representing a group",
  "FR": "compétence en représentation d'un groupe",
  "IEML": "n.e.-b.a.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a573")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggaaaaaaaeaabaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "north",
  "FR": "nord",
  "IEML": "l.-S:.U:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a579")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geaceaaaafeaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "temple",
  "FR": "temple",
  "IEML": "d.u.-k.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a57a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffabfaaaagfabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "seduction",
  "FR": "séduction",
  "IEML": "m.o.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a57e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfabgaaaafgacgaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in extreme sports",
  "FR": "compétence en sports extrêmes",
  "IEML": "f.e.-n.i.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a57f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geacfaaaaegacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "savings",
  "FR": "épargne",
  "IEML": "d.a.-t.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a580")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhacfaaaa"
  ],
  "CLASS": "4",
  "EN": "making society",
  "FR": "faire société",
  "IEML": "M:M:.a.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("55d220dc6653c32453c0a581")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffacgaaaaegacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "protected",
  "FR": "protégé",
  "IEML": "m.i.-t.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a582")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gcafcaaaa"
  ],
  "CLASS": "4",
  "EN": "new acquisition",
  "FR": "nouvelle acquisition",
  "IEML": "x.c.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a583")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfacgaaaaefacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "medicated",
  "FR": "médicamenté",
  "IEML": "f.i.-b.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a584")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggabgaaaafgacgaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in tool design | competence in machine design",
  "FR": "compétence en conception d'outils | compétence en conception de machines",
  "IEML": "l.e.-n.i.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a585")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhabhaaaa"
  ],
  "CLASS": "4",
  "EN": "virtual human development",
  "FR": "développement humain virtuel",
  "IEML": "M:M:.U:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "27",
  "_id": ObjectId("55d220dc6653c32453c0a586")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gbagfaaaa"
  ],
  "CLASS": "4",
  "EN": "theft | unfair competition",
  "FR": "vol | concurrence déloyale",
  "IEML": "p.f.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a588")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "abaefaaaa"
  ],
  "CLASS": "1",
  "EN": "on",
  "FR": "sur",
  "IEML": "E:U:.b.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a753")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geacgaaaafgacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "steering device",
  "FR": "instrument de pilotage",
  "IEML": "d.i.-n.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a589")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfabfaaaagfabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "living",
  "FR": "vivant",
  "IEML": "f.o.-f.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a58c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geacfaaaagfacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "teacher",
  "FR": "enseignant",
  "IEML": "d.a.-f.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a58d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feabfaaaaggabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "instituted",
  "FR": "institué",
  "IEML": "k.o.-l.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a58f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geabgaaaafeacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "commercial transaction",
  "FR": "transaction commerciale",
  "IEML": "d.e.-k.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a590")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "acaceaaaa"
  ],
  "CLASS": "1",
  "EN": "expressing",
  "FR": "exprimant",
  "IEML": "E:A:.u.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a591")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfabfaaaaegabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "growth",
  "FR": "croissance",
  "IEML": "f.o.-t.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a595")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feacfaaaagfacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "meal",
  "FR": "repas",
  "IEML": "k.a.-f.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a596")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ebabgaaaa"
  ],
  "CLASS": "4",
  "EN": "obedience",
  "FR": "obéissance",
  "IEML": "j.e.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a598")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aff"
  ],
  "CLASS": "1",
  "EN": "usually | regularly",
  "FR": "généralement | régulièrement",
  "IEML": "E:B:B:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a599")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ecafeaaaa"
  ],
  "CLASS": "4",
  "EN": "lack of interest from the public | lack of interest for the medium",
  "FR": "désaffection du public | désaffection du médium",
  "IEML": "g.k.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a59f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeabfaaaaffabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "comical | funny",
  "FR": "comique | drôle",
  "IEML": "s.o.-m.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5a2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feafcaaaa"
  ],
  "CLASS": "4",
  "EN": "renewed social bond",
  "FR": "lien social renouvelé",
  "IEML": "k.c.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5a3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egabgaaaaegaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "augmented cognition",
  "FR": "cognition augmentée",
  "IEML": "t.e.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5a4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeabfaaaagfabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "embodied",
  "FR": "incarné",
  "IEML": "s.o.-f.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5a6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egabgaaaagfaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "original music",
  "FR": "musique originale",
  "IEML": "t.e.-f.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5a7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffacfaaaaefacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "game",
  "FR": "jeu",
  "IEML": "m.a.-b.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5a8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "adf"
  ],
  "CLASS": "1",
  "EN": "comparative medium",
  "FR": "medium comparatif",
  "IEML": "E:O:B:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("55d220dc6653c32453c0a5aa")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "acageaaaa"
  ],
  "CLASS": "1",
  "EN": "to the back",
  "FR": "vers l'arrière",
  "IEML": "E:A:.d.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5ac")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geabgaaaageacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "measurement",
  "FR": "mesure",
  "IEML": "d.e.-d.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5ad")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feaceaaaaegaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "omen | divinatory sign",
  "FR": "présage | signe divinatoire",
  "IEML": "k.u.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5ae")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeaceaaaageaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "legend",
  "FR": "légende",
  "IEML": "s.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5af")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geaceaaaaffaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "reflex",
  "FR": "réflexe",
  "IEML": "d.u.-m.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5b2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fbacgaaaa"
  ],
  "CLASS": "4",
  "EN": "acknowledgement of the facts",
  "FR": "reconnaissance des faits",
  "IEML": "h.i.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5b3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gbaeeaaaa"
  ],
  "CLASS": "4",
  "EN": "lack of means | situation of need | poverty",
  "FR": "manque de moyens | situation de besoin | pauvreté",
  "IEML": "p.s.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5b5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggaceaaaagfaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "tactile | kinesthetic",
  "FR": "tactile | kinesthésique",
  "IEML": "l.u.-f.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5b6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egacgaaaaggacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "city",
  "FR": "ville",
  "IEML": "t.i.-l.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5b9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egabfaaaagfabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "rhythm",
  "FR": "rythme",
  "IEML": "t.o.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5c0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fbahhaaaa"
  ],
  "CLASS": "4",
  "EN": "spiritual obstacle",
  "FR": "obstacle spirituel",
  "IEML": "h.M:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("55d220dc6653c32453c0a5c4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeacfaaaaffacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "marriage",
  "FR": "mariage",
  "IEML": "s.a.-m.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5c5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feacgaaaafgacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "workshop",
  "FR": "atelier",
  "IEML": "k.i.-n.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5c8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feabgaaaaefacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "credibility",
  "FR": "crédibilité",
  "IEML": "k.e.-b.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5ca")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeacfaaaaegacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "data",
  "FR": "donnée",
  "IEML": "s.a.-t.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5cb")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaaaaaaaeaacaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "color",
  "FR": "couleur",
  "IEML": "b.-S:.A:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5cc")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "agafcaaaa"
  ],
  "CLASS": "1",
  "EN": "state of a system",
  "FR": "état d'un système",
  "IEML": "E:T:.c.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5cd")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efadhaaaa"
  ],
  "CLASS": "4",
  "EN": "language factors",
  "FR": "facteurs de langage",
  "IEML": "b.O:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dc6653c32453c0a5ce")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ade"
  ],
  "CLASS": "1",
  "EN": "comparative minus",
  "FR": "moins comparatif",
  "IEML": "E:O:S:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("55d220dc6653c32453c0a5cf")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "afe"
  ],
  "CLASS": "1",
  "EN": "rarely",
  "FR": "rarement",
  "IEML": "E:B:S:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5d0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geabfaaaaefabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "described",
  "FR": "décrit",
  "IEML": "d.o.-b.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5d1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffabeaaaa"
  ],
  "CLASS": "4",
  "EN": "emotional intelligence",
  "FR": "intelligence émotionnelle",
  "IEML": "m.y.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5d3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgacfaaaafeacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "reformer",
  "FR": "réformateur",
  "IEML": "n.a.-k.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5d5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgabfaaaafeabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "religion",
  "FR": "religion",
  "IEML": "n.o.-k.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5d8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gcahhaaaa"
  ],
  "CLASS": "4",
  "EN": "technical obstacle",
  "FR": "obstacle technique",
  "IEML": "x.M:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("55d220dc6653c32453c0a5d9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffacfaaaaffacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "familiar",
  "FR": "familier",
  "IEML": "m.a.-m.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5dc")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fcaeeaaaa"
  ],
  "CLASS": "4",
  "EN": "fanaticism | ultraconservatism",
  "FR": "fanatisme | ultraconservatisme",
  "IEML": "c.s.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5dd")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efacfaaaaefacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "author",
  "FR": "auteur",
  "IEML": "b.a.-b.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5df")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeaceaaaafeaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "icon",
  "FR": "icône",
  "IEML": "s.u.-k.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5e1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efabgaaaaggaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "scientific comprehension",
  "FR": "compréhension scientifique",
  "IEML": "b.e.-l.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5e4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efacgaaaaefacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "ubiquitous",
  "FR": "ubiquitaire",
  "IEML": "b.i.-b.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5e5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geacbaaaa"
  ],
  "CLASS": "4",
  "EN": "aesthetic constraint",
  "FR": "contrainte esthétique",
  "IEML": "d.wu.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5e6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egabgaaaaefaceaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in eloquence",
  "FR": "compétence en éloquence",
  "IEML": "t.e.-b.u.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5ea")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gcagbaaaa"
  ],
  "CLASS": "4",
  "EN": "sharing",
  "FR": "partage",
  "IEML": "x.p.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5ed")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeabgaaaageaceaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in information search",
  "FR": "compétence en recherche d'information",
  "IEML": "s.e.-d.u.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5ef")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fcagfaaaa"
  ],
  "CLASS": "4",
  "EN": "personal failure | defeat",
  "FR": "échec | défaite personnelle",
  "IEML": "c.f.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5f2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geacgaaaaegacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "numbered | measured",
  "FR": "compté | mesuré",
  "IEML": "d.i.-t.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5f3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efabeaaaa"
  ],
  "CLASS": "4",
  "EN": "formal intelligence",
  "FR": "intelligence formelle",
  "IEML": "b.y.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5f5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgabfaaaafgabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "human",
  "FR": "humain",
  "IEML": "n.o.-n.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5f6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgaaaaaaagaabaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "air | wind",
  "FR": "air | vent",
  "IEML": "n.-T:.U:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5f7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feacfaaaaffacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "fraternity",
  "FR": "fraternité",
  "IEML": "k.a.-m.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5f9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aig"
  ],
  "CLASS": "1",
  "EN": "more",
  "FR": "plus",
  "IEML": "E:F:T:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "5",
  "_id": ObjectId("55d220dc6653c32453c0a5fa")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efabfaaaaeeabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "interpretation",
  "FR": "interprétation",
  "IEML": "b.o.-s.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5fb")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efabgaaaaefaceaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in interpreting | competence in guiding",
  "FR": "compétence en interprétariat | compétence en guidage",
  "IEML": "b.e.-b.u.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5fd")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egaaaaaaagaacaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "rainy season",
  "FR": "saison pluvieuse",
  "IEML": "t.-T:.A:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5fe")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffaccaaaa"
  ],
  "CLASS": "4",
  "EN": "acceptance of constraints",
  "FR": "acceptation des contraintes",
  "IEML": "m.we.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5ff")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggaebaaaa"
  ],
  "CLASS": "4",
  "EN": "influence network of an artistic work | influence network of a poetic work",
  "FR": "réseau d'influence dune œuvre artistique | réseau d'influence dune œuvre poétique",
  "IEML": "l.j.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a600")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffafbaaaa"
  ],
  "CLASS": "4",
  "EN": "coherence between speech and action",
  "FR": "cohérence entre actes et paroles",
  "IEML": "m.h.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a601")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "beaaaaaaabgaaaaaaaccafbaaaa"
  ],
  "CLASS": "2",
  "EN": "propose solutions",
  "FR": "proposer des solutions",
  "IEML": "y.-e.-we.h.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a602")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffaceaaaaegaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "masked | concealed",
  "FR": "masqué | dissimulé",
  "IEML": "m.u.-t.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a603")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efacgaaaafeacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "public place",
  "FR": "place publique",
  "IEML": "b.i.-k.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a604")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hdagfaaaa"
  ],
  "CLASS": "4",
  "EN": "personal obstacle",
  "FR": "obstacle personnel",
  "IEML": "M:O:.f.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dc6653c32453c0a605")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhabfaaaahhabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "anthropological qualities",
  "FR": "qualités anthropologiques",
  "IEML": "M:M:.o.-M:M:.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "81",
  "_id": ObjectId("55d220dc6653c32453c0a606")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggacfaaaaffacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "alliance",
  "FR": "alliance",
  "IEML": "l.a.-m.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a607")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhabgaaaa"
  ],
  "CLASS": "4",
  "EN": "know how",
  "FR": "savoir faire",
  "IEML": "M:M:.e.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("55d220dc6653c32453c0a60a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfacfaaaaefacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "musician",
  "FR": "musicien",
  "IEML": "f.a.-b.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a60b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeaaaaaaagaacaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "wet",
  "FR": "humide",
  "IEML": "s.-T:.A:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a60c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaaaaaaafaabaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "neat",
  "FR": "net",
  "IEML": "b.-B:.U:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a60d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feaceaaaageaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "aura",
  "FR": "aura",
  "IEML": "k.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a60f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feabgaaaaffacfaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in friendship with oneself",
  "FR": "compétence en amitié avec soi-même",
  "IEML": "k.e.-m.a.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a610")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffaceaaaaeeaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "fantasized",
  "FR": "fantasmé",
  "IEML": "m.u.-s.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a611")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffacfaaaagfacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "helper",
  "FR": "aidant",
  "IEML": "m.a.-f.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a612")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfaccaaaa"
  ],
  "CLASS": "4",
  "EN": "leisure | entertainment | recreation",
  "FR": "loisir | divertissement | récréation",
  "IEML": "f.we.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a617")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geaaaaaaaeaabaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "hard | rigid",
  "FR": "dur | rigide",
  "IEML": "d.-S:.U:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a619")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgacfaaaageacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "customer",
  "FR": "client",
  "IEML": "n.a.-d.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a61a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gbaefaaaa"
  ],
  "CLASS": "4",
  "EN": "bad reputation | rejection from the consumers",
  "FR": "mauvaise réputation | rejet par les consommateurs",
  "IEML": "p.b.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a61b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "agh"
  ],
  "CLASS": "1",
  "EN": "space distribution",
  "FR": "distribution dans l'espace",
  "IEML": "E:T:M:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("55d220dc6653c32453c0a61c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfabfaaaageabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "attention",
  "FR": "attention",
  "IEML": "f.o.-d.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a61e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfaceaaaafgaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "attribute",
  "FR": "attribut",
  "IEML": "f.u.-n.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a61f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egabfaaaaffabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "hope",
  "FR": "espérance",
  "IEML": "t.o.-m.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a620")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfabfaaaaffabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "passion",
  "FR": "passion",
  "IEML": "f.o.-m.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a621")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggacfaaaaegacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "atlas",
  "FR": "atlas",
  "IEML": "l.a.-t.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a624")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feaceaaaaffaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "stigmata",
  "FR": "stigmate",
  "IEML": "k.u.-m.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a626")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeacfaaaagfacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "psychotherapy",
  "FR": "psychothérapie",
  "IEML": "s.a.-f.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a627")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efabfaaaaggabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "transmission",
  "FR": "transmission",
  "IEML": "b.o.-l.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a628")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egacfaaaageacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "investment",
  "FR": "investissement",
  "IEML": "t.a.-d.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a629")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egabfaaaaggabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "simultaneous",
  "FR": "simultané",
  "IEML": "t.o.-l.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a62a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggaceaaaafeaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "miracle",
  "FR": "miracle",
  "IEML": "l.u.-k.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a62b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeacgaaaa"
  ],
  "CLASS": "4",
  "EN": "interface",
  "FR": "interface",
  "IEML": "s.i.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a62d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ebacgaaaa"
  ],
  "CLASS": "4",
  "EN": "strategy",
  "FR": "stratégie",
  "IEML": "j.i.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a62f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gbahdaaaa"
  ],
  "CLASS": "4",
  "EN": "transformation on ability basis",
  "FR": "transformation sur base de capacités",
  "IEML": "p.M:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dc6653c32453c0a630")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfahdaaaa"
  ],
  "CLASS": "4",
  "EN": "personal connection of a creation-innovation cycle",
  "FR": "connexion personnelle d'un cycle de création-innovation",
  "IEML": "f.M:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dc6653c32453c0a631")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "adagbaaaa"
  ],
  "CLASS": "1",
  "EN": "manner of definition",
  "FR": "manière de définition",
  "IEML": "E:O:.p.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("55d220dc6653c32453c0a632")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efabfaaaafgabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "poetry",
  "FR": "poésie",
  "IEML": "b.o.-n.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a633")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeacfaaaageacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "personal advice",
  "FR": "conseil personnel",
  "IEML": "s.a.-d.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a634")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feabfaaaageabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "honest",
  "FR": "honnête",
  "IEML": "k.o.-d.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a635")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egaecaaaa"
  ],
  "CLASS": "4",
  "EN": "traditional theme | recurring theme",
  "FR": "thème traditionnel | thème récurrent",
  "IEML": "t.g.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a636")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feacbaaaa"
  ],
  "CLASS": "4",
  "EN": "community of taste",
  "FR": "communauté de goût",
  "IEML": "k.wu.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a637")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aiabdaaaa"
  ],
  "CLASS": "1",
  "EN": "indifferent number",
  "FR": "nombre indifférent",
  "IEML": "E:F:.U:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "10",
  "_id": ObjectId("55d220dc6653c32453c0a638")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeabfaaaafgabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "meditated",
  "FR": "médité",
  "IEML": "s.o.-n.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a639")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feaecaaaa"
  ],
  "CLASS": "4",
  "EN": "re-created public | re-created media community",
  "FR": "public re-créé | communauté de média re-créée",
  "IEML": "k.g.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a63b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfabfaaaafgabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "step | gait",
  "FR": "pas | démarche",
  "IEML": "f.o.-n.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a63c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ecabfaaaa"
  ],
  "CLASS": "4",
  "EN": "expression of the unconscious",
  "FR": "expression de l'inconscient",
  "IEML": "g.o.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a63e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feaceaaaagfaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "sanctity | holiness",
  "FR": "sainteté",
  "IEML": "k.u.-f.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a63f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "afadhaaaa"
  ],
  "CLASS": "1",
  "EN": "present tense",
  "FR": "temps présent",
  "IEML": "E:B:.O:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dc6653c32453c0a642")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeacgaaaafgacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "cooling device",
  "FR": "dispositif de réfrigération",
  "IEML": "s.i.-n.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a643")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gbabfaaaa"
  ],
  "CLASS": "4",
  "EN": "contemplation",
  "FR": "contemplation",
  "IEML": "p.o.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a644")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfacfaaaaefacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "concert",
  "FR": "concert",
  "IEML": "f.a.-b.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a645")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfabgaaaafgacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "survival",
  "FR": "survie",
  "IEML": "f.e.-n.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a647")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fbaffaaaa"
  ],
  "CLASS": "4",
  "EN": "inconsistency between speech and act",
  "FR": "incohérence entre les paroles et les actes",
  "IEML": "h.m.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a649")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egaceaaaaefaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "text",
  "FR": "texte",
  "IEML": "t.u.-b.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a64a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geaceaaaaegaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "anchor",
  "FR": "ancre",
  "IEML": "d.u.-t.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a64b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aiaegaaaa"
  ],
  "CLASS": "1",
  "EN": "structure of exi-stance",
  "FR": "structure d'exi-stance",
  "IEML": "E:F:.t.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "5",
  "_id": ObjectId("5647d66bc1d763d245621bc4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aiafhaaaa"
  ],
  "CLASS": "1",
  "EN": "inter-stance (spatial situation)",
  "FR": "inter-stance (situation spatiale)",
  "IEML": "E:F:.B:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "15",
  "_id": ObjectId("564d0397c1d763d245621bca")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "afabbaaaa"
  ],
  "CLASS": "1",
  "EN": "second person singular",
  "FR": "deuxième personne singulier",
  "IEML": "E:B:.wo.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5c9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aeacgaaaa"
  ],
  "CLASS": "1",
  "EN": "future must do",
  "FR": "devoir faire au futur",
  "IEML": "E:S:.i.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a57b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "afabeaaaa"
  ],
  "CLASS": "1",
  "EN": "know now",
  "FR": "connaître maintenant",
  "IEML": "E:B:.y.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aaf0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aeagdaaaa"
  ],
  "CLASS": "1",
  "EN": "mereological role",
  "FR": "rôle méréologique",
  "IEML": "E:S:.T:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("565f4aefddd8757dcd0838a5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geabgaaaaefacgaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in the mastery of communication techniques",
  "FR": "compétence en la maîtrise techniques de communication",
  "IEML": "d.e.-b.i.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a64c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "abaebaaaa"
  ],
  "CLASS": "1",
  "EN": "by contrast | but | and yet | on the contrary",
  "FR": "par contraste | mais | pourtant | au contraire",
  "IEML": "E:U:.j.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a64d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egabfaaaaegabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "change",
  "FR": "changement",
  "IEML": "t.o.-t.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a64f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfabfaaaafeabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "rite",
  "FR": "rite",
  "IEML": "f.o.-k.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a650")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efabfaaaaegabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "promised",
  "FR": "promis",
  "IEML": "b.o.-t.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a651")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egabgaaaageaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "informational problem",
  "FR": "problématique informationnelle",
  "IEML": "t.e.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a654")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hba"
  ],
  "CLASS": "4",
  "EN": "virtual mutation",
  "FR": "mutation virtuelle",
  "IEML": "M:U:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("55d220dc6653c32453c0a655")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egagcaaaa"
  ],
  "CLASS": "4",
  "EN": "calendar of a project | budget of a project",
  "FR": "calendrier d'un projet | budget d'un projet",
  "IEML": "t.x.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a656")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feagcaaaa"
  ],
  "CLASS": "4",
  "EN": "renewed project team",
  "FR": "équipe de projet renouvelée",
  "IEML": "k.x.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a65b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeabbaaaa"
  ],
  "CLASS": "4",
  "EN": "meta-level",
  "FR": "méta-niveau",
  "IEML": "s.wo.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a65c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "afd"
  ],
  "CLASS": "1",
  "EN": "belief",
  "FR": "croyance",
  "IEML": "E:B:O:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("55d220dc6653c32453c0a65d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfabfaaaagfabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "body",
  "FR": "corps",
  "IEML": "f.o.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a65e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feacfaaaaegacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "administration | office",
  "FR": "administration | bureau",
  "IEML": "k.a.-t.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a65f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggabbaaaa"
  ],
  "CLASS": "4",
  "EN": "freedom of thought",
  "FR": "liberté de pensée",
  "IEML": "l.wo.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a660")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feaceaaaafeaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "divine",
  "FR": "divin",
  "IEML": "k.u.-k.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a661")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ebaddaaaa"
  ],
  "CLASS": "4",
  "EN": "language change",
  "FR": "changement de langage",
  "IEML": "j.O:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220dc6653c32453c0a662")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efafbaaaa"
  ],
  "CLASS": "4",
  "EN": "context reinterpretation",
  "FR": "réinterprétation du contexte",
  "IEML": "b.h.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a664")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeaceaaaaefaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "phrase",
  "FR": "phrase",
  "IEML": "s.u.-b.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a665")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffaceaaaa"
  ],
  "CLASS": "4",
  "EN": "symptom",
  "FR": "symptôme",
  "IEML": "m.u.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a666")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffabfaaaaefabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "expressive",
  "FR": "expressif",
  "IEML": "m.o.-b.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a668")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feabgaaaagfacfaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in taking care of oneself",
  "FR": "compétence en soin de soi-même",
  "IEML": "k.e.-f.a.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a669")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfabfaaaaffabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "joyful",
  "FR": "joyeux",
  "IEML": "f.o.-m.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a66c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgabfaaaaefabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "style",
  "FR": "style",
  "IEML": "n.o.-b.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a66d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geaceaaaa"
  ],
  "CLASS": "4",
  "EN": "pointer",
  "FR": "pointeur",
  "IEML": "d.u.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a670")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gbacbaaaa"
  ],
  "CLASS": "4",
  "EN": "objective discovery",
  "FR": "découverte objective",
  "IEML": "p.wu.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a672")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhaebaaaa"
  ],
  "CLASS": "4",
  "EN": "poetic creation-innovation cycle",
  "FR": "cycle de création-innovation poétique",
  "IEML": "M:M:.j.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("55d220dc6653c32453c0a673")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhaaaaaaagaabaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "highness qualities",
  "FR": "qualités des hauteurs",
  "IEML": "M:M:.-T:.U:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("55d220dc6653c32453c0a674")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hdahhaaaa"
  ],
  "CLASS": "4",
  "EN": "obstacles",
  "FR": "obstacles",
  "IEML": "M:O:.M:M:.-",
  "LAYER": "2",
  "PARADIGM": "1",
  "TAILLE": "54",
  "_id": ObjectId("55d220dc6653c32453c0a675")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffaceaaaaffaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "other",
  "FR": "autre",
  "IEML": "m.u.-m.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a676")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "afaebaaaa"
  ],
  "CLASS": "1",
  "EN": "mutation",
  "FR": "mutation",
  "IEML": "E:B:.j.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a677")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfacfaaaafeacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "host",
  "FR": "hôte",
  "IEML": "f.a.-k.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a679")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feabeaaaa"
  ],
  "CLASS": "4",
  "EN": "relational intelligence",
  "FR": "intelligence relationnelle",
  "IEML": "k.y.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a67a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffaaaaaaagaacaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "sadness",
  "FR": "tristesse",
  "IEML": "m.-T:.A:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a67f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aeafeaaaa"
  ],
  "CLASS": "1",
  "EN": "mobile",
  "FR": "mobile",
  "IEML": "E:S:.k.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa45")
});
db.getCollection("terms").insert({
  "IEML": "O:O:.wu.-",
  "FR": "porter fruit",
  "EN": "bear fruit",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "4",
  "CANONICAL": [
    "ddacbaaaa"
  ],
  "_id": ObjectId("566487574cb331bd5293409a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeaccagaa"
  ],
  "CLASS": "4",
  "EN": "signs support system",
  "FR": "système de support des signes",
  "IEML": "s.we.T:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("566df9333b7897b48ba52831")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeacbabaa"
  ],
  "CLASS": "4",
  "EN": "intellection",
  "FR": "intellection",
  "IEML": "s.wu.U:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("566df9a43b7897b48ba52838")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "headhaaaa"
  ],
  "CLASS": "4",
  "EN": "human development becoming sign",
  "FR": "devenir signe du développement humain",
  "IEML": "M:S:.O:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "18",
  "_id": ObjectId("5679a74fb9fe1f5ab16a2c05")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhadeaaaa"
  ],
  "CLASS": "4",
  "EN": "human development of the sign",
  "FR": "développement humain du signe",
  "IEML": "M:M:.O:S:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "18",
  "_id": ObjectId("5679b4c4b9fe1f5ab16a2c19")
});
db.getCollection("terms").insert({
  "IEML": "t.-a.-s.y.-'",
  "FR": "histoire sociale",
  "EN": "social history",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "egaaaaaaacfaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567c770eb83eaf1ceef1f4e2")
});
db.getCollection("terms").insert({
  "IEML": "k.-e.-s.y.-'",
  "FR": "sciences de la gestion",
  "EN": "management sciences",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "feaaaaaaabgaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567c7809b83eaf1ceef1f50a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feaaaaaaacgaaaaaaaeeabeaaaa"
  ],
  "CLASS": "4",
  "EN": "sociology of techniques",
  "FR": "sociologie des techniques",
  "IEML": "k.-i.-s.y.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("567c78afb83eaf1ceef1f528")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgaaaaaaabfaaaaaaaeeabeaaaa"
  ],
  "CLASS": "4",
  "EN": "cultural identity studies",
  "FR": "études des identités culturelles",
  "IEML": "n.-o.-s.y.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("567c7aaeb83eaf1ceef1f578")
});
db.getCollection("terms").insert({
  "IEML": "d.-o.-s.y.-'",
  "FR": "droit constitutionnel",
  "EN": "constitutional law",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "geaaaaaaabfaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567c7c5bb83eaf1ceef1f5b4")
});
db.getCollection("terms").insert({
  "IEML": "f.-e.-s.y.-'",
  "FR": "étude des ressources humaines | marché du travail",
  "EN": "human resources | labor market studies",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "gfaaaaaaabgaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567c7e9fb83eaf1ceef1f5fa")
});
db.getCollection("terms").insert({
  "IEML": "l.-y.-s.y.-'",
  "FR": "géographie, sciences de la terre",
  "EN": "geography, earth sciences",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "ggaaaaaaabeaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567c7ff8b83eaf1ceef1f622")
});
db.getCollection("terms").insert({
  "IEML": "s.-g.-s.y.-'",
  "FR": "méthode hypothético-déductive",
  "EN": "hypothetico-deductive method",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "eeaaaaaaaecaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567d9dc2b83eaf1ceef1f668")
});
db.getCollection("terms").insert({
  "IEML": "l.-j.-s.y.-'",
  "FR": "études architecture | urbanisme",
  "EN": "architecture | urban studies",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "ggaaaaaaaebaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567db361b83eaf1ceef1f6e0")
});
db.getCollection("terms").insert({
  "IEML": "b.-g.-s.y.-'",
  "FR": "philologie | épigraphie",
  "EN": "philology | epigraphy",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "efaaaaaaaecaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567db3a4b83eaf1ceef1f6ea")
});
db.getCollection("terms").insert({
  "IEML": "n.-g.-s.y.-'",
  "FR": "analyse de contenu",
  "EN": "content analysis",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "fgaaaaaaaecaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567db5a9b83eaf1ceef1f73a")
});
db.getCollection("terms").insert({
  "IEML": "l.-g.-s.y.-'",
  "FR": "archéologie",
  "EN": "archeology",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "ggaaaaaaaecaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567db766b83eaf1ceef1f758")
});
db.getCollection("terms").insert({
  "IEML": "t.-h.-s.y.-'",
  "FR": "histoire des religions | du sacré",
  "EN": "history of religions | of the sacred",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "egaaaaaaafbaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567db7e4b83eaf1ceef1f76c")
});
db.getCollection("terms").insert({
  "IEML": "n.-h.-s.y.-'",
  "FR": "études arts | architectures sacrées",
  "EN": "sacred art | architecture studies",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "fgaaaaaaafbaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567db8c9b83eaf1ceef1f780")
});
db.getCollection("terms").insert({
  "IEML": "b.-c.-s.y.-'",
  "FR": "sciences de l'éducation",
  "EN": "educational sciences",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "efaaaaaaafcaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567dbe1db83eaf1ceef1f7a8")
});
db.getCollection("terms").insert({
  "IEML": "m.-c.-s.y.-'",
  "FR": "psychologie clinique, psychothérapie",
  "EN": "clinical psychology, psychotherapy",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "ffaaaaaaafcaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567dbee3b83eaf1ceef1f7bc")
});
db.getCollection("terms").insert({
  "IEML": "d.-x.-s.y.-'",
  "FR": "veille | renseignement",
  "EN": "watch | intelligence",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "geaaaaaaagcaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567dc6beb83eaf1ceef1f85c")
});
db.getCollection("terms").insert({
  "IEML": "b.-O:M:.-+M:O:.-s.y.-'",
  "FR": "études du langage",
  "EN": "language studies",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "12",
  "CANONICAL": [
    "efaaaaaaadhaaaaaaaeeabeaaaa",
    "efaaaaaaahdaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567dcb52b83eaf1ceef1f883")
});
db.getCollection("terms").insert({
  "IEML": "M:M:.-O:M:.-'+M:M:.-M:O:.-'",
  "FR": "objets des sciences humaines",
  "EN": "objects of humanities and social sciences",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "108",
  "CANONICAL": [
    "hhaaaaaaadhaaaaaaaaaaaaaaaa",
    "hhaaaaaaahdaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567f04ecb83eaf1ceef1f8d9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feaaaaaaadhaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "social phenomena (1)",
  "FR": "phénomènes sociaux (1)",
  "IEML": "k.-O:M:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("567f09ccb83eaf1ceef1f8fe")
});
db.getCollection("terms").insert({
  "IEML": "M:M:.-a.-'",
  "FR": "phénomènes collectifs",
  "EN": "collective phenomena",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "9",
  "CANONICAL": [
    "hhaaaaaaacfaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567f0bf9b83eaf1ceef1f936")
});
db.getCollection("terms").insert({
  "IEML": "M:M:.-i.-'",
  "FR": "phénomènes techno-scientifiques",
  "EN": "techno-scientific phenomena",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "9",
  "CANONICAL": [
    "hhaaaaaaacgaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567f0c2bb83eaf1ceef1f93d")
});
db.getCollection("terms").insert({
  "IEML": "s.-i.-'",
  "FR": "organisation technique",
  "EN": "technical organization",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "eeaaaaaaacgaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567f0d3ab83eaf1ceef1f967")
});
db.getCollection("terms").insert({
  "IEML": "b.-e.-'",
  "FR": "image de marque, publicité",
  "EN": "brand, advertisement",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "efaaaaaaabgaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567f0dfcb83eaf1ceef1f97c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egaaaaaaabeaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "scientific moment (event, epoch)",
  "FR": "moment scientifique (événement, période)",
  "IEML": "t.-y.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("567f0f6ab83eaf1ceef1f998")
});
db.getCollection("terms").insert({
  "IEML": "t.-i.-'",
  "FR": "moment | époque technique",
  "EN": "technical moment | epoch",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "egaaaaaaacgaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567f113eb83eaf1ceef1f9bb")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgaaaaaaacfaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "cultural invariant",
  "FR": "invariant culturel",
  "IEML": "n.-a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("567f1711b83eaf1ceef1fa32")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geaaaaaaaceaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "data set",
  "FR": "ensemble de données",
  "IEML": "d.-u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("567f1c56b83eaf1ceef1fa55")
});
db.getCollection("terms").insert({
  "IEML": "d.-a.-'",
  "FR": "relation sociale",
  "EN": "social relation",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "geaaaaaaacfaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567f1c89b83eaf1ceef1fa5c")
});
db.getCollection("terms").insert({
  "IEML": "f.-u.-'",
  "FR": "performance de communication | acte de langage",
  "EN": "communication performance | speech act",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "gfaaaaaaaceaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567f1f05b83eaf1ceef1fa8d")
});
db.getCollection("terms").insert({
  "IEML": "M:M:.-j.-'",
  "FR": "arts",
  "EN": "arts",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "9",
  "CANONICAL": [
    "hhaaaaaaaebaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("5680266bb83eaf1ceef1fabe")
});
db.getCollection("terms").insert({
  "IEML": "l.-g.-'",
  "FR": "artefact",
  "EN": "artifact",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "ggaaaaaaaecaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("568047eab83eaf1ceef1fb9e")
});
db.getCollection("terms").insert({
  "IEML": "s.-h.-'",
  "FR": "divinité",
  "EN": "divinity",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "eeaaaaaaafbaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("568048b1b83eaf1ceef1fba5")
});
db.getCollection("terms").insert({
  "IEML": "s.-c.-'",
  "FR": "âme",
  "EN": "soul",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "eeaaaaaaafcaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("56804aefb83eaf1ceef1fbe4")
});
db.getCollection("terms").insert({
  "IEML": "b.-p.-'",
  "FR": "jurisprudence",
  "EN": "jurisprudence",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "efaaaaaaagbaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("568060deb83eaf1ceef1fc2a")
});
db.getCollection("terms").insert({
  "IEML": "j.O:B:.-",
  "FR": "cadre structurel affectif",
  "EN": "affective structural framework",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "ebadfaaaa"
  ],
  "_id": ObjectId("56830f75b83eaf1ceef1fdf1")
});
db.getCollection("terms").insert({
  "IEML": "g.A:M:.-",
  "FR": "processus d'expression actuel",
  "EN": "actual process of expression",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "3",
  "CANONICAL": [
    "ecachaaaa"
  ],
  "_id": ObjectId("56830fcfb83eaf1ceef1fdff")
});
db.getCollection("terms").insert({
  "IEML": "h.U:M:.-",
  "FR": "cadre sémantique virtuel",
  "EN": "virtual semantic framework",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "3",
  "CANONICAL": [
    "fbabhaaaa"
  ],
  "_id": ObjectId("56831088b83eaf1ceef1fe1b")
});
db.getCollection("terms").insert({
  "IEML": "h.A:M:.-",
  "FR": "cadre sémantique actuel",
  "EN": "actual semantic framework",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "3",
  "CANONICAL": [
    "fbachaaaa"
  ],
  "_id": ObjectId("5683109fb83eaf1ceef1fe22")
});
db.getCollection("terms").insert({
  "IEML": "h.O:S:.-",
  "FR": "cadre sémantique abstrait",
  "EN": "abstract semantic framework",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "fbadeaaaa"
  ],
  "_id": ObjectId("568310c5b83eaf1ceef1fe29")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhacbaaaa"
  ],
  "CLASS": "4",
  "EN": "aesthetic sources of meaning",
  "FR": "sources esthétiques du sens",
  "IEML": "M:M:.wu.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("55d220dc6653c32453c0a67e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeacfaaaafeacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "politician",
  "FR": "politicien",
  "IEML": "s.a.-k.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a680")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeaceaaaaffaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "dream",
  "FR": "rêve",
  "IEML": "s.u.-m.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a682")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egacfaaaaegacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "foundation",
  "FR": "fondation",
  "IEML": "t.a.-t.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a683")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hdaefaaaa"
  ],
  "CLASS": "4",
  "EN": "defect of language",
  "FR": "défaut du langage",
  "IEML": "M:O:.b.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dc6653c32453c0a684")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffacgaaaaeeacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "trapped",
  "FR": "piégé",
  "IEML": "m.i.-s.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a687")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geacgaaaaggacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "address | indicator",
  "FR": "adresse | indicateur",
  "IEML": "d.i.-l.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a688")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gcabcaaaa"
  ],
  "CLASS": "4",
  "EN": "new vehicle | tool",
  "FR": "nouveau véhicule | outil",
  "IEML": "x.wa.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a689")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfacfaaaafeacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "welcome | hospitality",
  "FR": "accueil | hospitalité",
  "IEML": "f.a.-k.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a68a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaceaaaaefaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "significant",
  "FR": "signifiant",
  "IEML": "b.u.-b.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a68d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffacgaaaagfacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "caressed",
  "FR": "caressé",
  "IEML": "m.i.-f.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a68e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgacfaaaa"
  ],
  "CLASS": "4",
  "EN": "judge",
  "FR": "juge",
  "IEML": "n.a.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a68f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egaddaaaa"
  ],
  "CLASS": "4",
  "EN": "sources of meaning in memory",
  "FR": "sources du sens dans la mémoire",
  "IEML": "t.O:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220dc6653c32453c0a690")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gcafeaaaa"
  ],
  "CLASS": "4",
  "EN": "lack of human resources",
  "FR": "manque de ressources humaines",
  "IEML": "x.k.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a691")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeafbaaaa"
  ],
  "CLASS": "4",
  "EN": "cultural project | cultural dimension of a creation-innovation project",
  "FR": "projet culturel | dimension culturelle d'un projet de création-innovation",
  "IEML": "s.h.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a692")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhacfaaaahhacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "social functions",
  "FR": "fonctions sociales",
  "IEML": "M:M:.a.-M:M:.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "81",
  "_id": ObjectId("55d220dc6653c32453c0a694")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffaceaaaafeaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "sacrificed",
  "FR": "sacrifié",
  "IEML": "m.u.-k.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a699")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gbaddaaaa"
  ],
  "CLASS": "4",
  "EN": "object change",
  "FR": "changement d'objet",
  "IEML": "p.O:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220dc6653c32453c0a69c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffabcaaaa"
  ],
  "CLASS": "4",
  "EN": "audacity",
  "FR": "audace",
  "IEML": "m.wa.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a69d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egabgaaaafeaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "original symbol",
  "FR": "symbole original",
  "IEML": "t.e.-k.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a69e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "agc"
  ],
  "CLASS": "1",
  "EN": "by experience | from the facts",
  "FR": "par expérience | à partir des faits",
  "IEML": "E:T:A:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a69f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeacgaaaaggacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "articulation | joint",
  "FR": "articulation physique",
  "IEML": "s.i.-l.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6a0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfabcaaaa"
  ],
  "CLASS": "4",
  "EN": "physical activity",
  "FR": "activité physique",
  "IEML": "f.wa.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6a3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fbadhaaaa"
  ],
  "CLASS": "4",
  "EN": "semantic process",
  "FR": "cadre sémantique",
  "IEML": "h.O:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dc6653c32453c0a6a6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgabbaaaa"
  ],
  "CLASS": "4",
  "EN": "spiritual exercise",
  "FR": "exercice spirituel",
  "IEML": "n.wo.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6a7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgaceaaaaeeaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "overall form | overall structure",
  "FR": "forme d'ensemble | structure d'ensemble",
  "IEML": "n.u.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6a8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hdaeeaaaa"
  ],
  "CLASS": "4",
  "EN": "initial obstacle",
  "FR": "obstacle initial",
  "IEML": "M:O:.s.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dc6653c32453c0a6a9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggabgaaaa"
  ],
  "CLASS": "4",
  "EN": "engineering competence",
  "FR": "compétence en ingénierie",
  "IEML": "l.e.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6aa")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egacfaaaaffacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "ancestry",
  "FR": "ascendance",
  "IEML": "t.a.-m.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6ac")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgacgaaaageacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "quick",
  "FR": "rapide",
  "IEML": "n.i.-d.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6ad")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfaaaaaaagaabaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "spicy",
  "FR": "goût piquant",
  "IEML": "f.-T:.U:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6ae")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efabfaaaaggabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "transmitted",
  "FR": "transmis",
  "IEML": "b.o.-l.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6b0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gbafgaaaa"
  ],
  "CLASS": "4",
  "EN": "lack of economic initiative",
  "FR": "absence d'initiative économique",
  "IEML": "p.n.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6b1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geacfaaaafeacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "inspection",
  "FR": "inspection",
  "IEML": "d.a.-k.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6b2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffafcaaaa"
  ],
  "CLASS": "4",
  "EN": "respect of people",
  "FR": "respect des personnes",
  "IEML": "m.c.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6b6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geacgaaaafgacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "steered",
  "FR": "piloté",
  "IEML": "d.i.-n.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6b7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feaaaaaaagaacaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "hight volume | loud | heavy",
  "FR": "fort volume | lourd",
  "IEML": "k.-T:.A:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6b8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfacgaaaaeeacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "prosthesis",
  "FR": "prothèse",
  "IEML": "f.i.-s.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6b9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggabfaaaaeeabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "explored",
  "FR": "exploré",
  "IEML": "l.o.-s.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6ba")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggabfaaaaefabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "composed",
  "FR": "composé",
  "IEML": "l.o.-b.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6bb")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeaceaaaagfaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "perception",
  "FR": "perception",
  "IEML": "s.u.-f.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6bc")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "acahdaaaa"
  ],
  "CLASS": "1",
  "EN": "positive manner",
  "FR": "manière positive",
  "IEML": "E:A:.M:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dc6653c32453c0a6c3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggacgaaaagfacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "powerful | agile",
  "FR": "puissant | agile",
  "IEML": "l.i.-f.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6c4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "image | diagram",
  "FR": "image | diagramme",
  "IEML": "s.u.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6c5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fbacfaaaa"
  ],
  "CLASS": "4",
  "EN": "adherence",
  "FR": "adhésion",
  "IEML": "h.a.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6c6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fcaddaaaa"
  ],
  "CLASS": "4",
  "EN": "personal change",
  "FR": "changement personnel",
  "IEML": "c.O:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220dc6653c32453c0a6c7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ecafcaaaa"
  ],
  "CLASS": "4",
  "EN": "vow renewal | promise renewal",
  "FR": "renouvellement d'un vœu | renouvellement d'une promesse",
  "IEML": "g.c.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6c8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfabgaaaaggacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "fight",
  "FR": "combat",
  "IEML": "f.e.-l.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6cc")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfabgaaaaegacgaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in driving",
  "FR": "compétence en conduite",
  "IEML": "f.e.-t.i.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6ce")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ach"
  ],
  "CLASS": "1",
  "EN": "quantity variation",
  "FR": "variation quantitative",
  "IEML": "E:A:M:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("55d220dc6653c32453c0a6d0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgacgaaaaefacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "lighted",
  "FR": "éclairé",
  "IEML": "n.i.-b.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6d3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "agadhaaaa"
  ],
  "CLASS": "1",
  "EN": "past tense",
  "FR": "temps passé",
  "IEML": "E:T:.O:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dc6653c32453c0a6d4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ebabcaaaa"
  ],
  "CLASS": "4",
  "EN": "change of justifications",
  "FR": "changement de justifications",
  "IEML": "j.wa.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6d6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffabfaaaafeabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "compassion",
  "FR": "compassion",
  "IEML": "m.o.-k.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6da")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggabgaaaaegacgaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in vehicle design",
  "FR": "compétence en conception de véhicules",
  "IEML": "l.e.-t.i.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6db")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeabgaaaafeaceaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in reading | competence in writing",
  "FR": "compétence en lecture | compétence en écriture",
  "IEML": "s.e.-k.u.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6de")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggacgaaaafgacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "cutting tool | piercing tool",
  "FR": "outil coupant | outil perçant",
  "IEML": "l.i.-n.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6df")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeabfaaaaggabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "proportioned",
  "FR": "proportionné",
  "IEML": "s.o.-l.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6e1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffabgaaaageacfaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in truth seeking",
  "FR": "compétence en recherche de la vérité",
  "IEML": "m.e.-d.a.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6e2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgacgaaaaeeacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "in motion",
  "FR": "en mouvement",
  "IEML": "n.i.-s.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6e3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ebafgaaaa"
  ],
  "CLASS": "4",
  "EN": "clichÃ© | platitude",
  "FR": "cliché | platitude",
  "IEML": "j.n.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6e4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geacgaaaaeeacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "integrated circuit",
  "FR": "circuit intégré",
  "IEML": "d.i.-s.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6e5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feabgaaaafgacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "ethics",
  "FR": "éthique",
  "IEML": "k.e.-n.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6e6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geacgaaaa"
  ],
  "CLASS": "4",
  "EN": "measuring instrument",
  "FR": "instrument de mesure",
  "IEML": "d.i.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6e7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geaceaaaagfaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "present",
  "FR": "présent",
  "IEML": "d.u.-f.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6e9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egabfaaaafeabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "traditional",
  "FR": "traditionnel",
  "IEML": "t.o.-k.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6eb")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geacgaaaaggacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "place | site",
  "FR": "lieu | site",
  "IEML": "d.i.-l.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6ec")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efacbaaaa"
  ],
  "CLASS": "4",
  "EN": "aesthetic encounter",
  "FR": "rencontre esthétique",
  "IEML": "b.wu.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6ed")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feacgaaaaefacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "software",
  "FR": "logiciel",
  "IEML": "k.i.-b.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6ee")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fcafeaaaa"
  ],
  "CLASS": "4",
  "EN": "sclerosis of the bond",
  "FR": "sclérose du lien",
  "IEML": "c.k.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6f0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aeg"
  ],
  "CLASS": "1",
  "EN": "always",
  "FR": "toujours",
  "IEML": "E:S:T:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6f1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geacfaaaageacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "invention",
  "FR": "invention",
  "IEML": "d.a.-d.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6f2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ahafeaaaa"
  ],
  "CLASS": "1",
  "EN": "dynamic intermediary",
  "FR": "intermédiaire dynamique",
  "IEML": "E:M:.k.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("55d220dc6653c32453c0a6f3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgaceaaaaggaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "trail",
  "FR": "piste",
  "IEML": "n.u.-l.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6f4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggacfaaaagfacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "natural environment",
  "FR": "environnement naturel",
  "IEML": "l.a.-f.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6f5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ecaegaaaa"
  ],
  "CLASS": "4",
  "EN": "inappropriate expression | untimely expression",
  "FR": "incongruité | propos inopportun",
  "IEML": "g.t.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6f8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feabfaaaaeeabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "governed",
  "FR": "gouverné",
  "IEML": "k.o.-s.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6f9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfabgaaaa"
  ],
  "CLASS": "4",
  "EN": "technical ability",
  "FR": "habileté technique",
  "IEML": "f.e.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6fa")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgacfaaaaefacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "news",
  "FR": "nouvelle",
  "IEML": "n.a.-b.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6fb")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egaccaaaa"
  ],
  "CLASS": "4",
  "EN": "regularity",
  "FR": "régularité",
  "IEML": "t.we.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6fd")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffacgaaaageacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "targeted",
  "FR": "ciblé",
  "IEML": "m.i.-d.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6ff")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffabgaaaaefacfaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in speaking wisely",
  "FR": "compétence en paroles sages",
  "IEML": "m.e.-b.a.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a700")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffabfaaaageabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "sincerity",
  "FR": "sincérité",
  "IEML": "m.o.-d.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a701")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feaceaaaaefaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "revelation",
  "FR": "révélation",
  "IEML": "k.u.-b.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a705")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "adadhaaaa"
  ],
  "CLASS": "1",
  "EN": "diathesis | grammatical voice",
  "FR": "diathèse | voix grammaticale",
  "IEML": "E:O:.O:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "12",
  "_id": ObjectId("55d220dc6653c32453c0a707")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffacfaaaaeeacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "mediator",
  "FR": "médiateur",
  "IEML": "m.a.-s.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a708")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efacgaaaaefacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "cyberspace",
  "FR": "cyberespace",
  "IEML": "b.i.-b.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a70a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geacfaaaafgacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "witness",
  "FR": "témoin",
  "IEML": "d.a.-n.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a70b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfabgaaaagfacgaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in athletics",
  "FR": "compétence en athlétisme",
  "IEML": "f.e.-f.i.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a70c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fcabcaaaa"
  ],
  "CLASS": "4",
  "EN": "reversal of alliance",
  "FR": "retournement d'alliance",
  "IEML": "c.wa.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a70e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggabgaaaagfacgaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in biotechnology",
  "FR": "compétence en biotechnologie",
  "IEML": "l.e.-f.i.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a70f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "afg"
  ],
  "CLASS": "1",
  "EN": "often",
  "FR": "souvent",
  "IEML": "E:B:T:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a711")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egaaaaaaaeaabaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "winter",
  "FR": "hiver",
  "IEML": "t.-S:.U:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a713")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhaddaaaa"
  ],
  "CLASS": "4",
  "EN": "resources of meaning",
  "FR": "ressources du sens",
  "IEML": "M:M:.O:O:.-",
  "LAYER": "2",
  "PARADIGM": "1",
  "TAILLE": "36",
  "_id": ObjectId("55d220dc6653c32453c0a715")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhaaaaaaagaacaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "deepness qualities",
  "FR": "qualités des profondeurs",
  "IEML": "M:M:.-T:.A:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("55d220dc6653c32453c0a71a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffagbaaaa"
  ],
  "CLASS": "4",
  "EN": "rendered service",
  "FR": "service rendu",
  "IEML": "m.p.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a71b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ccafgaaaa"
  ],
  "CLASS": "2",
  "EN": "accept the judgement of peers",
  "FR": "accepter le jugement des pairs",
  "IEML": "we.n.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a71c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gcaecaaaa"
  ],
  "CLASS": "4",
  "EN": "debt transformation",
  "FR": "transformation de la dette",
  "IEML": "x.g.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a71e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geacfaaaaggacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "intelligence agent",
  "FR": "agent de renseignements",
  "IEML": "d.a.-l.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a71f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gcaccaaaa"
  ],
  "CLASS": "4",
  "EN": "mutation of natural environment",
  "FR": "mutation de l'environnement naturel",
  "IEML": "x.we.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a722")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feabfaaaaegabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "past",
  "FR": "passé",
  "IEML": "k.o.-t.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a724")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggacfaaaaefacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "reputation",
  "FR": "réputation",
  "IEML": "l.a.-b.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a725")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egacgaaaafgacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "heated",
  "FR": "chauffé",
  "IEML": "t.i.-n.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a726")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geacgaaaaefacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "computer",
  "FR": "ordinateur",
  "IEML": "d.i.-b.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a728")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggacfaaaa"
  ],
  "CLASS": "4",
  "EN": "guardian",
  "FR": "gardien",
  "IEML": "l.a.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a72a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geabgaaaageacgaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in control | competence in measure",
  "FR": "compétence en contrôle | compétence en mesure",
  "IEML": "d.e.-d.i.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a72b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hdabfaaaa"
  ],
  "CLASS": "4",
  "EN": "conditions of desire",
  "FR": "conditions du désir",
  "IEML": "M:O:.o.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dc6653c32453c0a72d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggaceaaaaefaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "transcription",
  "FR": "transcription",
  "IEML": "l.u.-b.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a72e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gbaebaaaa"
  ],
  "CLASS": "4",
  "EN": "new synthesis",
  "FR": "nouvelle synthèse",
  "IEML": "p.j.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a730")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hdacbaaaa"
  ],
  "CLASS": "4",
  "EN": "perception mutation",
  "FR": "mutation de la perception",
  "IEML": "M:O:.wu.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dc6653c32453c0a731")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gcagcaaaa"
  ],
  "CLASS": "4",
  "EN": "production mutation",
  "FR": "mutation de la production",
  "IEML": "x.x.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a733")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfacgaaaafeacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "edible | drinkable",
  "FR": "comestible | potable",
  "IEML": "f.i.-k.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a734")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "acabeaaaa"
  ],
  "CLASS": "1",
  "EN": "knowing",
  "FR": "connaissant",
  "IEML": "E:A:.y.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a736")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feaceaaaafgaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "tribal",
  "FR": "tribal",
  "IEML": "k.u.-n.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a737")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffacfaaaaegacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "notary",
  "FR": "notaire",
  "IEML": "m.a.-t.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a738")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dhaaaaaaabeaaaaaaaccafbaaaa"
  ],
  "CLASS": "2",
  "EN": "strengthen knowledge",
  "FR": "renforcer la connaissance",
  "IEML": "O:M:.-y.-we.h.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dc6653c32453c0a739")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfaceaaaaefaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "accentuated",
  "FR": "accentué",
  "IEML": "f.u.-b.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a73a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffabgaaaafgacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "chosen person",
  "FR": "personne choisie",
  "IEML": "m.e.-n.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a73b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efabfaaaaffabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "beautiful",
  "FR": "beau",
  "IEML": "b.o.-m.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a73d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ahf"
  ],
  "CLASS": "1",
  "EN": "distributive medium",
  "FR": "medium distributif",
  "IEML": "E:M:B:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("55d220dc6653c32453c0a73f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egabfaaaa"
  ],
  "CLASS": "4",
  "EN": "right time (seizing the)",
  "FR": "moment opportun (saisie du)",
  "IEML": "t.o.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a741")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fbabgaaaa"
  ],
  "CLASS": "4",
  "EN": "legitimacy",
  "FR": "légitimité",
  "IEML": "h.e.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a744")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgaceaaaaefaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "proposition | assertion",
  "FR": "proposition | affirmation",
  "IEML": "n.u.-b.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a745")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggaceaaaafgaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "happening | occuring",
  "FR": "ayant lieu | survenant",
  "IEML": "l.u.-n.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a746")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geaceaaaageaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "salient",
  "FR": "saillant",
  "IEML": "d.u.-d.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a747")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffaaaaaaahaadaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "emotions",
  "FR": "émotions",
  "IEML": "m.-M:.O:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dc6653c32453c0a749")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ecaecaaaa"
  ],
  "CLASS": "4",
  "EN": "discourse mutation",
  "FR": "mutation du discours",
  "IEML": "g.g.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a74d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhaaaaaaahaadaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "qualities",
  "FR": "qualités",
  "IEML": "M:M:.-M:.O:.-'",
  "LAYER": "3",
  "PARADIGM": "1",
  "TAILLE": "54",
  "_id": ObjectId("55d220dc6653c32453c0a74f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeaceaaaaefaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "enunciated",
  "FR": "énoncé",
  "IEML": "s.u.-b.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a750")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggabgaaaaefacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "virtual world",
  "FR": "monde virtuel",
  "IEML": "l.e.-b.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a751")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geabfaaaafeabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "sure",
  "FR": "sûr",
  "IEML": "d.o.-k.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a752")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgaceaaaafeaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "excellent",
  "FR": "excellent",
  "IEML": "n.u.-k.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a754")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "adafbaaaa"
  ],
  "CLASS": "1",
  "EN": "manner of tropism",
  "FR": "manière de tropisme",
  "IEML": "E:O:.h.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("55d220dc6653c32453c0a755")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "acafbaaaa"
  ],
  "CLASS": "1",
  "EN": "seeking | heading towards",
  "FR": "en cherchant | vers",
  "IEML": "E:A:.h.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a756")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ebaccaaaa"
  ],
  "CLASS": "4",
  "EN": "cultural adaptation | transfer",
  "FR": "adaptation | transfert culturel",
  "IEML": "j.we.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a757")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ebacfaaaa"
  ],
  "CLASS": "4",
  "EN": "learning of the community's language",
  "FR": "langage commun",
  "IEML": "j.a.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a758")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffaceaaaaefaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "spell",
  "FR": "sortilège",
  "IEML": "m.u.-b.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a75a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgacfaaaaeeacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "adult",
  "FR": "adulte",
  "IEML": "n.a.-s.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a75e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggaceaaaaffaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "usual",
  "FR": "habituel",
  "IEML": "l.u.-m.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a760")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "abg"
  ],
  "CLASS": "1",
  "EN": "better",
  "FR": "meilleur",
  "IEML": "E:U:T:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a761")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feacfaaaaefacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "spectator",
  "FR": "spectateur",
  "IEML": "k.a.-b.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a763")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeabfaaaaeeabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "mind",
  "FR": "esprit",
  "IEML": "s.o.-s.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a767")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feabgaaaaeeacfaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in understanding oneself",
  "FR": "compétence en compréhension de soi-même",
  "IEML": "k.e.-s.a.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a768")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeaaaaaaaeaabaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "cold",
  "FR": "froid",
  "IEML": "s.-S:.U:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a769")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geaceaaaageaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "signal",
  "FR": "signal",
  "IEML": "d.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a76a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfacgaaaa"
  ],
  "CLASS": "4",
  "EN": "organ",
  "FR": "organe",
  "IEML": "f.i.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a76e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffaddaaaa"
  ],
  "CLASS": "4",
  "EN": "sources of meaning in affective relation",
  "FR": "sources du sens dans le rapport affectif",
  "IEML": "m.O:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220dc6653c32453c0a76f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feagbaaaa"
  ],
  "CLASS": "4",
  "EN": "renewed economic partnership",
  "FR": "partenariat économique renouvelé",
  "IEML": "k.p.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a770")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efabfaaaafgabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "poetical",
  "FR": "poétique",
  "IEML": "b.o.-n.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a772")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggaaaaaaagaacaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "nadir",
  "FR": "nadir",
  "IEML": "l.-T:.A:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a773")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ahaecaaaa"
  ],
  "CLASS": "1",
  "EN": "actual formal cause",
  "FR": "cause formelle actuelle",
  "IEML": "E:M:.g.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("55d220dc6653c32453c0a774")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgabgaaaafgacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "moral refinement",
  "FR": "raffinement moral",
  "IEML": "n.e.-n.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a776")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgacfaaaaegacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "lawyer",
  "FR": "avocat",
  "IEML": "n.a.-t.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a778")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geacfaaaaffacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "child",
  "FR": "enfant",
  "IEML": "d.a.-m.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a779")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fcabfaaaa"
  ],
  "CLASS": "4",
  "EN": "prohibition | renunciation",
  "FR": "interdit | renoncement",
  "IEML": "c.o.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a77a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffaceaaaaggaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "remembered",
  "FR": "rappelé à  la mémoire",
  "IEML": "m.u.-l.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a77b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aiaccaaaa"
  ],
  "CLASS": "1",
  "EN": "feminine pronoun",
  "FR": "pronom féminin",
  "IEML": "E:F:.we.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "5",
  "_id": ObjectId("55d220dc6653c32453c0a77f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeaceaaaaegaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "ideogram",
  "FR": "idéogramme",
  "IEML": "s.u.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a780")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ecagcaaaa"
  ],
  "CLASS": "4",
  "EN": "credit transformation",
  "FR": "transformation du crédit",
  "IEML": "g.x.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a781")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egabcaaaa"
  ],
  "CLASS": "4",
  "EN": "chance | unexpected events",
  "FR": "hasard | événements inattendus",
  "IEML": "t.wa.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a782")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeahdaaaa"
  ],
  "CLASS": "4",
  "EN": "creation-innovation cycle project",
  "FR": "projet de cycle de création-innovation",
  "IEML": "s.M:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dc6653c32453c0a783")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ahe"
  ],
  "CLASS": "1",
  "EN": "distributive minus",
  "FR": "moins distributif",
  "IEML": "E:M:S:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("55d220dc6653c32453c0a785")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feabfaaaagfabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "collaboration",
  "FR": "collaboration",
  "IEML": "k.o.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a789")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggabfaaaageabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "orientation",
  "FR": "orientation",
  "IEML": "l.o.-d.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a78c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgacfaaaaeeacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "majority",
  "FR": "majorité",
  "IEML": "n.a.-s.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a78d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfacfaaaaegacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "insurance",
  "FR": "assurance",
  "IEML": "f.a.-t.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a78f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aeafbaaaa"
  ],
  "CLASS": "1",
  "EN": "variable",
  "FR": "variable",
  "IEML": "E:S:.h.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a792")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "adg"
  ],
  "CLASS": "1",
  "EN": "comparative plus",
  "FR": "plus comparatif",
  "IEML": "E:O:T:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("55d220dc6653c32453c0a793")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfabfaaaageabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "focal",
  "FR": "focal",
  "IEML": "f.o.-d.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a794")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgaaaaaaaeaabaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "earth",
  "FR": "terre",
  "IEML": "n.-S:.U:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a795")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeabgaaaageaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "obtained information",
  "FR": "information obtenue",
  "IEML": "s.e.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a796")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffacfaaaafeacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "neighbor",
  "FR": "voisin",
  "IEML": "m.a.-k.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a797")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfabfaaaaeeabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "surreal | mythical",
  "FR": "surréel | mythique",
  "IEML": "f.o.-s.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a79a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffaceaaaafgaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "subjective",
  "FR": "subjectif",
  "IEML": "m.u.-n.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a79b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ahaedaaaa"
  ],
  "CLASS": "1",
  "EN": "formal cause | formal role",
  "FR": "cause formelle | rôle formel",
  "IEML": "E:M:.S:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dd6653c32453c0a79c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeabgaaaaeeaceaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "in drawing | painting",
  "FR": "en dessin | peinture",
  "IEML": "s.e.-s.u.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a79d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gbabgaaaa"
  ],
  "CLASS": "4",
  "EN": "domain of competence",
  "FR": "domaine de compétence",
  "IEML": "p.e.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a79e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "acaccaaaa"
  ],
  "CLASS": "1",
  "EN": "possessive feminine",
  "FR": "possessif féminin",
  "IEML": "E:A:.we.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7a0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geagbaaaa"
  ],
  "CLASS": "4",
  "EN": "economic intelligence",
  "FR": "intelligence économique",
  "IEML": "d.p.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7a1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efacgaaaafgacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "musical instrument",
  "FR": "instrument de musique",
  "IEML": "b.i.-n.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7a3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "afacfaaaa"
  ],
  "CLASS": "1",
  "EN": "commit now",
  "FR": "s'engager maintenant",
  "IEML": "E:B:.a.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7a5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfacgaaaagfacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "organism",
  "FR": "organisme",
  "IEML": "f.i.-f.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7a6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggabfaaaaeeabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "exploration",
  "FR": "exploration",
  "IEML": "l.o.-s.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7a9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hdabcaaaa"
  ],
  "CLASS": "4",
  "EN": "action mutation",
  "FR": "mutation de l'action",
  "IEML": "M:O:.wa.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dd6653c32453c0a7aa")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efacfaaaageacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "advertiser",
  "FR": "publicitaire",
  "IEML": "b.a.-d.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7ab")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egacfaaaafgacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "legislator",
  "FR": "législateur",
  "IEML": "t.a.-n.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7ad")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aiacdaaaa"
  ],
  "CLASS": "1",
  "EN": "neutral gender",
  "FR": "genre neutre",
  "IEML": "E:F:.A:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "10",
  "_id": ObjectId("55d220dd6653c32453c0a7ae")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfaceaaaafeaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "glimpsed",
  "FR": "aperçu",
  "IEML": "f.u.-k.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7b0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgacgaaaa"
  ],
  "CLASS": "4",
  "EN": "fire | transformation technique",
  "FR": "feu | technique de transformation",
  "IEML": "n.i.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7b1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gcaeeaaaa"
  ],
  "CLASS": "4",
  "EN": "design flaw",
  "FR": "défaut de conception",
  "IEML": "x.s.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7b2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffabgaaaaggacfaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in abiding by law",
  "FR": "compétence en respect de la loi",
  "IEML": "m.e.-l.a.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7b3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "afahdaaaa"
  ],
  "CLASS": "1",
  "EN": "interactive cause",
  "FR": "cause interactive",
  "IEML": "E:B:.M:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dd6653c32453c0a7b4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfabgaaaaefacgaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in dancing",
  "FR": "compétence en danse",
  "IEML": "f.e.-b.i.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7b5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egaceaaaaefaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "written",
  "FR": "écrit",
  "IEML": "t.u.-b.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7b7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaceaaaaeeaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "metaphor | similarity",
  "FR": "métaphore | ressemblance",
  "IEML": "b.u.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7ba")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeabcaaaa"
  ],
  "CLASS": "4",
  "EN": "context",
  "FR": "contexte",
  "IEML": "s.wa.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7bb")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fcacfaaaa"
  ],
  "CLASS": "4",
  "EN": "identification",
  "FR": "identification",
  "IEML": "c.a.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7bd")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfacgaaaaeeacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "assisted",
  "FR": "assisté",
  "IEML": "f.i.-s.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7be")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egaceaaaaegaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "number",
  "FR": "nombre",
  "IEML": "t.u.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7c0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeagbaaaa"
  ],
  "CLASS": "4",
  "EN": "economic project | economic dimension of a creation-innovation project",
  "FR": "projet économique | dimension économique d'un projet de création-innovation",
  "IEML": "s.p.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7c1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egaaaaaaagaabaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "dry season",
  "FR": "saison sèche",
  "IEML": "t.-T:.U:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7c2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgacfaaaaffacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "father",
  "FR": "père",
  "IEML": "n.a.-m.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7c3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ecaebaaaa"
  ],
  "CLASS": "4",
  "EN": "new response",
  "FR": "nouvelle réponse",
  "IEML": "g.j.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7c5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egabgaaaafeaceaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in symbol creation",
  "FR": "compétence en création de symboles",
  "IEML": "t.e.-k.u.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7c6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dhaaaaaaabfaaaaaaaccafbaaaa"
  ],
  "CLASS": "2",
  "EN": "strengthen governance",
  "FR": "renforcer la gouvernance",
  "IEML": "O:M:.-o.-we.h.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dd6653c32453c0a7c8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geaceaaaafeaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "erect",
  "FR": "dressé",
  "IEML": "d.u.-k.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7c9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fbafbaaaa"
  ],
  "CLASS": "4",
  "EN": "ethical mutation",
  "FR": "mutation éthique",
  "IEML": "h.h.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7ca")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ebageaaaa"
  ],
  "CLASS": "4",
  "EN": "double talk | mimicry | parroting",
  "FR": "langue de bois | imitation | psittacisme",
  "IEML": "j.d.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7cb")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ababfaaaa"
  ],
  "CLASS": "1",
  "EN": "wanted",
  "FR": "voulu",
  "IEML": "E:U:.o.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7cc")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgaceaaaaggaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "retraced",
  "FR": "retracé",
  "IEML": "n.u.-l.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7ce")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efacfaaaagfacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "care",
  "FR": "soin",
  "IEML": "b.a.-f.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7d0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggacfaaaaffacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "ally",
  "FR": "allié",
  "IEML": "l.a.-m.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7d2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfaceaaaageaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "exclamation",
  "FR": "exclamation",
  "IEML": "f.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7d3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feacfaaaafeacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "citizen",
  "FR": "citoyen",
  "IEML": "k.a.-k.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7d8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ecahdaaaa"
  ],
  "CLASS": "4",
  "EN": "transformation on expressive basis",
  "FR": "transformation sur base expressive",
  "IEML": "g.M:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dd6653c32453c0a7db")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggacgaaaaefacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "simulation",
  "FR": "simulation",
  "IEML": "l.i.-b.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7dc")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ahageaaaa"
  ],
  "CLASS": "1",
  "EN": "dynamic termination",
  "FR": "terminaison dynamique",
  "IEML": "E:M:.d.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("55d220dd6653c32453c0a7dd")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efacfaaaaegacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "accounts",
  "FR": "comptes",
  "IEML": "b.a.-t.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7e2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ebaceaaaa"
  ],
  "CLASS": "4",
  "EN": "generation of ideas",
  "FR": "génération d'idées",
  "IEML": "j.u.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7e4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geaaaaaaafaabaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "rough",
  "FR": "rugueux",
  "IEML": "d.-B:.U:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7e5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gcagfaaaa"
  ],
  "CLASS": "4",
  "EN": "non repaired breakdown | inefficiency",
  "FR": "panne non réparée | inefficacité",
  "IEML": "x.f.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7e6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfacgaaaafgacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "weapon",
  "FR": "arme",
  "IEML": "f.i.-n.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7e8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fbabeaaaa"
  ],
  "CLASS": "4",
  "EN": "school",
  "FR": "école",
  "IEML": "h.y.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7e9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geacfaaaageacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "inventor",
  "FR": "inventeur",
  "IEML": "d.a.-d.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7ea")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfaddaaaa"
  ],
  "CLASS": "4",
  "EN": "sources of meaning in the body",
  "FR": "sources du sens dans le corps",
  "IEML": "f.O:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220dd6653c32453c0a7eb")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgaceaaaaegaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "emblematic",
  "FR": "emblématique",
  "IEML": "n.u.-t.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7ed")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeaaaaaaafaabaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "growing | increasing | waxing",
  "FR": "croissant | augmentant",
  "IEML": "s.-B:.U:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7ee")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeabgaaaaefaceaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in mastering a second language",
  "FR": "compétence en maîtrise dune deuxième langue",
  "IEML": "s.e.-b.u.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7ef")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efafcaaaa"
  ],
  "CLASS": "4",
  "EN": "ability to gather people",
  "FR": "capacité de rassemblement",
  "IEML": "b.c.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7f0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeabgaaaaeeaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "drawing | painting",
  "FR": "dessin | peinture",
  "IEML": "s.e.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7f1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfabgaaaafeacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "team spirit",
  "FR": "esprit d'équipe",
  "IEML": "f.e.-k.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7f2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feabgaaaafeacfaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in following a discipline",
  "FR": "compétence en adhésion à  une discipline",
  "IEML": "k.e.-k.a.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7f3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egahdaaaa"
  ],
  "CLASS": "4",
  "EN": "inscription in time of a creation-innovation cycle",
  "FR": "inscription dans le temps d'un cycle de création-innovation",
  "IEML": "t.M:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dd6653c32453c0a7f4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egacfaaaafgacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "law",
  "FR": "loi",
  "IEML": "t.a.-n.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7f5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgabgaaaafeacfaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in giving oneself as example",
  "FR": "compétence en don de soi en exemple",
  "IEML": "n.e.-k.a.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7fa")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhabgaaaahhachaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "achievements",
  "FR": "accomplissements",
  "IEML": "M:M:.e.-M:M:.A:M:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "243",
  "_id": ObjectId("55d220dd6653c32453c0a7fd")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geabfaaaaeeabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "reasonable",
  "FR": "raisonnable",
  "IEML": "d.o.-s.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7fe")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "afabgaaaa"
  ],
  "CLASS": "1",
  "EN": "can now",
  "FR": "pouvoir maintenant",
  "IEML": "E:B:.e.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7ff")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ecacbaaaa"
  ],
  "CLASS": "4",
  "EN": "gestalt switch",
  "FR": "'gestalt switch'",
  "IEML": "g.wu.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a802")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggabgaaaagfacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "modified bioevolution",
  "FR": "bioévolution modifiée",
  "IEML": "l.e.-f.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a804")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feabfaaaaegabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "history",
  "FR": "histoire",
  "IEML": "k.o.-t.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a807")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfacfaaaaggacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "disaster",
  "FR": "désastre",
  "IEML": "f.a.-l.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a808")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeaaaaaaaeaacaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "hot",
  "FR": "chaud",
  "IEML": "s.-S:.A:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a80a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfacfaaaagfacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "growing | farming",
  "FR": "culture | élevage",
  "IEML": "f.a.-f.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a80b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geabfaaaaffabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "intuition",
  "FR": "intuition",
  "IEML": "d.o.-m.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a810")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egaceaaaagfaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "melody",
  "FR": "mélodie",
  "IEML": "t.u.-f.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a811")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geabfaaaaeeabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "reasoning",
  "FR": "raisonnement",
  "IEML": "d.o.-s.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a812")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffacfaaaaffacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "family",
  "FR": "famille",
  "IEML": "m.a.-m.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a813")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgabfaaaaegabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "in progress",
  "FR": "en progrès",
  "IEML": "n.o.-t.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a815")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfacgaaaageacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "detected | sensed",
  "FR": "détecté | capté",
  "IEML": "f.i.-d.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a817")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hdaffaaaa"
  ],
  "CLASS": "4",
  "EN": "ethical defect",
  "FR": "défaut éthique",
  "IEML": "M:O:.m.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dd6653c32453c0a818")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "acafcaaaa"
  ],
  "CLASS": "1",
  "EN": "pro | for | support",
  "FR": "pro | pour | adhésion",
  "IEML": "E:A:.c.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a819")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feabfaaaafgabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "justice",
  "FR": "justice",
  "IEML": "k.o.-n.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a81a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efacfaaaaeeacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "reader",
  "FR": "lecteur",
  "IEML": "b.a.-s.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a81c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaceaaaafeaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "prayer",
  "FR": "prière",
  "IEML": "b.u.-k.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a81d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feabcaaaa"
  ],
  "CLASS": "4",
  "EN": "community of action",
  "FR": "communauté d'action",
  "IEML": "k.wa.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a81e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feabgaaaaegacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "personal memory",
  "FR": "mémoire personnelle",
  "IEML": "k.e.-t.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a81f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egaceaaaaggaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "photograph",
  "FR": "photo",
  "IEML": "t.u.-l.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a820")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaceaaaafeaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "asked for",
  "FR": "demandé",
  "IEML": "b.u.-k.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a821")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfabfaaaafeabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "ritual",
  "FR": "rituel",
  "IEML": "f.o.-k.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a826")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfagbaaaa"
  ],
  "CLASS": "4",
  "EN": "commercial relationship | commercial contact",
  "FR": "relation commerciale | contact commercial",
  "IEML": "f.p.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a82a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffaceaaaafeaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "sacrifice",
  "FR": "sacrifice",
  "IEML": "m.u.-k.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a82b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hdachaaaa"
  ],
  "CLASS": "4",
  "EN": "condition of actual activity",
  "FR": "condition de l'activité actuelle",
  "IEML": "M:O:.A:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "18",
  "_id": ObjectId("55d220dd6653c32453c0a82d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efabgaaaafgaceaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in literary erudition",
  "FR": "compétence en érudition littéraire",
  "IEML": "b.e.-n.u.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a82e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggabgaaaaegacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "transport system",
  "FR": "système de transport",
  "IEML": "l.e.-t.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a82f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffagcaaaa"
  ],
  "CLASS": "4",
  "EN": "atmosphere of collaboration",
  "FR": "atmosphère de collaboration",
  "IEML": "m.x.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a830")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gbacfaaaa"
  ],
  "CLASS": "4",
  "EN": "community",
  "FR": "communauté",
  "IEML": "p.a.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a831")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggaceaaaaffaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "habit",
  "FR": "habitude",
  "IEML": "l.u.-m.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a833")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egaceaaaaegaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "quantity",
  "FR": "quantité",
  "IEML": "t.u.-t.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a836")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeacgaaaafeacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "harvested",
  "FR": "récolté",
  "IEML": "s.i.-k.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a837")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhaaaaaaafaacaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "western qualities",
  "FR": "qualités occidentales",
  "IEML": "M:M:.-B:.A:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("55d220dd6653c32453c0a839")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffacgaaaagfacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "skin",
  "FR": "peau",
  "IEML": "m.i.-f.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a83b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfaceaaaaeeaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "mental image",
  "FR": "image mentale",
  "IEML": "f.u.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a83d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfabgaaaaggacgaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in martial arts",
  "FR": "compétence en arts martiaux",
  "IEML": "f.e.-l.i.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a83e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffabfaaaafeabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "benevolent",
  "FR": "bienveillant",
  "IEML": "m.o.-k.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a83f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egaceaaaagfaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "sequential",
  "FR": "séquentiel",
  "IEML": "t.u.-f.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a840")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffacbaaaa"
  ],
  "CLASS": "4",
  "EN": "taste for life",
  "FR": "goût de vivre",
  "IEML": "m.wu.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a841")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geacgaaaaeeacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "electronics | photonics",
  "FR": "électronique | photonique",
  "IEML": "d.i.-s.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a842")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfaaaaaaagaacaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "bland",
  "FR": "fade",
  "IEML": "f.-T:.A:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a843")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgabgaaaa"
  ],
  "CLASS": "4",
  "EN": "leadership",
  "FR": "capacité de diriger",
  "IEML": "n.e.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a844")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efacfaaaaggacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "transportation",
  "FR": "transport",
  "IEML": "b.a.-l.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a845")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfabgaaaaeeacgaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in the body-mind disciplines",
  "FR": "compétence en les disciplines corps-esprit",
  "IEML": "f.e.-s.i.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a847")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gcabfaaaa"
  ],
  "CLASS": "4",
  "EN": "enjoyment",
  "FR": "jouissance",
  "IEML": "x.o.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a849")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ebafbaaaa"
  ],
  "CLASS": "4",
  "EN": "priority change",
  "FR": "changement de priorité",
  "IEML": "j.h.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a84a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geafcaaaa"
  ],
  "CLASS": "4",
  "EN": "authenticity",
  "FR": "authenticité",
  "IEML": "d.c.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a84b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "seizure of power",
  "FR": "prise du pouvoir",
  "IEML": "c.e.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a84c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efacgaaaafgacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "virtuoso",
  "FR": "virtuose",
  "IEML": "b.i.-n.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a84f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egaebaaaa"
  ],
  "CLASS": "4",
  "EN": "artistic reference | artistic tradition",
  "FR": "référence artistique | tradition artistique",
  "IEML": "t.j.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a852")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aib"
  ],
  "CLASS": "1",
  "EN": "logical possibility | may",
  "FR": "possibilité logique | peut",
  "IEML": "E:F:U:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "5",
  "_id": ObjectId("55d220dd6653c32453c0a853")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ecafgaaaa"
  ],
  "CLASS": "4",
  "EN": "inertia of mindsets",
  "FR": "inertie des mentalités",
  "IEML": "g.n.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a855")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeabfaaaagfabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "embodiment",
  "FR": "incarnation",
  "IEML": "s.o.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a856")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ahaffaaaa"
  ],
  "CLASS": "1",
  "EN": "relative intermediary",
  "FR": "intermediaire relatif",
  "IEML": "E:M:.m.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("55d220dd6653c32453c0a858")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efacfaaaaggacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "carrier",
  "FR": "transporteur",
  "IEML": "b.a.-l.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a85a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggacgaaaa"
  ],
  "CLASS": "4",
  "EN": "knot | connection technique",
  "FR": "noeud | technique de connection",
  "IEML": "l.i.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a85b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "adafhaaaa"
  ],
  "CLASS": "1",
  "EN": "middle",
  "FR": "milieu",
  "IEML": "E:O:.B:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dd6653c32453c0a85c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffaecaaaa"
  ],
  "CLASS": "4",
  "EN": "empathy with the public",
  "FR": "empathie avec le public",
  "IEML": "m.g.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a85f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fbaggaaaa"
  ],
  "CLASS": "4",
  "EN": "fundamentalism | xenophobia",
  "FR": "intégrisme | xénophobie",
  "IEML": "h.l.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a860")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geabgaaaafgacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "industry",
  "FR": "industrie",
  "IEML": "d.e.-n.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a864")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfaceaaaaeeaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "imagined",
  "FR": "imaginé",
  "IEML": "f.u.-s.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a865")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgabfaaaaffabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "confident",
  "FR": "confiant",
  "IEML": "n.o.-m.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a866")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfacfaaaafgacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "social protection",
  "FR": "protection sociale",
  "IEML": "f.a.-n.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a869")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feacgaaaageacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "market",
  "FR": "marché",
  "IEML": "k.i.-d.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a86a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feabgaaaagfacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "physical autonomy",
  "FR": "autonomie physique",
  "IEML": "k.e.-f.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a86b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feabfaaaaggabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "institution",
  "FR": "institution",
  "IEML": "k.o.-l.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a86c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgabgaaaaffacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "mutual understanding | harmony",
  "FR": "compréhension mutuelle | entente",
  "IEML": "n.e.-m.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a870")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feacgaaaafeacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "economic",
  "FR": "économique",
  "IEML": "k.i.-k.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a871")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeabeaaaa"
  ],
  "CLASS": "4",
  "EN": "organized knowledge",
  "FR": "connaissance organisée",
  "IEML": "s.y.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a872")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ebabeaaaa"
  ],
  "CLASS": "4",
  "EN": "hypothesis | conceptual framework",
  "FR": "hypothèse | cadre conceptuel",
  "IEML": "j.y.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a874")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gcaefaaaa"
  ],
  "CLASS": "4",
  "EN": "isolation | lack of common language | lack of communication tools",
  "FR": "isolement | absence de langage commun | absence de moyens de communication",
  "IEML": "x.b.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a875")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feadhaaaa"
  ],
  "CLASS": "4",
  "EN": "society factors",
  "FR": "facteurs de société",
  "IEML": "k.O:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dd6653c32453c0a876")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egaceaaaageaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "index",
  "FR": "index",
  "IEML": "t.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a877")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aiabfaaaa"
  ],
  "CLASS": "1",
  "EN": "optative mood",
  "FR": "mode optatif",
  "IEML": "E:F:.o.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "5",
  "_id": ObjectId("55d220dd6653c32453c0a878")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fdadhaaaa"
  ],
  "CLASS": "4",
  "EN": "condition of activity in being",
  "FR": "condition de l'activité dans l'être",
  "IEML": "B:O:.O:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "12",
  "_id": ObjectId("55d220dd6653c32453c0a879")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egaaaaaaahaadaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "seasons",
  "FR": "saisons",
  "IEML": "t.-M:.O:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dd6653c32453c0a87a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaecaaaa"
  ],
  "CLASS": "4",
  "EN": "content of the message | substance of the message",
  "FR": "contenu du message | substance du message",
  "IEML": "b.g.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a87b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feabgaaaageacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "judgement",
  "FR": "jugement",
  "IEML": "k.e.-d.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a87c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "acagbaaaa"
  ],
  "CLASS": "1",
  "EN": "definite | the",
  "FR": "défini | le",
  "IEML": "E:A:.p.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a87d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efacgaaaagfacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "circulatory system | respiratory system",
  "FR": "système circulatoire | système respiratoire",
  "IEML": "b.i.-f.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a87e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggacgaaaaeeacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "open",
  "FR": "ouvert",
  "IEML": "l.i.-s.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a87f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efabfaaaaefabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "negation",
  "FR": "négation",
  "IEML": "b.o.-b.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a880")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeabgaaaaggaceaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in reading natural signs",
  "FR": "compétence en lecture des signes naturels",
  "IEML": "s.e.-l.u.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a883")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggaaaaaaafaabaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "east",
  "FR": "est",
  "IEML": "l.-B:.U:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a884")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgacgaaaaffacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "paid work",
  "FR": "travail rémunéré",
  "IEML": "n.i.-m.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a888")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geabfaaaageabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "examined",
  "FR": "examiné",
  "IEML": "d.o.-d.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a88a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffaaaaaaafaacaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "anger",
  "FR": "colère",
  "IEML": "m.-B:.A:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a88b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efacgaaaaegacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "media library",
  "FR": "médiathèque",
  "IEML": "b.i.-t.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a88c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggaceaaaaegaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "qualitative",
  "FR": "qualitatif",
  "IEML": "l.u.-t.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a88d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egabfaaaafgabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "date",
  "FR": "date",
  "IEML": "t.o.-n.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a890")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeabfaaaaegabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "creation",
  "FR": "création",
  "IEML": "s.o.-t.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a891")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efagcaaaa"
  ],
  "CLASS": "4",
  "EN": "collaborative environment",
  "FR": "environnement collaboratif",
  "IEML": "b.x.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a892")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffaceaaaaegaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "mask",
  "FR": "masque",
  "IEML": "m.u.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a894")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geacfaaaaeeacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "student",
  "FR": "étudiant",
  "IEML": "d.a.-s.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a895")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feacfaaaaeeacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "diplomat",
  "FR": "diplomate",
  "IEML": "k.a.-s.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a896")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaaaaaaaeaabaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "form | shape",
  "FR": "forme",
  "IEML": "b.-S:.U:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a898")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feaccaaaa"
  ],
  "CLASS": "4",
  "EN": "residential community",
  "FR": "communauté de résidence",
  "IEML": "k.we.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a899")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efabfaaaaeeabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "interpreted",
  "FR": "interprété",
  "IEML": "b.o.-s.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a89a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hdacgaaaa"
  ],
  "CLASS": "4",
  "EN": "condition of efficiency",
  "FR": "condition de l'efficacité",
  "IEML": "M:O:.i.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dd6653c32453c0a89b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfacfaaaageacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "technician",
  "FR": "technicien",
  "IEML": "f.a.-d.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a89f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bcafgaaaa"
  ],
  "CLASS": "2",
  "EN": "cultivate one's motivation",
  "FR": "cultiver sa motivation",
  "IEML": "wa.n.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8a0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeaceaaaafgaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "common name",
  "FR": "nom commun",
  "IEML": "s.u.-n.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8a1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aeacbaaaa"
  ],
  "CLASS": "1",
  "EN": "first person masculine",
  "FR": "première personne masculin",
  "IEML": "E:S:.wu.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8a2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hdadhaaaa"
  ],
  "CLASS": "4",
  "EN": "condition of activity",
  "FR": "condition de l'activité",
  "IEML": "M:O:.O:M:.-",
  "LAYER": "2",
  "PARADIGM": "1",
  "TAILLE": "36",
  "_id": ObjectId("55d220dd6653c32453c0a8a4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egacgaaaaefacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "document",
  "FR": "document",
  "IEML": "t.i.-b.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8a5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egaceaaaafgaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "unique",
  "FR": "unique",
  "IEML": "t.u.-n.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8a6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeaecaaaa"
  ],
  "CLASS": "4",
  "EN": "communication project | communication dimension of a creation-innovation project",
  "FR": "projet de communication | dimension de communication d'un projet de création-innovation",
  "IEML": "s.g.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8a7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffabgaaaafeacfaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in collaborative attitude",
  "FR": "compétence en attitude collaborative",
  "IEML": "m.e.-k.a.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8a8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgabfaaaaffabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "faith",
  "FR": "foi",
  "IEML": "n.o.-m.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8a9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geaceaaaaffaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "physical reaction",
  "FR": "réaction physique",
  "IEML": "d.u.-m.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8aa")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geafbaaaa"
  ],
  "CLASS": "4",
  "EN": "cultural refinement",
  "FR": "raffinement culturel",
  "IEML": "d.h.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8ad")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeaceaaaaggaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "obscure",
  "FR": "obscur",
  "IEML": "s.u.-l.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8ae")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "abagcaaaa"
  ],
  "CLASS": "1",
  "EN": "without",
  "FR": "sans",
  "IEML": "E:U:.x.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8af")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egabfaaaaegabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "in transition | temporal",
  "FR": "en transition | temporel",
  "IEML": "t.o.-t.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8b2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ahaghaaaa"
  ],
  "CLASS": "1",
  "EN": "termination",
  "FR": "terminaison",
  "IEML": "E:M:.T:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("55d220dd6653c32453c0a8b3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egabgaaaa"
  ],
  "CLASS": "4",
  "EN": "ability to convince",
  "FR": "capacité de convaincre",
  "IEML": "t.e.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8b4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feaceaaaafgaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "totem",
  "FR": "totem",
  "IEML": "k.u.-n.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8b5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gbaccaaaa"
  ],
  "CLASS": "4",
  "EN": "irreversible consequence",
  "FR": "conséquence irréversible",
  "IEML": "p.we.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8b6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fcaebaaaa"
  ],
  "CLASS": "4",
  "EN": "teaching transformation",
  "FR": "transformation de l'enseignement",
  "IEML": "c.j.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8b7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeabgaaaaffaceaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "to play",
  "FR": "jouer comédie",
  "IEML": "s.e.-m.u.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8b8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geabgaaaaeeacgaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in practical ingenuity",
  "FR": "compétence en inventivité pratique",
  "IEML": "d.e.-s.i.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8b9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geaceaaaaefaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "warning",
  "FR": "avertissement",
  "IEML": "d.u.-b.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8ba")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "abaddaaaa"
  ],
  "CLASS": "1",
  "EN": "demonstrative pronoun",
  "FR": "pronom démonstratif",
  "IEML": "E:U:.O:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220dd6653c32453c0a8bc")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaceaaaaeeaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "similar",
  "FR": "semblable",
  "IEML": "b.u.-s.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8be")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeabgaaaaffaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "actor's play",
  "FR": "jeu d'acteur",
  "IEML": "s.e.-m.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8c1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gbaffaaaa"
  ],
  "CLASS": "4",
  "EN": "exploitation",
  "FR": "exploitation",
  "IEML": "p.m.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8c2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhaccaaaa"
  ],
  "CLASS": "4",
  "EN": "sources of meaning in sustainability",
  "FR": "sources du sens dans la durabilité",
  "IEML": "M:M:.we.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("55d220dd6653c32453c0a8c3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfabgaaaaegacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "safe driving",
  "FR": "conduite sûre",
  "IEML": "f.e.-t.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8c7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egabgaaaaggaceaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in scientific research",
  "FR": "compétence en recherche scientifique",
  "IEML": "t.e.-l.u.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8c8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggabfaaaaffabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "liberty",
  "FR": "liberté",
  "IEML": "l.o.-m.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8c9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfaceaaaaffaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "tear",
  "FR": "larme",
  "IEML": "f.u.-m.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8ca")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaceaaaaffaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "voice",
  "FR": "voix",
  "IEML": "b.u.-m.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8cc")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggabfaaaaefabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "composition",
  "FR": "composition",
  "IEML": "l.o.-b.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8cd")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggacfaaaafgacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "defense",
  "FR": "défense",
  "IEML": "l.a.-n.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8cf")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfaceaaaaefaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "accent",
  "FR": "accent",
  "IEML": "f.u.-b.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8d1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "afacbaaaa"
  ],
  "CLASS": "1",
  "EN": "second person masculine",
  "FR": "deuxième personne masculin",
  "IEML": "E:B:.wu.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8d2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggaddaaaa"
  ],
  "CLASS": "4",
  "EN": "sources of meaning in liberty | sources of meaning in responsibility",
  "FR": "sources du sens dans la liberté | sources du sens dans la responsabilité",
  "IEML": "l.O:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220dd6653c32453c0a8d3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeagcaaaa"
  ],
  "CLASS": "4",
  "EN": "technical project | technical dimension of a creation-innovation project",
  "FR": "projet technique | dimension technique d'un projet de création-innovation",
  "IEML": "s.x.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8d6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geadhaaaa"
  ],
  "CLASS": "4",
  "EN": "truth factors",
  "FR": "facteurs de vérité",
  "IEML": "d.O:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dd6653c32453c0a8d7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ecaefaaaa"
  ],
  "CLASS": "4",
  "EN": "transmission error",
  "FR": "erreur de transmission",
  "IEML": "g.b.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8d9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "adafcaaaa"
  ],
  "CLASS": "1",
  "EN": "manner of choice",
  "FR": "manière de choix",
  "IEML": "E:O:.c.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("55d220dd6653c32453c0a8db")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egacgaaaaegacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "recorded",
  "FR": "enregistré",
  "IEML": "t.i.-t.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8dc")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhabfaaaahhabfaaaaaaaaaaaaa",
    "hhabfaaaahhabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "anthropological functions and qualities",
  "FR": "fonctions et qualités anthropologiques",
  "IEML": "M:M:.o.-M:M:.o.-E:.-+s.u.-'",
  "LAYER": "3",
  "PARADIGM": "1",
  "TAILLE": "162",
  "_id": ObjectId("55d220dd6653c32453c0a8dd")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geabgaaaaegacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "well-maintained material",
  "FR": "matériel bien entretenu",
  "IEML": "d.e.-t.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8df")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aae"
  ],
  "CLASS": "1",
  "EN": "nominative | subject-verb relation",
  "FR": "nominatif | relation verbe-sujet",
  "IEML": "E:E:S:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8e0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efacgaaaagfacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "distributed",
  "FR": "distribué",
  "IEML": "b.i.-f.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8e1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geabfaaaafeabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "security",
  "FR": "sécurité",
  "IEML": "d.o.-k.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8e2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggaceaaaa"
  ],
  "CLASS": "4",
  "EN": "trace",
  "FR": "trace",
  "IEML": "l.u.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8e3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "abaecaaaa"
  ],
  "CLASS": "1",
  "EN": "other | different",
  "FR": "autre | différent",
  "IEML": "E:U:.g.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8e4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgaceaaaageaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "tag",
  "FR": "étiquette",
  "IEML": "n.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8e6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggabfaaaaffabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "free",
  "FR": "libre",
  "IEML": "l.o.-m.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8e7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffahdaaaa"
  ],
  "CLASS": "4",
  "EN": "affective & ethical reverberations of a creation-innovation cycle",
  "FR": "réverbération affective & éthique d'un cycle de création-innovation",
  "IEML": "m.M:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dd6653c32453c0a8e8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ebaffaaaa"
  ],
  "CLASS": "4",
  "EN": "banality | unfelt expression",
  "FR": "banalité | expression non-sentie",
  "IEML": "j.m.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8e9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gcafgaaaa"
  ],
  "CLASS": "4",
  "EN": "obsolescence | wear",
  "FR": "obsolescence | désuétude | usure",
  "IEML": "x.n.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8ea")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efabfaaaagfabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "courageous",
  "FR": "courageux",
  "IEML": "b.o.-f.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8eb")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ebahdaaaa"
  ],
  "CLASS": "4",
  "EN": "transformation on knowledge basis",
  "FR": "transformation sur base de savoir",
  "IEML": "j.M:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dd6653c32453c0a8ef")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeabfaaaafeabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "collective intelligence",
  "FR": "intelligence collective",
  "IEML": "s.o.-k.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8f1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ahaggaaaa"
  ],
  "CLASS": "1",
  "EN": "absolute termination",
  "FR": "terminaison absolue",
  "IEML": "E:M:.l.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("55d220dd6653c32453c0a8f3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aeb"
  ],
  "CLASS": "1",
  "EN": "possibility",
  "FR": "possibilité",
  "IEML": "E:S:U:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8f4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "agf"
  ],
  "CLASS": "1",
  "EN": "somewhere",
  "FR": "quelque part",
  "IEML": "E:T:B:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8f5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgacfaaaafgacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "spiritual community",
  "FR": "communauté spirituelle",
  "IEML": "n.a.-n.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8f7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geaceaaaaeeaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "mapped",
  "FR": "cartographié",
  "IEML": "d.u.-s.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8f8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffabgaaaagfacfaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in producing well-being",
  "FR": "compétence en production du bien-être",
  "IEML": "m.e.-f.a.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8fb")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egacfaaaaefacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "editing | publishing",
  "FR": "édition | publication",
  "IEML": "t.a.-b.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8fe")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfabgaaaaffacgaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in subtlety of the senses",
  "FR": "compétence en subtilité des sens",
  "IEML": "f.e.-m.i.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8ff")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ecaeeaaaa"
  ],
  "CLASS": "4",
  "EN": "noise",
  "FR": "bruit",
  "IEML": "g.s.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a900")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggaceaaaageaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "sample",
  "FR": "échantillon",
  "IEML": "l.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a901")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggacgaaaafeacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "real-estate | land",
  "FR": "immobilier | foncier",
  "IEML": "l.i.-k.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a908")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feabfaaaaffabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "friendly",
  "FR": "amical",
  "IEML": "k.o.-m.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a90c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfaiaaaaa"
  ],
  "CLASS": "2",
  "EN": "perform metabolic function",
  "FR": "accomplir une fonction métabolique",
  "IEML": "a.F:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "5",
  "_id": ObjectId("55d220dd6653c32453c0a90f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efabfaaaafeabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "communication",
  "FR": "communication",
  "IEML": "b.o.-k.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a911")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feacgaaaaeeacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "to be recycled",
  "FR": "à  recycler",
  "IEML": "k.i.-s.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a912")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efacgaaaageacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "displayed",
  "FR": "affiché",
  "IEML": "b.i.-d.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a913")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfaceaaaa"
  ],
  "CLASS": "4",
  "EN": "sensation",
  "FR": "sensation",
  "IEML": "f.u.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a915")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeacfaaaaegacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "computer scientist",
  "FR": "informaticien",
  "IEML": "s.a.-t.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a916")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geaaaaaaagaacaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "viscous | slimy",
  "FR": "visqueux | gluant",
  "IEML": "d.-T:.A:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a91a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaccaaaa"
  ],
  "CLASS": "4",
  "EN": "media climate",
  "FR": "climat médiatique",
  "IEML": "b.we.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a91b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fbaccaaaa"
  ],
  "CLASS": "4",
  "EN": "situation reversa",
  "FR": "retournement de situation",
  "IEML": "h.we.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a91d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffaaaaaaaeaacaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "surprise | wonder",
  "FR": "surprise | étonnement",
  "IEML": "m.-S:.A:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a91e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geabgaaaafgacgaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in the mastery of production",
  "FR": "compétence en la maîtrise de la production",
  "IEML": "d.e.-n.i.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a920")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feacgaaaaffacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "play symbol",
  "FR": "symbole de jeu",
  "IEML": "k.i.-m.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a921")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fcabbaaaa"
  ],
  "CLASS": "4",
  "EN": "personal maturation",
  "FR": "maturation personnelle",
  "IEML": "c.wo.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a923")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "age"
  ],
  "CLASS": "1",
  "EN": "nowhere",
  "FR": "nulle part",
  "IEML": "E:T:S:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a924")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hdabgaaaa"
  ],
  "CLASS": "4",
  "EN": "conditions of power",
  "FR": "conditions du pouvoir",
  "IEML": "M:O:.e.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dd6653c32453c0a92b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geabeaaaa"
  ],
  "CLASS": "4",
  "EN": "knowledge of facts",
  "FR": "connaissance factuelle",
  "IEML": "d.y.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a92c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feabgaaaaggacfaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in self-protection",
  "FR": "compétence en auto-protection",
  "IEML": "k.e.-l.a.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a92e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efabfaaaaefabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "opposite",
  "FR": "contraire",
  "IEML": "b.o.-b.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a930")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geacgaaaagfacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "perceived",
  "FR": "perçu",
  "IEML": "d.i.-f.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a931")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfabfaaaaefabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "gesture | blow",
  "FR": "geste | coup",
  "IEML": "f.o.-b.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a932")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egacfaaaaegacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "founder",
  "FR": "fondateur",
  "IEML": "t.a.-t.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a933")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeafcaaaa"
  ],
  "CLASS": "4",
  "EN": "political project | political dimension of a creation-innovation project",
  "FR": "projet politique | dimension politique d'un projet de création-innovation",
  "IEML": "s.c.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a934")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhabcaaaa"
  ],
  "CLASS": "4",
  "EN": "practical sources of meaning",
  "FR": "sources pratiques du sens",
  "IEML": "M:M:.wa.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("55d220dd6653c32453c0a935")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgabgaaaaeeacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "collective approach",
  "FR": "démarche collective",
  "IEML": "n.e.-s.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a936")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geacgaaaafeacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "money",
  "FR": "monnaie",
  "IEML": "d.i.-k.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a937")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feabgaaaaggacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "personal security | personal safety",
  "FR": "sécurité personnelle",
  "IEML": "k.e.-l.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a93a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggacfaaaafeacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "army",
  "FR": "armée",
  "IEML": "l.a.-k.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a93b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "edadhaaaa"
  ],
  "CLASS": "4",
  "EN": "condition of activity in sign",
  "FR": "condition de l'activité dans le signe",
  "IEML": "S:O:.O:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "12",
  "_id": ObjectId("55d220dd6653c32453c0a93c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egacfaaaa"
  ],
  "CLASS": "4",
  "EN": "scribe",
  "FR": "scribe",
  "IEML": "t.a.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a93d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfacfaaaaeeacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "consultant",
  "FR": "consultant",
  "IEML": "f.a.-s.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a93f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfabgaaaagfacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "physical performance",
  "FR": "performance physique",
  "IEML": "f.e.-f.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a941")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gda"
  ],
  "CLASS": "4",
  "EN": "thing in mutation",
  "FR": "chose en mutation",
  "IEML": "T:O:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("55d220dd6653c32453c0a942")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfaaaaaaaeaabaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "salty",
  "FR": "salé",
  "IEML": "f.-S:.U:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a943")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gbacgaaaa"
  ],
  "CLASS": "4",
  "EN": "modeling | rehearsal",
  "FR": "modélisation | répétition",
  "IEML": "p.i.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a944")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fcafgaaaa"
  ],
  "CLASS": "4",
  "EN": "political stagnation",
  "FR": "stagnation politique",
  "IEML": "c.n.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a945")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfafbaaaa"
  ],
  "CLASS": "4",
  "EN": "fruitful encounter",
  "FR": "rencontre fructueuse",
  "IEML": "f.h.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a946")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hdafgaaaa"
  ],
  "CLASS": "4",
  "EN": "vitality deficiency",
  "FR": "défaut de vitalité",
  "IEML": "M:O:.n.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dd6653c32453c0a947")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggabgaaaafeacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "prosperity",
  "FR": "prospérité",
  "IEML": "l.e.-k.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a949")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgacgaaaaeeacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "engine",
  "FR": "moteur",
  "IEML": "n.i.-s.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a94a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgacgaaaaffacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "added value",
  "FR": "valeur ajoutée",
  "IEML": "n.i.-m.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a94d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ahg"
  ],
  "CLASS": "1",
  "EN": "distributive plus",
  "FR": "plus distributif",
  "IEML": "E:M:T:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("55d220dd6653c32453c0a94e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeacgaaaaegacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "filter",
  "FR": "filtre",
  "IEML": "s.i.-t.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a94f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efabfaaaageabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "clear",
  "FR": "clair",
  "IEML": "b.o.-d.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a951")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggabfaaaafeabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "territorial",
  "FR": "territorial",
  "IEML": "l.o.-k.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a953")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhahdaaaa"
  ],
  "CLASS": "4",
  "EN": "creation-innovation cycle",
  "FR": "cycle de création-innovation",
  "IEML": "M:M:.M:O:.-",
  "LAYER": "2",
  "PARADIGM": "1",
  "TAILLE": "54",
  "_id": ObjectId("55d220dd6653c32453c0a954")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feacfaaaageacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "sale",
  "FR": "vente",
  "IEML": "k.a.-d.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a956")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fbageaaaa"
  ],
  "CLASS": "4",
  "EN": "cultural coarseness | poorness",
  "FR": "grossièreté | pauvreté culturelle",
  "IEML": "h.d.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a957")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fdaebaaaa"
  ],
  "CLASS": "4",
  "EN": "B:O:.j.- test",
  "FR": "B:O:.j.- test",
  "IEML": "B:O:.j.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("5643d9da9b2d5747911911a0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aiaefaaaa"
  ],
  "CLASS": "1",
  "EN": "relation of exi-stance",
  "FR": "relation d'exi-stance",
  "IEML": "E:F:.b.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "5",
  "_id": ObjectId("5646686e9b2d5747911911a2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aiageaaaa"
  ],
  "CLASS": "1",
  "EN": "tension of insi-stance",
  "FR": "tension d'insi-stance",
  "IEML": "E:F:.d.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "5",
  "_id": ObjectId("56414a919b2d57479119119f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aiagfaaaa"
  ],
  "CLASS": "1",
  "EN": "relation of insi-stance",
  "FR": "relation d'insi-stance",
  "IEML": "E:F:.f.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "5",
  "_id": ObjectId("5647d795c1d763d245621bc7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aiaggaaaa"
  ],
  "CLASS": "1",
  "EN": "structure of insi-stance",
  "FR": "structure d'insi-stance",
  "IEML": "E:F:.l.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "5",
  "_id": ObjectId("5647d7cac1d763d245621bc8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aeagfaaaa"
  ],
  "CLASS": "1",
  "EN": "arrival point",
  "FR": "point d'arrivée",
  "IEML": "E:S:.f.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0acf9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aiaehaaaa"
  ],
  "CLASS": "1",
  "EN": "exi-stance (spatial situation)",
  "FR": "exi-stance (spatial situation)",
  "IEML": "E:F:.S:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "15",
  "_id": ObjectId("564d02adc1d763d245621bc9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "abaccaaaa"
  ],
  "CLASS": "1",
  "EN": "demonstrative feminine",
  "FR": "démonstratif féminin",
  "IEML": "E:U:.we.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0aca5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "agabbaaaa"
  ],
  "CLASS": "1",
  "EN": "third person singular | it",
  "FR": "troisième personne singulier",
  "IEML": "E:T:.wo.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a69a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "agaccaaaa"
  ],
  "CLASS": "1",
  "EN": "third person feminine",
  "FR": "troisième personne féminin",
  "IEML": "E:T:.we.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad25")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aeabcaaaa"
  ],
  "CLASS": "1",
  "EN": "first person plural | us",
  "FR": "première personne pluriel | nous",
  "IEML": "E:S:.wa.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa40")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aeaceaaaa"
  ],
  "CLASS": "1",
  "EN": "will express",
  "FR": "exprimer au futur",
  "IEML": "E:S:.u.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a857")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "afacgaaaa"
  ],
  "CLASS": "1",
  "EN": "must do now",
  "FR": "devoir faire maintenant",
  "IEML": "E:B:.i.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a88f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "afagcaaaa"
  ],
  "CLASS": "1",
  "EN": "agent",
  "FR": "agent",
  "IEML": "E:B:.x.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0acf8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeaccaaaa"
  ],
  "CLASS": "4",
  "EN": "concern for the environment",
  "FR": "souci de l'environnemt",
  "IEML": "s.we.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a959")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gcacbaaaa"
  ],
  "CLASS": "4",
  "EN": "new instrument of observation",
  "FR": "nouvel instrument d'observation",
  "IEML": "x.wu.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a95b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeaddaaaa"
  ],
  "CLASS": "4",
  "EN": "sources of meaning in thought",
  "FR": "sources du sens dans la pensée",
  "IEML": "s.O:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220dd6653c32453c0a95e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ecagfaaaa"
  ],
  "CLASS": "4",
  "EN": "censorship | message betrayal",
  "FR": "censure | trahison du message",
  "IEML": "g.f.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a961")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "abafcaaaa"
  ],
  "CLASS": "1",
  "EN": "anti | against",
  "FR": "anti | contre",
  "IEML": "E:U:.c.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a962")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggacgaaaaeeacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "opening | door | window",
  "FR": "ouverture | porte | fenêtre",
  "IEML": "l.i.-s.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a963")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egabbaaaa"
  ],
  "CLASS": "4",
  "EN": "bringing together",
  "FR": "mise en relation",
  "IEML": "t.wo.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a964")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aih"
  ],
  "CLASS": "1",
  "EN": "gradient adverb",
  "FR": "adverbe de gradient",
  "IEML": "E:F:M:.",
  "LAYER": "1",
  "PARADIGM": "1",
  "TAILLE": "15",
  "_id": ObjectId("55d220dd6653c32453c0a965")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeacfaaaaggacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "innovation",
  "FR": "innovation",
  "IEML": "s.a.-l.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a967")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "adaecaaaa"
  ],
  "CLASS": "1",
  "EN": "manner of identity",
  "FR": "manière d'identité",
  "IEML": "E:O:.g.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("55d220dd6653c32453c0a968")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egacfaaaaeeacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "translation",
  "FR": "traduction",
  "IEML": "t.a.-s.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a969")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feacgaaaaggacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "house | building",
  "FR": "maison | bâtiment",
  "IEML": "k.i.-l.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a96a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffacgaaaafeacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "playful",
  "FR": "ludique",
  "IEML": "m.i.-k.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a96b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egabfaaaageabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "relevance",
  "FR": "pertinence",
  "IEML": "t.o.-d.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a96e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffabfaaaa"
  ],
  "CLASS": "4",
  "EN": "emotional involvement",
  "FR": "implication émotionnelle",
  "IEML": "m.o.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a96f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hdaccaaaa"
  ],
  "CLASS": "4",
  "EN": "environment mutation",
  "FR": "mutation de l'environnement",
  "IEML": "M:O:.we.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dd6653c32453c0a970")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ebacbaaaa"
  ],
  "CLASS": "4",
  "EN": "new perception grid",
  "FR": "nouvelle grille de perception",
  "IEML": "j.wu.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a972")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egacgaaaaffacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "treasure",
  "FR": "trésor",
  "IEML": "t.i.-m.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a974")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gcaebaaaa"
  ],
  "CLASS": "4",
  "EN": "computation evolution",
  "FR": "évolution de la computation",
  "IEML": "x.j.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a975")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gcadhaaaa"
  ],
  "CLASS": "4",
  "EN": "material process",
  "FR": "processus matériel",
  "IEML": "x.O:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dd6653c32453c0a976")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geacfaaaagfacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "lesson",
  "FR": "leçon",
  "IEML": "d.a.-f.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a979")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efacfaaaagfacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "nurse | caregiver",
  "FR": "infirmier | soignant",
  "IEML": "b.a.-f.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a97b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feabfaaaa"
  ],
  "CLASS": "4",
  "EN": "desire for social bond",
  "FR": "désir de lien social",
  "IEML": "k.o.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a97d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgadhaaaa"
  ],
  "CLASS": "4",
  "EN": "world factors",
  "FR": "facteurs de monde",
  "IEML": "n.O:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dd6653c32453c0a97f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaddaaaa"
  ],
  "CLASS": "4",
  "EN": "sources of meaning in communication",
  "FR": "sources du sens dans la communication",
  "IEML": "b.O:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220dd6653c32453c0a980")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggacgaaaaffacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "furnished",
  "FR": "meublé",
  "IEML": "l.i.-m.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a981")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "adagcaaaa"
  ],
  "CLASS": "1",
  "EN": "manner of presence",
  "FR": "manière de présence",
  "IEML": "E:O:.x.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("55d220dd6653c32453c0a982")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geabgaaaagfacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "operation on the body",
  "FR": "opération sur le corps",
  "IEML": "d.e.-f.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a985")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ahafbaaaa"
  ],
  "CLASS": "1",
  "EN": "virtual systemic cause",
  "FR": "cause systémique virtuelle",
  "IEML": "E:M:.h.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("55d220dd6653c32453c0a986")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feabfaaaafeabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "peaceful",
  "FR": "pacifique",
  "IEML": "k.o.-k.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a987")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfabfaaaaeeabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "imaginary",
  "FR": "imaginaire",
  "IEML": "f.o.-s.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a988")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeabfaaaaegabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "created",
  "FR": "créé",
  "IEML": "s.o.-t.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a98c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geacfaaaaefacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "producer",
  "FR": "producteur",
  "IEML": "d.a.-b.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a98d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggabgaaaafgacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "tool | machine",
  "FR": "outil | machine",
  "IEML": "l.e.-n.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a98e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaaaaaaagaacaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "dark",
  "FR": "sombre",
  "IEML": "b.-T:.A:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a98f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffabgaaaaggacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "power of the law",
  "FR": "force de la loi",
  "IEML": "m.e.-l.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a992")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffabfaaaaegabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "loyalty",
  "FR": "loyauté",
  "IEML": "m.o.-t.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a997")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "acagcaaaa"
  ],
  "CLASS": "1",
  "EN": "with",
  "FR": "avec",
  "IEML": "E:A:.x.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a998")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feaaaaaaaeaacaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "auditive signal",
  "FR": "signal auditif",
  "IEML": "k.-S:.A:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a99a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffacgaaaaggacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "textile | clothing",
  "FR": "textile | vêtement",
  "IEML": "m.i.-l.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a99d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fbaceaaaa"
  ],
  "CLASS": "4",
  "EN": "content of the discourse",
  "FR": "contenu du discours",
  "IEML": "h.u.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a99f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aiacbaaaa"
  ],
  "CLASS": "1",
  "EN": "masculine pronoun",
  "FR": "pronom masculin",
  "IEML": "E:F:.wu.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "5",
  "_id": ObjectId("55d220dd6653c32453c0a9a1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfabeaaaa"
  ],
  "CLASS": "4",
  "EN": "body intelligence",
  "FR": "intelligence du corps",
  "IEML": "f.y.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a9a3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffacgaaaaffacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "fetishized",
  "FR": "fétichisé",
  "IEML": "m.i.-m.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a9a4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfaaaaaaafaabaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "sour | acidic",
  "FR": "acide",
  "IEML": "f.-B:.U:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a9a5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhabfaaaa"
  ],
  "CLASS": "4",
  "EN": "will to be",
  "FR": "vouloir être",
  "IEML": "M:M:.o.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("55d220dd6653c32453c0a9a7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaceaaaaefaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "hypertext",
  "FR": "hypertexte",
  "IEML": "b.u.-b.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a9a8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feacfaaaaffacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "brother | sister",
  "FR": "frère | soeur",
  "IEML": "k.a.-m.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a9ab")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfabbaaaa"
  ],
  "CLASS": "4",
  "EN": "intellectual gymnastics",
  "FR": "exercice intellectuel",
  "IEML": "f.wo.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a9ac")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeabfaaaafgabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "meditation",
  "FR": "méditation",
  "IEML": "s.o.-n.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a9ad")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgacfaaaafeacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "reform",
  "FR": "réforme",
  "IEML": "n.a.-k.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a9ae")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egaceaaaaggaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "photographed",
  "FR": "photographié",
  "IEML": "t.u.-l.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a9b0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efagbaaaa"
  ],
  "CLASS": "4",
  "EN": "consumers conversations about the product",
  "FR": "conversations des consommateurs sur le produit",
  "IEML": "b.p.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a9b1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgacgaaaaefacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "lighting",
  "FR": "éclairage",
  "IEML": "n.i.-b.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a9b2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffaceaaaafgaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "subject",
  "FR": "sujet",
  "IEML": "m.u.-n.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a9b3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgabgaaaaefacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "community image",
  "FR": "image de la communauté",
  "IEML": "n.e.-b.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a9b5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfacgaaaafeacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "food | drink",
  "FR": "nourriture | boisson",
  "IEML": "f.i.-k.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a9b6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hdabhaaaa"
  ],
  "CLASS": "4",
  "EN": "condition of virtual activity",
  "FR": "condition de l'activité virtuelle",
  "IEML": "M:O:.U:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "18",
  "_id": ObjectId("55d220dd6653c32453c0a9b8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "acaecaaaa"
  ],
  "CLASS": "1",
  "EN": "same | identical",
  "FR": "même | identique",
  "IEML": "E:A:.g.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a9b9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fcahdaaaa"
  ],
  "CLASS": "4",
  "EN": "transformation on social basis",
  "FR": "transformation sur base sociale",
  "IEML": "c.M:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dd6653c32453c0a9ba")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geacgaaaageacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "quantified",
  "FR": "quantifié",
  "IEML": "d.i.-d.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a9bd")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hdacfaaaa"
  ],
  "CLASS": "4",
  "EN": "conditions of integration",
  "FR": "conditions de l'intégration",
  "IEML": "M:O:.a.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dd6653c32453c0a9be")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efabgaaaageaceaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in documentation",
  "FR": "compétence en documentation",
  "IEML": "b.e.-d.u.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a9c0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffacfaaaageacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "partnership",
  "FR": "partenariat",
  "IEML": "m.a.-d.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a9c2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fbabcaaaa"
  ],
  "CLASS": "4",
  "EN": "situation reframing",
  "FR": "recadrage de la situation",
  "IEML": "h.wa.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0a9c4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgacgaaaafeacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "for sale",
  "FR": "à  vendre",
  "IEML": "n.i.-k.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0a9c5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeaceaaaafgaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "conceptual",
  "FR": "conceptuel",
  "IEML": "s.u.-n.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0a9c6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffabgaaaaegacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "strength of personal ties",
  "FR": "force des liens personnels",
  "IEML": "m.e.-t.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0a9cb")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggacgaaaaegacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "closure | bag",
  "FR": "fermeture | sac",
  "IEML": "l.i.-t.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0a9cc")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egacgaaaaeeacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "in transit",
  "FR": "en transit",
  "IEML": "t.i.-s.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0a9ce")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egacfaaaaggacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "archivist",
  "FR": "archiviste",
  "IEML": "t.a.-l.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0a9cf")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efabfaaaaegabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "promise",
  "FR": "promesse",
  "IEML": "b.o.-t.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0a9d1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aeadhaaaa"
  ],
  "CLASS": "1",
  "EN": "future tense",
  "FR": "temps futur",
  "IEML": "E:S:.O:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220de6653c32453c0a9d2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeabfaaaa"
  ],
  "CLASS": "4",
  "EN": "concern for thought",
  "FR": "souci de la pensée",
  "IEML": "s.o.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0a9d3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "c"
  ],
  "CLASS": "2",
  "EN": "actual",
  "FR": "actuel",
  "IEML": "A:",
  "LAYER": "0",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0a9d4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfaceaaaaffaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "sentimental",
  "FR": "sentimental",
  "IEML": "f.u.-m.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0a9d6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ecacgaaaa"
  ],
  "CLASS": "4",
  "EN": "tactics",
  "FR": "tactique",
  "IEML": "g.i.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0a9d7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feaceaaaaggaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "relic | mortal remains",
  "FR": "relique | dépouille",
  "IEML": "k.u.-l.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0a9d8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aeagcaaaa"
  ],
  "CLASS": "1",
  "EN": "part",
  "FR": "partie",
  "IEML": "E:S:.x.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0a9d9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feacfaaaa"
  ],
  "CLASS": "4",
  "EN": "chief",
  "FR": "chef",
  "IEML": "k.a.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0a9da")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "acagfaaaa"
  ],
  "CLASS": "1",
  "EN": "behind",
  "FR": "derrière",
  "IEML": "E:A:.f.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0a9db")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efacfaaaaefacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "literature",
  "FR": "littérature",
  "IEML": "b.a.-b.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0a9df")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ace"
  ],
  "CLASS": "1",
  "EN": "a few | slightly",
  "FR": "peu",
  "IEML": "E:A:S:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0a9e1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fbaecaaaa"
  ],
  "CLASS": "4",
  "EN": "new communication form",
  "FR": "nouvelle forme de communication",
  "IEML": "h.g.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0a9e2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ebafcaaaa"
  ],
  "CLASS": "4",
  "EN": "learning transformation",
  "FR": "transformation de l'apprentissage",
  "IEML": "j.c.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0a9e4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egabfaaaafgabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "calendar",
  "FR": "calendrier",
  "IEML": "t.o.-n.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0a9e5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggacfaaaafeacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "officer",
  "FR": "officier",
  "IEML": "l.a.-k.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0a9e6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "abagbaaaa"
  ],
  "CLASS": "1",
  "EN": "indefinite | a | some",
  "FR": "indéfini | un | quelque",
  "IEML": "E:U:.p.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0a9e7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgaceaaaafgaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "unknown",
  "FR": "inconnu",
  "IEML": "n.u.-n.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0a9e8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gbaceaaaa"
  ],
  "CLASS": "4",
  "EN": "common context",
  "FR": "contexte commun",
  "IEML": "p.u.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0a9e9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "f"
  ],
  "CLASS": "4",
  "EN": "being",
  "FR": "être",
  "IEML": "B:",
  "LAYER": "0",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0a9ea")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeacgaaaagfacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "nervous system | immune system",
  "FR": "système nerveux | système immunitaire",
  "IEML": "s.i.-f.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0a9ec")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ebaegaaaa"
  ],
  "CLASS": "4",
  "EN": "archaism",
  "FR": "archaïsme",
  "IEML": "j.t.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0a9ef")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geabgaaaagfacgaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in surgery | competence in body care",
  "FR": "compétence en chirurgie | compétence en soins du corps",
  "IEML": "d.e.-f.i.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0a9f2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feacfaaaaegacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "secretary",
  "FR": "secrétaire",
  "IEML": "k.a.-t.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0a9f3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egacgaaaageacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "clock",
  "FR": "horloge",
  "IEML": "t.i.-d.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0a9f4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feabgaaaaefacfaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in speaking sincerely",
  "FR": "compétence en parole sincère",
  "IEML": "k.e.-b.a.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0a9f6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geabgaaaaegacgaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in maintenance",
  "FR": "compétence en maintenance",
  "IEML": "d.e.-t.i.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0a9f7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "adb"
  ],
  "CLASS": "1",
  "EN": "logical may",
  "FR": "peut logique",
  "IEML": "E:O:U:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("55d220de6653c32453c0a9f9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffabfaaaaegabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "loyal",
  "FR": "loyal",
  "IEML": "m.o.-t.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0a9fa")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeaceaaaaffaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "dream-like",
  "FR": "onirique",
  "IEML": "s.u.-m.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0a9fd")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efabgaaaageaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "research object",
  "FR": "objet de recherche",
  "IEML": "b.e.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0a9ff")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgabeaaaa"
  ],
  "CLASS": "4",
  "EN": "knowledge of principles",
  "FR": "connaissance des principes",
  "IEML": "n.y.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa00")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaceaaaaegaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "programmed",
  "FR": "programmé",
  "IEML": "b.u.-t.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa01")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggacgaaaaffacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "furniture",
  "FR": "meuble",
  "IEML": "l.i.-m.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa03")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fbagcaaaa"
  ],
  "CLASS": "4",
  "EN": "new application | new candidacy",
  "FR": "nouvelle candidature",
  "IEML": "h.x.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa04")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeabfaaaaefabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "inspired",
  "FR": "inspiré",
  "IEML": "s.o.-b.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa05")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fcacbaaaa"
  ],
  "CLASS": "4",
  "EN": "bodily transformation",
  "FR": "transformation corporelle",
  "IEML": "c.wu.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa06")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffacgaaaafeacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "piece of a game",
  "FR": "pièce d'un jeu",
  "IEML": "m.i.-k.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa07")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geabfaaaa"
  ],
  "CLASS": "4",
  "EN": "valuation of truth",
  "FR": "valorisation de la vérité",
  "IEML": "d.o.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa0e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "abahdaaaa"
  ],
  "CLASS": "1",
  "EN": "negative manner",
  "FR": "manière négative",
  "IEML": "E:U:.M:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220de6653c32453c0aa11")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhaaaaaaaeaacaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "southern qualities",
  "FR": "qualités australes",
  "IEML": "M:M:.-S:.A:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("55d220de6653c32453c0aa12")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efacgaaaaegacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "information medium",
  "FR": "support d'information",
  "IEML": "b.i.-t.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa14")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egaceaaaafeaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "scriptural",
  "FR": "scriptural",
  "IEML": "t.u.-k.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa15")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfaaaaaaaeaacaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "sweet",
  "FR": "sucré",
  "IEML": "f.-S:.A:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa16")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "acf"
  ],
  "CLASS": "1",
  "EN": "medium quantity | equality",
  "FR": "quantité moyenne | égalité",
  "IEML": "E:A:B:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa17")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfacfaaaafgacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "social worker",
  "FR": "travailleur social",
  "IEML": "f.a.-n.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa18")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geaceaaaaeeaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "map",
  "FR": "carte",
  "IEML": "d.u.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa19")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeacfaaaafgacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "precursor",
  "FR": "précurseur",
  "IEML": "s.a.-n.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa1e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgafbaaaa"
  ],
  "CLASS": "4",
  "EN": "acculturation",
  "FR": "acculturation",
  "IEML": "n.h.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa1f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geabbaaaa"
  ],
  "CLASS": "4",
  "EN": "intellectual constraint",
  "FR": "contrainte intellectuelle",
  "IEML": "d.wo.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa20")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efacfaaaaffacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "lover",
  "FR": "amant",
  "IEML": "b.a.-m.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa21")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geaaaaaaafaacaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "smooth",
  "FR": "lisse",
  "IEML": "d.-B:.A:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa22")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aeh"
  ],
  "CLASS": "1",
  "EN": "time distribution",
  "FR": "distribution dans le temps",
  "IEML": "E:S:M:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("55d220de6653c32453c0aa25")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fcageaaaa"
  ],
  "CLASS": "4",
  "EN": "hypocrisy | deception",
  "FR": "hypocrisie | tromperie",
  "IEML": "c.d.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa26")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feaceaaaaggaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "tomb | mausoleum",
  "FR": "tombeau | mausolée",
  "IEML": "k.u.-l.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa27")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "a"
  ],
  "CLASS": "1",
  "EN": "emptiness | silence | illusion | fiction",
  "FR": "vide | silence | illusion | fiction",
  "IEML": "E:",
  "LAYER": "0",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa29")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ecadhaaaa"
  ],
  "CLASS": "4",
  "EN": "expression process",
  "FR": "processus d'expression",
  "IEML": "g.O:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220de6653c32453c0aa2b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feaceaaaaeeaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "symmetrical",
  "FR": "symétrique",
  "IEML": "k.u.-s.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa2c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggabgaaaafeacgaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in elaborating commercial strategies",
  "FR": "compétence en élaboration de stratégies commerciales",
  "IEML": "l.e.-k.i.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa2d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffacfaaaaefacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "player",
  "FR": "joueur",
  "IEML": "m.a.-b.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa2e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efabgaaaafeaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "intellectual appropriation",
  "FR": "appropriation intellectuelle",
  "IEML": "b.e.-k.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa2f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hdaggaaaa"
  ],
  "CLASS": "4",
  "EN": "spatial obstacle",
  "FR": "obstacle spatial",
  "IEML": "M:O:.l.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220de6653c32453c0aa30")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eda"
  ],
  "CLASS": "4",
  "EN": "sign in mutation",
  "FR": "signe en mutation",
  "IEML": "S:O:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("55d220de6653c32453c0aa31")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feacgaaaaggacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "built",
  "FR": "bâti",
  "IEML": "k.i.-l.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa32")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ecaccaaaa"
  ],
  "CLASS": "4",
  "EN": "context variation",
  "FR": "variation du contexte",
  "IEML": "g.we.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa35")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geacgaaaaefacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "digital",
  "FR": "numérique",
  "IEML": "d.i.-b.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa36")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggacfaaaaeeacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "management",
  "FR": "management | gestion",
  "IEML": "l.a.-s.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa37")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffaebaaaa"
  ],
  "CLASS": "4",
  "EN": "expression | poetic awakening of emotion",
  "FR": "expression | réveil poétique des émotions",
  "IEML": "m.j.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa38")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geacgaaaaffacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "award | medal",
  "FR": "prix | médaille",
  "IEML": "d.i.-m.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa39")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feaaaaaaahaadaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "auditory qualities",
  "FR": "qualités auditives",
  "IEML": "k.-M:.O:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220de6653c32453c0aa3a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "adagdaaaa"
  ],
  "CLASS": "1",
  "EN": "manner of existence",
  "FR": "mode d'existence",
  "IEML": "E:O:.T:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220de6653c32453c0aa3d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gbahhaaaa"
  ],
  "CLASS": "4",
  "EN": "economic obstacle",
  "FR": "obstacle économique",
  "IEML": "p.M:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("55d220de6653c32453c0aa3e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfabgaaaafeacgaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in team sports",
  "FR": "compétence en sports d'équipe",
  "IEML": "f.e.-k.i.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa3f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "afaceaaaa"
  ],
  "CLASS": "1",
  "EN": "express now",
  "FR": "exprimer maintenant",
  "IEML": "E:B:.u.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa41")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgaceaaaagfaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "sense data quality",
  "FR": "qualité sensible",
  "IEML": "n.u.-f.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa43")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhaaaaaaafaabaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "eastern qualities",
  "FR": "qualités orientales",
  "IEML": "M:M:.-B:.U:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("55d220de6653c32453c0aa44")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhafcaaaa"
  ],
  "CLASS": "4",
  "EN": "political creation-innovation cycle",
  "FR": "cycle de création-innovation politique",
  "IEML": "M:M:.c.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("55d220de6653c32453c0aa46")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffacgaaaageacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "target",
  "FR": "cible",
  "IEML": "m.i.-d.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa47")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "exercise of power",
  "FR": "exercice du pouvoir",
  "IEML": "x.e.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa48")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ebadhaaaa"
  ],
  "CLASS": "4",
  "EN": "structural framework",
  "FR": "cadre structurel",
  "IEML": "j.O:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220de6653c32453c0aa4a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egaceaaaageaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "indexed",
  "FR": "indexé",
  "IEML": "t.u.-d.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa4b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gbageaaaa"
  ],
  "CLASS": "4",
  "EN": "lack of economic information and training",
  "FR": "absence de formation et d'information économique",
  "IEML": "p.d.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa4d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egacgaaaageacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "measured time",
  "FR": "chronométré",
  "IEML": "t.i.-d.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa4e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgaaaaaaafaabaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "wood",
  "FR": "bois",
  "IEML": "n.-B:.U:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa4f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geabfaaaaffabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "intuitive",
  "FR": "intuitif",
  "IEML": "d.o.-m.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa51")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feabfaaaaefabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "conversation",
  "FR": "conversation",
  "IEML": "k.o.-b.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa52")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geacgaaaagfacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "sensory organ",
  "FR": "organe sensoriel",
  "IEML": "d.i.-f.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa53")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggacfaaaaggacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "war",
  "FR": "guerre",
  "IEML": "l.a.-l.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa54")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfacgaaaaefacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "drug | medicine",
  "FR": "drogue | médicament",
  "IEML": "f.i.-b.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa55")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aiacfaaaa"
  ],
  "CLASS": "1",
  "EN": "promisive mood",
  "FR": "mode promissif",
  "IEML": "E:F:.a.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "5",
  "_id": ObjectId("55d220de6653c32453c0aa56")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egacgaaaafeacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "capital",
  "FR": "capital",
  "IEML": "t.i.-k.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa58")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeacgaaaagfacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "recognized",
  "FR": "reconnu",
  "IEML": "s.i.-f.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa59")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hdabbaaaa"
  ],
  "CLASS": "4",
  "EN": "mutation of possibilities",
  "FR": "mutation des possibles",
  "IEML": "M:O:.wo.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220de6653c32453c0aa5a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feaaaaaaafaacaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "low-pitched",
  "FR": "grave",
  "IEML": "k.-B:.A:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa5b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ghadhaaaa"
  ],
  "CLASS": "4",
  "EN": "thing of human development",
  "FR": "chose du développement humain",
  "IEML": "T:M:.O:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "18",
  "_id": ObjectId("55d220de6653c32453c0aa5d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgaccaaaa"
  ],
  "CLASS": "4",
  "EN": "cultural roots",
  "FR": "racines culturelles",
  "IEML": "n.we.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa5e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egabgaaaaegaceaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in software design",
  "FR": "compétence en conception de logiciels",
  "IEML": "t.e.-t.u.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa5f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efabgaaaaegaceaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in logic | competence in programming",
  "FR": "compétence en logique | compétence en programmation",
  "IEML": "b.e.-t.u.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa61")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgabgaaaafeacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "transparency of actions",
  "FR": "transparence des actes",
  "IEML": "n.e.-k.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa62")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgaaaaaaaeaacaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "fire",
  "FR": "feu",
  "IEML": "n.-S:.A:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa64")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeaceaaaaggaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "shadow",
  "FR": "ombre",
  "IEML": "s.u.-l.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa65")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeabgaaaafgaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "semantic distinction",
  "FR": "distinction sémantique",
  "IEML": "s.e.-n.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa66")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgabgaaaagfacfaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in healing",
  "FR": "compétence en guérison",
  "IEML": "n.e.-f.a.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa67")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ebaecaaaa"
  ],
  "CLASS": "4",
  "EN": "new question",
  "FR": "nouvelle question",
  "IEML": "j.g.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa68")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfaceaaaaegaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "musical score",
  "FR": "partition",
  "IEML": "f.u.-t.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa6b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgacgaaaafgacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "energy source",
  "FR": "source d'énergie",
  "IEML": "n.i.-n.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa6c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffabfaaaaggabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "offered",
  "FR": "offert",
  "IEML": "m.o.-l.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa6d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egacgaaaa"
  ],
  "CLASS": "4",
  "EN": "container",
  "FR": "contenant",
  "IEML": "t.i.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa6e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efabgaaaaegaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "logical consistency",
  "FR": "cohérence logique",
  "IEML": "b.e.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa6f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geaceaaaaggaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "clue",
  "FR": "indice",
  "IEML": "d.u.-l.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa70")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gbabcaaaa"
  ],
  "CLASS": "4",
  "EN": "change of objective",
  "FR": "changement d'objectif",
  "IEML": "p.wa.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa71")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feabgaaaa"
  ],
  "CLASS": "4",
  "EN": "self-control",
  "FR": "maîtrise de soi",
  "IEML": "k.e.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa72")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geabgaaaaggacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "public building | public works",
  "FR": "bâtiment public | travaux publics",
  "IEML": "d.e.-l.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa74")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "acd"
  ],
  "CLASS": "1",
  "EN": "constructive mode",
  "FR": "mode constructif",
  "IEML": "E:A:O:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("55d220de6653c32453c0aa75")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ecaffaaaa"
  ],
  "CLASS": "4",
  "EN": "malicious gossip | contempt",
  "FR": "médisance | mépris",
  "IEML": "g.m.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa76")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aeaegaaaa"
  ],
  "CLASS": "1",
  "EN": "entry point",
  "FR": "point d'entrée",
  "IEML": "E:S:.t.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa77")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egabgaaaafgaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "literary text",
  "FR": "texte littéraire",
  "IEML": "t.e.-n.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa7a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaceaaaaggaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "cited",
  "FR": "cité",
  "IEML": "b.u.-l.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa7e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "acaefaaaa"
  ],
  "CLASS": "1",
  "EN": "in front of",
  "FR": "devant",
  "IEML": "E:A:.b.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa7f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffabgaaaaegacfaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in fidelity",
  "FR": "compétence en fidélité",
  "IEML": "m.e.-t.a.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa80")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgabfaaaaggabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "cosmos",
  "FR": "cosmos",
  "IEML": "n.o.-l.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa82")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egacfaaaageacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "investor",
  "FR": "investisseur",
  "IEML": "t.a.-d.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa83")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fbafeaaaa"
  ],
  "CLASS": "4",
  "EN": "betrayal of the spirit | betrayal of tradition",
  "FR": "trahison de l'esprit | trahison de la tradition",
  "IEML": "h.k.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa85")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffabgaaaagfacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "well-being",
  "FR": "bien-être",
  "IEML": "m.e.-f.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa87")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geacfaaaaggacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "intelligence | data gathering",
  "FR": "renseignement | accumulation de données",
  "IEML": "d.a.-l.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa8b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffabfaaaafgabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "wisdom",
  "FR": "sagesse",
  "IEML": "m.o.-n.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa8e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgaceaaaaegaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "logo",
  "FR": "logo",
  "IEML": "n.u.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa8f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffaaaaaaafaabaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "desire",
  "FR": "désir",
  "IEML": "m.-B:.U:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa92")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggacfaaaageacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "entrepreneur",
  "FR": "entrepreneur",
  "IEML": "l.a.-d.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa96")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "afh"
  ],
  "CLASS": "1",
  "EN": "frequency distribution",
  "FR": "distribution de fréquence",
  "IEML": "E:B:M:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("55d220de6653c32453c0aa98")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfacfaaaagfacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "farmer",
  "FR": "cultivateur | éleveur",
  "IEML": "f.a.-f.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa99")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgaceaaaa"
  ],
  "CLASS": "4",
  "EN": "name",
  "FR": "nom",
  "IEML": "n.u.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa9a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggacfaaaaeeacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "manager",
  "FR": "manager",
  "IEML": "l.a.-s.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa9b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egaceaaaaeeaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "printed | engraved",
  "FR": "imprimé | gravé",
  "IEML": "t.u.-s.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa9c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geacfaaaafgacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "testimony",
  "FR": "témoignage",
  "IEML": "d.a.-n.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aa9f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgaceaaaagfaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "visual",
  "FR": "visuel",
  "IEML": "n.u.-f.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aaa0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgabgaaaaffacfaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in inspiring harmony",
  "FR": "compétence en inspiration de l'harmonie",
  "IEML": "n.e.-m.a.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aaa2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "will to live | living body",
  "FR": "vouloir vivre | corps vivant",
  "IEML": "f.o.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aaa3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffabfaaaaggabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "generosity",
  "FR": "générosité",
  "IEML": "m.o.-l.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aaa4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggabfaaaafgabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "architecture",
  "FR": "architecture",
  "IEML": "l.o.-n.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aaa6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ebagcaaaa"
  ],
  "CLASS": "4",
  "EN": "formalism evolution",
  "FR": "évolution du formalisme",
  "IEML": "j.x.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aaa7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fcaceaaaa"
  ],
  "CLASS": "4",
  "EN": "self presentation",
  "FR": "présentation de soi",
  "IEML": "c.u.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aaa9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgaceaaaaffaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "imitation",
  "FR": "imitation",
  "IEML": "n.u.-m.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aaaa")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggacgaaaageacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "compass",
  "FR": "boussole",
  "IEML": "l.i.-d.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aaab")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geacgaaaaegacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "meter | gauge",
  "FR": "compteur | jauge",
  "IEML": "d.i.-t.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aaac")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaebaaaa"
  ],
  "CLASS": "4",
  "EN": "semiotic innovation",
  "FR": "innovation sémiotique",
  "IEML": "b.j.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aaad")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geabfaaaagfabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "empirical",
  "FR": "empirique",
  "IEML": "d.o.-f.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aaae")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egabgaaaaffaceaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in staging | competence in artistic direction",
  "FR": "compétence en mise en scène | compétence en direction artistique",
  "IEML": "t.e.-m.u.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aaaf")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geabfaaaaefabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "description",
  "FR": "description",
  "IEML": "d.o.-b.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aab0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efabgaaaaffaceaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in the performing arts culture",
  "FR": "compétence en la culture des arts de la scène",
  "IEML": "b.e.-m.u.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aab2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feacgaaaaegacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "stored",
  "FR": "entreposé",
  "IEML": "k.i.-t.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aab3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ceahdaaaa"
  ],
  "CLASS": "2",
  "EN": "communicate a work",
  "FR": "communiquer une oeuvre",
  "IEML": "u.M:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220de6653c32453c0aab5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feacgaaaagfacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "mouth | digestive system",
  "FR": "bouche | système digestif",
  "IEML": "k.i.-f.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aab6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggabeaaaa"
  ],
  "CLASS": "4",
  "EN": "awareness of limits",
  "FR": "conscience des limites",
  "IEML": "l.y.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aab7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aiabbaaaa"
  ],
  "CLASS": "1",
  "EN": "singular pronoun",
  "FR": "pronom singulier",
  "IEML": "E:F:.wo.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "5",
  "_id": ObjectId("55d220de6653c32453c0aab8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "agafgaaaa"
  ],
  "CLASS": "1",
  "EN": "around",
  "FR": "autour",
  "IEML": "E:T:.n.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aabc")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "afafbaaaa"
  ],
  "CLASS": "1",
  "EN": "operand",
  "FR": "opérande",
  "IEML": "E:B:.h.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aabd")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ahadhaaaa"
  ],
  "CLASS": "1",
  "EN": "tense | time | when",
  "FR": "temps | quand",
  "IEML": "E:M:.O:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "18",
  "_id": ObjectId("55d220de6653c32453c0aac1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgabfaaaaeeabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "culture",
  "FR": "culture",
  "IEML": "n.o.-s.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aac2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhaceaaaahhaceaaaaaaaaaaaaa",
    "hhaceaaaahhaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "semiotic functions and qualities",
  "FR": "fonctions et qualités sémiotiques",
  "IEML": "M:M:.u.-M:M:.u.-E:.-+d.u.-'",
  "LAYER": "3",
  "PARADIGM": "1",
  "TAILLE": "162",
  "_id": ObjectId("55d220de6653c32453c0aac3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feahdaaaa"
  ],
  "CLASS": "4",
  "EN": "social dimension of a creation-innovation cycle",
  "FR": "dimension sociale d'un cycle de création-innovation",
  "IEML": "k.M:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220de6653c32453c0aac5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feaceaaaaegaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "premonitory",
  "FR": "prémonitoire",
  "IEML": "k.u.-t.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aac7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fcafbaaaa"
  ],
  "CLASS": "4",
  "EN": "change of staff",
  "FR": "changement de personnel",
  "IEML": "c.h.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aac8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efabgaaaagfaceaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in musical culture",
  "FR": "compétence en culture musicale",
  "IEML": "b.e.-f.u.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aac9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeaceaaaaeeaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "idea",
  "FR": "idée",
  "IEML": "s.u.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aaca")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhacfaaaahhacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "social actors",
  "FR": "acteurs sociaux",
  "IEML": "M:M:.a.-M:M:.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "81",
  "_id": ObjectId("55d220de6653c32453c0aacb")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "adaehaaaa"
  ],
  "CLASS": "1",
  "EN": "top | face",
  "FR": "haut | face",
  "IEML": "E:O:.S:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220de6653c32453c0aacf")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgabfaaaafeabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "religious",
  "FR": "religieux",
  "IEML": "n.o.-k.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aad0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggabfaaaafgabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "spatial",
  "FR": "spatial",
  "IEML": "l.o.-n.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aad1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeaaaaaaahaadaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "elementary qualities",
  "FR": "qualités élémentaires",
  "IEML": "s.-M:.O:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220de6653c32453c0aad2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfacgaaaagfacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "organic",
  "FR": "organique",
  "IEML": "f.i.-f.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aad3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efacgaaaaggacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "linked",
  "FR": "relié",
  "IEML": "b.i.-l.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aad5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hdafbaaaa"
  ],
  "CLASS": "4",
  "EN": "transformation in will",
  "FR": "transformation dans la volonté",
  "IEML": "M:O:.h.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220de6653c32453c0aad6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggafbaaaa"
  ],
  "CLASS": "4",
  "EN": "migration | cultural mixing",
  "FR": "migration | mixage culturel",
  "IEML": "l.h.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aad7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfabgaaaageacgaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in shooting sports aiming",
  "FR": "compétence en sports de tir de visée",
  "IEML": "f.e.-d.i.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aada")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ecabcaaaa"
  ],
  "CLASS": "4",
  "EN": "transformative feedback",
  "FR": "rétroaction transformatrice",
  "IEML": "g.wa.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aadb")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhagcaaaa"
  ],
  "CLASS": "4",
  "EN": "technical creation-innovation cycle",
  "FR": "cycle de création-innovation technique",
  "IEML": "M:M:.x.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("55d220de6653c32453c0aadc")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggabgaaaageacgaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in metrology",
  "FR": "compétence en métrologie",
  "IEML": "l.e.-d.i.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aadf")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ddaccaaaa"
  ],
  "CLASS": "2",
  "EN": "wane",
  "FR": "décliner",
  "IEML": "O:O:.we.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220de6653c32453c0aae2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhaecaaaa"
  ],
  "CLASS": "4",
  "EN": "communication creation-innovation cycle",
  "FR": "cycle de création-innovation en communication",
  "IEML": "M:M:.g.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("55d220de6653c32453c0aae3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hdahdaaaa"
  ],
  "CLASS": "4",
  "EN": "transformations",
  "FR": "transformations",
  "IEML": "M:O:.M:O:.-",
  "LAYER": "2",
  "PARADIGM": "1",
  "TAILLE": "36",
  "_id": ObjectId("55d220de6653c32453c0aae5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfabfaaaaefabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "played",
  "FR": "joué",
  "IEML": "f.o.-b.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aae6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ababeaaaa"
  ],
  "CLASS": "1",
  "EN": "known",
  "FR": "connu",
  "IEML": "E:U:.y.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aae9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "agacbaaaa"
  ],
  "CLASS": "1",
  "EN": "third person masculine",
  "FR": "troisième personne masculin",
  "IEML": "E:T:.wu.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aaea")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aeaccaaaa"
  ],
  "CLASS": "1",
  "EN": "first person feminine",
  "FR": "première personne féminin",
  "IEML": "E:S:.we.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aaec")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffabfaaaaffabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "in love",
  "FR": "amoureux",
  "IEML": "m.o.-m.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aaee")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egabgaaaagfaceaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in composing music",
  "FR": "compétence en composition de musique",
  "IEML": "t.e.-f.u.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aaef")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geabgaaaaeeacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "practical solution",
  "FR": "solution pratique",
  "IEML": "d.e.-s.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aaf1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaceaaaaffaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "song",
  "FR": "chant",
  "IEML": "b.u.-m.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aaf2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hdabeaaaa"
  ],
  "CLASS": "4",
  "EN": "conditions of knowledge",
  "FR": "conditions du savoir",
  "IEML": "M:O:.y.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220de6653c32453c0aaf3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggacgaaaagfacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "muscle | os",
  "FR": "muscle | os",
  "IEML": "l.i.-f.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aaf4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gcacfaaaa"
  ],
  "CLASS": "4",
  "EN": "coexistence | doing things with others",
  "FR": "coexistence | fréquentation d'autrui",
  "IEML": "x.a.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aaf5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geaaaaaaagaabaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "crisp",
  "FR": "craquant",
  "IEML": "d.-T:.U:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aaf6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeaceaaaaegaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "schematised",
  "FR": "schématisé",
  "IEML": "s.u.-t.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aaf7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "acabfaaaa"
  ],
  "CLASS": "1",
  "EN": "willing",
  "FR": "voulant",
  "IEML": "E:A:.o.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aaf8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffabfaaaaeeabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "interest",
  "FR": "intérêt",
  "IEML": "m.o.-s.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aaf9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfaceaaaagfaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "illusory",
  "FR": "illusoire",
  "IEML": "f.u.-f.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aafc")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeacfaaaagfacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "psychologist",
  "FR": "psychologue",
  "IEML": "s.a.-f.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aafe")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geacfaaaaeeacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "studies",
  "FR": "études",
  "IEML": "d.a.-s.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aaff")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efabcaaaa"
  ],
  "CLASS": "4",
  "EN": "negotiation | coordination",
  "FR": "négociation | coordination",
  "IEML": "b.wa.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab00")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "abh"
  ],
  "CLASS": "1",
  "EN": "quality variation",
  "FR": "variation qualitative",
  "IEML": "E:U:M:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("55d220de6653c32453c0ab02")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geabgaaaaffacgaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in esthetics | competence in fashion",
  "FR": "compétence en esthétique | compétence en mode",
  "IEML": "d.e.-m.i.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab03")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeacgaaaaegacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "filtered",
  "FR": "filtré",
  "IEML": "s.i.-t.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab04")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efacgaaaaffacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "bright",
  "FR": "brillant",
  "IEML": "b.i.-m.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab05")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgabcaaaa"
  ],
  "CLASS": "4",
  "EN": "practical wisdom | prudence",
  "FR": "sagesse pratique | prudence",
  "IEML": "n.wa.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab06")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffabgaaaaffacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "reciprocity",
  "FR": "réciprocité",
  "IEML": "m.e.-m.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab07")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggacgaaaaefacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "simulated",
  "FR": "simulé",
  "IEML": "l.i.-b.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab08")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfabfaaaafgabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "dance",
  "FR": "danse",
  "IEML": "f.o.-n.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab09")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feacfaaaaggacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "trade union",
  "FR": "syndicat",
  "IEML": "k.a.-l.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab0a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egaceaaaa"
  ],
  "CLASS": "4",
  "EN": "mark",
  "FR": "marque",
  "IEML": "t.u.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab0b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggaceaaaafeaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "miraculous",
  "FR": "miraculeux",
  "IEML": "l.u.-k.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab0c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffabfaaaaeeabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "interesting",
  "FR": "intéressant",
  "IEML": "m.o.-s.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab0e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efacfaaaageacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "advertisement",
  "FR": "publicité",
  "IEML": "b.a.-d.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab10")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aiacgaaaa"
  ],
  "CLASS": "1",
  "EN": "imperative mood",
  "FR": "mode impératif",
  "IEML": "E:F:.i.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "5",
  "_id": ObjectId("55d220de6653c32453c0ab11")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ecacfaaaa"
  ],
  "CLASS": "4",
  "EN": "participation to the conversation",
  "FR": "participation à la conversation",
  "IEML": "g.a.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab12")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aeagbaaaa"
  ],
  "CLASS": "1",
  "EN": "whole",
  "FR": "tout",
  "IEML": "E:S:.p.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab13")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffacgaaaaegacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "security device",
  "FR": "dispositif de sécurité",
  "IEML": "m.i.-t.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab14")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efacgaaaaggacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "channel | way",
  "FR": "canal | voie",
  "IEML": "b.i.-l.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab15")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feabfaaaageabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "honesty",
  "FR": "honnêteté",
  "IEML": "k.o.-d.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab19")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggabgaaaaeeacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "compatibility",
  "FR": "compatibilité",
  "IEML": "l.e.-s.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab1a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggacgaaaafeacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "terrain | field",
  "FR": "terrain | champ",
  "IEML": "l.i.-k.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab1e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgacfaaaagfacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "illness",
  "FR": "maladie",
  "IEML": "n.a.-f.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab20")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geagcaaaa"
  ],
  "CLASS": "4",
  "EN": "rigorous technical procedures | rigorous technical processes",
  "FR": "procédures techniques rigoureuses | procédés techniques rigoureux",
  "IEML": "d.x.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab21")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egacfaaaafeacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "public servant",
  "FR": "fonctionnaire",
  "IEML": "t.a.-k.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab22")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeabgaaaaefaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "cultural openness",
  "FR": "ouverture culturelle",
  "IEML": "s.e.-b.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab23")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "abafbaaaa"
  ],
  "CLASS": "1",
  "EN": "avoiding | turning one's back on",
  "FR": "en évitant | en tournant le dos à ",
  "IEML": "E:U:.h.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab24")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffabgaaaafeacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "collective competence",
  "FR": "compétence collective",
  "IEML": "m.e.-k.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab27")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "afaccaaaa"
  ],
  "CLASS": "1",
  "EN": "second person feminine",
  "FR": "deuxième personne féminin",
  "IEML": "E:B:.we.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab2a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "e"
  ],
  "CLASS": "4",
  "EN": "sign",
  "FR": "signe",
  "IEML": "S:",
  "LAYER": "0",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab2c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffacfaaaaggacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "manufacturing",
  "FR": "fabrication",
  "IEML": "m.a.-l.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab2d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggacgaaaageacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "oriented",
  "FR": "orienté",
  "IEML": "l.i.-d.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab2e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ebaggaaaa"
  ],
  "CLASS": "4",
  "EN": "absence of response | absence of echo",
  "FR": "absence de réponse | absence d'écho",
  "IEML": "j.l.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab2f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geaecaaaa"
  ],
  "CLASS": "4",
  "EN": "quality of documents | quality of messages",
  "FR": "qualité des documents | qualité des messages",
  "IEML": "d.g.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab30")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geabfaaaaggabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "ordered",
  "FR": "ordonné",
  "IEML": "d.o.-l.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab31")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geabfaaaafgabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "science",
  "FR": "science",
  "IEML": "d.o.-n.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab32")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaceaaaagfaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "belonging to a literary genre",
  "FR": "appartenance à  un genre littéraire",
  "IEML": "b.u.-f.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab33")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeabgaaaaegaceaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in counting | competence in calculating",
  "FR": "compétence en énumération | compétence en calcul",
  "IEML": "s.e.-t.u.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab34")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fcacgaaaa"
  ],
  "CLASS": "4",
  "EN": "adaptation",
  "FR": "adaptation",
  "IEML": "c.i.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab35")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggacbaaaa"
  ],
  "CLASS": "4",
  "EN": "freedom of expression",
  "FR": "liberté d'expression",
  "IEML": "l.wu.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab36")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aiabhaaaa"
  ],
  "CLASS": "1",
  "EN": "declarative mood",
  "FR": "mode déclaratif",
  "IEML": "E:F:.U:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "15",
  "_id": ObjectId("55d220de6653c32453c0ab37")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feaebaaaa"
  ],
  "CLASS": "4",
  "EN": "re-created language community",
  "FR": "communauté de langage re-créée",
  "IEML": "k.j.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab3a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgabfaaaaeeabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "cultivated",
  "FR": "cultivé",
  "IEML": "n.o.-s.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab3b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeacfaaaaffacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "spouse",
  "FR": "époux",
  "IEML": "s.a.-m.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab3c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhadhaaaa"
  ],
  "CLASS": "4",
  "EN": "human development",
  "FR": "développement humain",
  "IEML": "M:M:.O:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "54",
  "_id": ObjectId("55d220de6653c32453c0ab3d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "g"
  ],
  "CLASS": "4",
  "EN": "thing",
  "FR": "chose",
  "IEML": "T:",
  "LAYER": "0",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab3e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feacfaaaaeeacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "diplomacy",
  "FR": "diplomatie",
  "IEML": "k.a.-s.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab3f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egaaaaaaaeaacaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "summer",
  "FR": "été",
  "IEML": "t.-S:.A:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab40")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfafcaaaa"
  ],
  "CLASS": "4",
  "EN": "election | appointment | personal victory",
  "FR": "élection | nomination | victoire personnelle",
  "IEML": "f.c.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab41")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeabgaaaagfaceaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in playing music | competence in singing",
  "FR": "compétence en interprétation de musique | compétence en chant",
  "IEML": "s.e.-f.u.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab43")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aic"
  ],
  "CLASS": "1",
  "EN": "logical necessity | must",
  "FR": "nécessité logique | doit",
  "IEML": "E:F:A:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "5",
  "_id": ObjectId("55d220de6653c32453c0ab44")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feaceaaaafeaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "sacred",
  "FR": "sacré",
  "IEML": "k.u.-k.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab46")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhabeaaaa"
  ],
  "CLASS": "4",
  "EN": "knowing power",
  "FR": "pouvoir savoir",
  "IEML": "M:M:.y.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("55d220de6653c32453c0ab47")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feacfaaaagfacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "provider",
  "FR": "pourvoyeur",
  "IEML": "k.a.-f.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab49")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fbagbaaaa"
  ],
  "CLASS": "4",
  "EN": "modification of specifications",
  "FR": "modification des spécifications",
  "IEML": "h.p.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab4a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffaceaaaagfaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "smile",
  "FR": "sourire",
  "IEML": "m.u.-f.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab4b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgacfaaaaffacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "man",
  "FR": "homme",
  "IEML": "n.a.-m.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab4e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "b"
  ],
  "CLASS": "2",
  "EN": "virtual",
  "FR": "virtuel",
  "IEML": "U:",
  "LAYER": "0",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab4f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egabgaaaaeeaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "original design",
  "FR": "design original",
  "IEML": "t.e.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab50")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efabgaaaaffaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "cultural scene",
  "FR": "scène culturelle",
  "IEML": "b.e.-m.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab51")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgagbaaaa"
  ],
  "CLASS": "4",
  "EN": "market evolution",
  "FR": "évolution du marché",
  "IEML": "n.p.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab55")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgacgaaaafeacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "merchandise",
  "FR": "marchandise",
  "IEML": "n.i.-k.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab56")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgabgaaaaegacfaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in establishing a tradition",
  "FR": "compétence en établissement dune tradition",
  "IEML": "n.e.-t.a.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab57")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfacgaaaafgacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "armed",
  "FR": "armé",
  "IEML": "f.i.-n.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab5a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egadhaaaa"
  ],
  "CLASS": "4",
  "EN": "memory factors",
  "FR": "facteurs de mémoire",
  "IEML": "t.O:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220de6653c32453c0ab5b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffadhaaaa"
  ],
  "CLASS": "4",
  "EN": "factors of affective bond",
  "FR": "facteurs de lien affectif",
  "IEML": "m.O:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220de6653c32453c0ab5c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhachaaaa"
  ],
  "CLASS": "4",
  "EN": "actual human development",
  "FR": "développement humain actuel",
  "IEML": "M:M:.A:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "27",
  "_id": ObjectId("55d220de6653c32453c0ab5e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efacfaaaaegacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "accountant",
  "FR": "comptable",
  "IEML": "b.a.-t.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab60")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffabgaaaaffacfaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in concern",
  "FR": "compétence en sollicitude",
  "IEML": "m.e.-m.a.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab61")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggaaaaaaahaadaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "spatial directions",
  "FR": "directions spatiales",
  "IEML": "l.-M:.O:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220de6653c32453c0ab64")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geacfaaaafeacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "inspector",
  "FR": "inspecteur",
  "IEML": "d.a.-k.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab65")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feaceaaaaffaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "stigmatized",
  "FR": "stigmatisé",
  "IEML": "k.u.-m.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab66")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efahdaaaa"
  ],
  "CLASS": "4",
  "EN": "communication constraints of a creation-innovation cycle",
  "FR": "contrainte de communication d'un cycle de création-innovation",
  "IEML": "b.M:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220de6653c32453c0ab67")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aag"
  ],
  "CLASS": "1",
  "EN": "accusative | direct object",
  "FR": "accusatif | complément d'objet direct",
  "IEML": "E:E:T:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab68")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hdageaaaa"
  ],
  "CLASS": "4",
  "EN": "epistemic defect",
  "FR": "défaut épistémique",
  "IEML": "M:O:.d.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220de6653c32453c0ab6c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feacfaaaageacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "vendor",
  "FR": "vendeur",
  "IEML": "k.a.-d.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab6d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efacfaaaafgacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "prosecutor",
  "FR": "procureur",
  "IEML": "b.a.-n.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab6e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggabgaaaaggacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "space structuring",
  "FR": "structuration de l'espace",
  "IEML": "l.e.-l.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab6f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feacgaaaaffacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "playing ground",
  "FR": "terrain de jeu",
  "IEML": "k.i.-m.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab70")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gcaffaaaa"
  ],
  "CLASS": "4",
  "EN": "labour dispute | conflicts at work",
  "FR": "conflit de travail | conflits au travail",
  "IEML": "x.m.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab71")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeacgaaaaggacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "articulated",
  "FR": "articulé",
  "IEML": "s.i.-l.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab72")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffacfaaaa"
  ],
  "CLASS": "4",
  "EN": "parent",
  "FR": "parent",
  "IEML": "m.a.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab73")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geabgaaaaggacgaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in the mastery of construction",
  "FR": "compétence en la maîtrise de la construction",
  "IEML": "d.e.-l.i.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab75")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feabfaaaaefabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "civil",
  "FR": "civil",
  "IEML": "k.o.-b.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab76")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeacfaaaafgacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "advance",
  "FR": "avancée",
  "IEML": "s.a.-n.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab79")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfacfaaaaffacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "mother",
  "FR": "mère",
  "IEML": "f.a.-m.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab7b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egabfaaaaggabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "harmony",
  "FR": "harmonie",
  "IEML": "t.o.-l.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab7c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgaceaaaaffaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "imitated",
  "FR": "imité",
  "IEML": "n.u.-m.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab7d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fbacbaaaa"
  ],
  "CLASS": "4",
  "EN": "existential discovery",
  "FR": "découverte existentielle",
  "IEML": "h.wu.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab7e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffacfaaaaeeacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "mediation",
  "FR": "médiation",
  "IEML": "m.a.-s.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab80")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hdaceaaaa"
  ],
  "CLASS": "4",
  "EN": "conditions of enunciation",
  "FR": "conditions de l'énonciation",
  "IEML": "M:O:.u.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220de6653c32453c0ab82")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggafcaaaa"
  ],
  "CLASS": "4",
  "EN": "country | territorial projection of political creation",
  "FR": "pays | projection territoriale de la création politique",
  "IEML": "l.c.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab83")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efabgaaaagfaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "music scene",
  "FR": "scène musicale",
  "IEML": "b.e.-f.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab84")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feacgaaaaegacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "store | storage",
  "FR": "magasin | entrepôt",
  "IEML": "k.i.-t.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab86")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gbaggaaaa"
  ],
  "CLASS": "4",
  "EN": "illusion of self-sufficiency",
  "FR": "illusion d'autosuffisance",
  "IEML": "p.l.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab87")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffabgaaaageacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "method of investigation",
  "FR": "méthode d'investigation",
  "IEML": "m.e.-d.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab88")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egacfaaaaffacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "ancestor",
  "FR": "ancêtre",
  "IEML": "t.a.-m.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab8a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaceaaaageaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "partial | incomplete",
  "FR": "partiel | incomplet",
  "IEML": "b.u.-d.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab8b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egaaaaaaafaabaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "spring season",
  "FR": "printemps",
  "IEML": "t.-B:.U:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab8c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeacgaaaageacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "transmitter",
  "FR": "émetteur",
  "IEML": "s.i.-d.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab8d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egacgaaaaggacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "urban",
  "FR": "urbain",
  "IEML": "t.i.-l.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab8f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgabgaaaaggacfaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in protecting a group",
  "FR": "compétence en protection d'un groupe",
  "IEML": "n.e.-l.a.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab91")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fbafcaaaa"
  ],
  "CLASS": "4",
  "EN": "change of management",
  "FR": "changement de direction | changement de 'management'",
  "IEML": "h.c.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab94")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egabgaaaaggaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "scientific discovery",
  "FR": "découverte scientifique",
  "IEML": "t.e.-l.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab95")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgacfaaaaegacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "trial",
  "FR": "procès",
  "IEML": "n.a.-t.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab99")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfagcaaaa"
  ],
  "CLASS": "4",
  "EN": "satisfied user",
  "FR": "utilisateur satisfait",
  "IEML": "f.x.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab9a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ecabgaaaa"
  ],
  "CLASS": "4",
  "EN": "order | decree",
  "FR": "ordre | décret",
  "IEML": "g.e.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab9b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egabfaaaaefabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "narrative",
  "FR": "récit",
  "IEML": "t.o.-b.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab9d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggacfaaaaefacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "public relations specialist",
  "FR": "spécialiste des relations publiques",
  "IEML": "l.a.-b.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab9e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aeaggaaaa"
  ],
  "CLASS": "1",
  "EN": "point of exit",
  "FR": "point de sortie",
  "IEML": "E:S:.l.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab9f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efacfaaaafgacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "accusation",
  "FR": "accusation",
  "IEML": "b.a.-n.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aba0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfacgaaaaegacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "fat",
  "FR": "graisse",
  "IEML": "f.i.-t.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aba5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgacgaaaageacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "wheel | lever",
  "FR": "roue | levier",
  "IEML": "n.i.-d.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aba6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "acabcaaaa"
  ],
  "CLASS": "1",
  "EN": "possessive plural",
  "FR": "possessif pluriel",
  "IEML": "E:A:.wa.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aba8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geaceaaaafgaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "deictic",
  "FR": "déictique",
  "IEML": "d.u.-n.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abaa")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "agg"
  ],
  "CLASS": "1",
  "EN": "everywhere",
  "FR": "partout",
  "IEML": "E:T:T:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abab")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeacgaaaafeacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "fertilizer",
  "FR": "engrais",
  "IEML": "s.i.-k.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abad")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gbabeaaaa"
  ],
  "CLASS": "4",
  "EN": "observation",
  "FR": "observation",
  "IEML": "p.y.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abaf")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efabfaaaagfabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "courage",
  "FR": "courage",
  "IEML": "b.o.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abb1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeacbaaaa"
  ],
  "CLASS": "4",
  "EN": "analysis of perceptions",
  "FR": "analyse des perceptions",
  "IEML": "s.wu.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abb5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ebagbaaaa"
  ],
  "CLASS": "4",
  "EN": "new analysis",
  "FR": "nouvelle analyse",
  "IEML": "j.p.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abb7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgabgaaaageacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "informing the public",
  "FR": "information du public",
  "IEML": "n.e.-d.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abb8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "agacgaaaa"
  ],
  "CLASS": "1",
  "EN": "past must do",
  "FR": "devoir faire au passé",
  "IEML": "E:T:.i.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abba")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggaaaaaaagaabaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "zenith",
  "FR": "zénith",
  "IEML": "l.-T:.U:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abbb")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geaceaaaaefaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "advised",
  "FR": "conseillé",
  "IEML": "d.u.-b.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abbc")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egacgaaaafeacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "stocked",
  "FR": "stocké",
  "IEML": "t.i.-k.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abbd")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeabfaaaafeabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "conscious",
  "FR": "conscient",
  "IEML": "s.o.-k.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abbe")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fcaffaaaa"
  ],
  "CLASS": "4",
  "EN": "harassment | persecution",
  "FR": "harcèlement | persécution",
  "IEML": "c.m.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abc0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feacgaaaagfacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "digested",
  "FR": "digéré",
  "IEML": "k.i.-f.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abc2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feabbaaaa"
  ],
  "CLASS": "4",
  "EN": "school of thought",
  "FR": "école de pensée",
  "IEML": "k.wo.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abc3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfaecaaaa"
  ],
  "CLASS": "4",
  "EN": "faithful spokesman | faithful representative",
  "FR": "porte-parole fidèle | représentant fidèle",
  "IEML": "f.g.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abc5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egabfaaaaeeabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "forecast",
  "FR": "prévision",
  "IEML": "t.o.-s.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abc6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeacgaaaaffacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "mechanical",
  "FR": "mécanique",
  "IEML": "s.i.-m.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abc9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ahb"
  ],
  "CLASS": "1",
  "EN": "inferential may",
  "FR": "peut inférentiel",
  "IEML": "E:M:U:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("55d220de6653c32453c0abcb")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeaceaaaageaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "located",
  "FR": "repéré",
  "IEML": "s.u.-d.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abcc")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fbaegaaaa"
  ],
  "CLASS": "4",
  "EN": "forgetfulness",
  "FR": "oubli",
  "IEML": "h.t.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abd0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efacgaaaaeeacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "atmosphere",
  "FR": "atmosphère",
  "IEML": "b.i.-s.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abd1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egabgaaaaeeaceaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in image creation | competence in graphic design",
  "FR": "compétence en création d'image | compétence en design graphique",
  "IEML": "t.e.-s.u.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abd2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feaceaaaaeeaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "mandala",
  "FR": "mandala",
  "IEML": "k.u.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abd3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhagbaaaa"
  ],
  "CLASS": "4",
  "EN": "economic creation-innovation cycle",
  "FR": "cycle de création-innovation économique",
  "IEML": "M:M:.p.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("55d220de6653c32453c0abd5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "afagbaaaa"
  ],
  "CLASS": "1",
  "EN": "patient",
  "FR": "patient",
  "IEML": "E:B:.p.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abd6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgahdaaaa"
  ],
  "CLASS": "4",
  "EN": "sustainable transformations resulting from a creation-innovation cycle",
  "FR": "transformation durable résultant d'un cycle de création-innovation",
  "IEML": "n.M:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220de6653c32453c0abd7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeacgaaaafgacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "refrigerated",
  "FR": "réfrigéré",
  "IEML": "s.i.-n.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abd9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeaaaaaaafaacaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "decreasing | diminishing | waning",
  "FR": "décroissant | diminuant",
  "IEML": "s.-B:.A:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abda")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggabfaaaafeabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "territory",
  "FR": "territoire",
  "IEML": "l.o.-k.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abdb")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggabfaaaaegabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "far",
  "FR": "loin",
  "IEML": "l.o.-t.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abde")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efabfaaaa"
  ],
  "CLASS": "4",
  "EN": "taste for language",
  "FR": "goût du langage",
  "IEML": "b.o.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abdf")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feacgaaaageacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "price",
  "FR": "prix",
  "IEML": "k.i.-d.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abe0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggaceaaaaeeaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "mold",
  "FR": "moule",
  "IEML": "l.u.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abe1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efacgaaaaeeacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "atmospheric",
  "FR": "atmosphérique",
  "IEML": "b.i.-s.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abe3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feaaaaaaagaabaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "low volume | light",
  "FR": "faible volume | léger",
  "IEML": "k.-T:.U:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abe4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggagbaaaa"
  ],
  "CLASS": "4",
  "EN": "skills network",
  "FR": "réseau de compétences",
  "IEML": "l.p.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abe5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fbaddaaaa"
  ],
  "CLASS": "4",
  "EN": "meaning change",
  "FR": "changement de sens",
  "IEML": "h.O:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220de6653c32453c0abe6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efabfaaaaffabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "beauty",
  "FR": "beauté",
  "IEML": "b.o.-m.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abe8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gcahdaaaa"
  ],
  "CLASS": "4",
  "EN": "transformation on concrete basis",
  "FR": "transformation sur base concrète",
  "IEML": "x.M:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220de6653c32453c0abea")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgabgaaaageacfaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in releasing the truth",
  "FR": "compétence en publication de la vérité",
  "IEML": "n.e.-d.a.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abeb")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efabgaaaaefaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "cultural exchange",
  "FR": "échange culturel",
  "IEML": "b.e.-b.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abec")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egaaaaaaafaacaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "autumn | fall season",
  "FR": "automne",
  "IEML": "t.-B:.A:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abed")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffacgaaaaefacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "perfumed",
  "FR": "parfumé",
  "IEML": "m.i.-b.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abee")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfacgaaaaffacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "sexual",
  "FR": "sexuel",
  "IEML": "f.i.-m.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abf0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffaceaaaaeeaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "fantasy",
  "FR": "fantasme",
  "IEML": "m.u.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abf1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgacgaaaafgacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "energy",
  "FR": "énergie",
  "IEML": "n.i.-n.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abf2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gcacgaaaa"
  ],
  "CLASS": "4",
  "EN": "manufacturing | execution",
  "FR": "fabrication | exécution",
  "IEML": "x.i.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abf3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeabgaaaafgaceaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in vocabulary",
  "FR": "compétence en vocabulaire",
  "IEML": "s.e.-n.u.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abf4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeabfaaaaefabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "inspiration",
  "FR": "inspiration",
  "IEML": "s.o.-b.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abf5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeacfaaaaggacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "innovator",
  "FR": "innovateur",
  "IEML": "s.a.-l.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abf6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhacgaaaahhacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "technical qualities",
  "FR": "qualités techniques",
  "IEML": "M:M:.i.-M:M:.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "81",
  "_id": ObjectId("55d220de6653c32453c0abf7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfacgaaaaggacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "supported",
  "FR": "soutenu",
  "IEML": "f.i.-l.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abfb")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fcadhaaaa"
  ],
  "CLASS": "4",
  "EN": "personal process",
  "FR": "processus personnel",
  "IEML": "c.O:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220de6653c32453c0abfc")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efacfaaaafeacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "political action",
  "FR": "action politique",
  "IEML": "b.a.-k.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abfe")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egacgaaaaffacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "precious",
  "FR": "précieux",
  "IEML": "t.i.-m.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ac02")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feacfaaaaefacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "show",
  "FR": "spectacle",
  "IEML": "k.a.-b.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ac04")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gbafbaaaa"
  ],
  "CLASS": "4",
  "EN": "new conception | new plan",
  "FR": "nouvelle conception | nouveau plan",
  "IEML": "p.h.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ac05")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aiabgaaaa"
  ],
  "CLASS": "1",
  "EN": "abilitative mood",
  "FR": "mode abilitatif",
  "IEML": "E:F:.e.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "5",
  "_id": ObjectId("55d220de6653c32453c0ac06")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efabgaaaaeeaceaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in visual refinement",
  "FR": "compétence en raffinement visuel",
  "IEML": "b.e.-s.u.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ac08")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feabfaaaafeabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "peace",
  "FR": "paix",
  "IEML": "k.o.-k.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ac09")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaceaaaafgaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "verb",
  "FR": "verbe",
  "IEML": "b.u.-n.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ac0c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ebaeeaaaa"
  ],
  "CLASS": "4",
  "EN": "slip of tongue | articulation deficiency",
  "FR": "lapsus | défaut d'articulation",
  "IEML": "j.s.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac11")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgaaaaaaagaacaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "water",
  "FR": "eau",
  "IEML": "n.-T:.A:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac13")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feabfaaaafgabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "just",
  "FR": "juste",
  "IEML": "k.o.-n.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac14")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffabfaaaaefabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "expression",
  "FR": "expression",
  "IEML": "m.o.-b.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac15")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efabgaaaafeaceaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in personal interpretation",
  "FR": "compétence en interprétation personnelle",
  "IEML": "b.e.-k.u.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac16")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egabgaaaaefaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "won-over public",
  "FR": "public conquis",
  "IEML": "t.e.-b.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac18")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fcaccaaaa"
  ],
  "CLASS": "4",
  "EN": "family event",
  "FR": "événement familial",
  "IEML": "c.we.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac1b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfaceaaaafeaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "vision",
  "FR": "vision",
  "IEML": "f.u.-k.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac1c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feacgaaaafgacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "assembled | manufactured",
  "FR": "assemblé | manufacturé",
  "IEML": "k.i.-n.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac1d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egabfaaaagfabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "periodical",
  "FR": "périodique",
  "IEML": "t.o.-f.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac1e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gcageaaaa"
  ],
  "CLASS": "4",
  "EN": "execution flaw",
  "FR": "défaut d'exécution",
  "IEML": "x.d.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac1f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feacgaaaafeacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "economic good",
  "FR": "bien économique",
  "IEML": "k.i.-k.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac20")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efabgaaaa"
  ],
  "CLASS": "4",
  "EN": "reasoning ability",
  "FR": "capacité de raisonner",
  "IEML": "b.e.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac21")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egaceaaaaffaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "auditive",
  "FR": "auditif",
  "IEML": "t.u.-m.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac22")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feabgaaaaffacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "affective autonomy",
  "FR": "autonomie affective",
  "IEML": "k.e.-m.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac24")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgacgaaaaegacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "consumed",
  "FR": "consommé",
  "IEML": "n.i.-t.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac25")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfacfaaaaggacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "rescuer",
  "FR": "secouriste",
  "IEML": "f.a.-l.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac26")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fca"
  ],
  "CLASS": "4",
  "EN": "personal mutation",
  "FR": "mutation personnelle",
  "IEML": "c.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac27")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efacfaaaaffacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "erotism",
  "FR": "érotisme",
  "IEML": "b.a.-m.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac28")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "adafdaaaa"
  ],
  "CLASS": "1",
  "EN": "manner of orientation",
  "FR": "mode d'orientation",
  "IEML": "E:O:.B:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220df6653c32453c0ac29")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaceaaaageaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "metonymy | part",
  "FR": "métonymie | partie",
  "IEML": "b.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac2c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ecabeaaaa"
  ],
  "CLASS": "4",
  "EN": "bibliography, literature review",
  "FR": "bibliographie, revue de littérature",
  "IEML": "g.y.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac2d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geabcaaaa"
  ],
  "CLASS": "4",
  "EN": "ethical constraint",
  "FR": "contrainte éthique",
  "IEML": "d.wa.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac30")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeacgaaaaeeacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "switched on",
  "FR": "allumé",
  "IEML": "s.i.-s.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac33")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggabgaaaaefacgaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in computer engineering",
  "FR": "compétence en ingénierie informatique",
  "IEML": "l.e.-b.i.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac34")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "afafcaaaa"
  ],
  "CLASS": "1",
  "EN": "operation",
  "FR": "opération",
  "IEML": "E:B:.c.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac35")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeabfaaaaeeabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "intelligent",
  "FR": "intelligent",
  "IEML": "s.o.-s.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac37")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geabfaaaaegabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "learning",
  "FR": "apprentissage",
  "IEML": "d.o.-t.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac38")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egaceaaaaffaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "sound",
  "FR": "son",
  "IEML": "t.u.-m.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac3b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "afc"
  ],
  "CLASS": "1",
  "EN": "authority",
  "FR": "autorité",
  "IEML": "E:B:A:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac3c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efacgaaaafeacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "monumental",
  "FR": "monumental",
  "IEML": "b.i.-k.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac3d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeabgaaaafeaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "reading | writing",
  "FR": "lecture | écriture",
  "IEML": "s.e.-k.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac3e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeacgaaaageacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "emitted | broadcasted",
  "FR": "émis | diffusé",
  "IEML": "s.i.-d.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac40")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egacgaaaagfacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "genetic",
  "FR": "génétique",
  "IEML": "t.i.-f.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac42")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgacfaaaageacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "purchase",
  "FR": "achat",
  "IEML": "n.a.-d.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac43")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffacfaaaagfacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "help",
  "FR": "aide",
  "IEML": "m.a.-f.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac44")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeabfaaaaggabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "proportion",
  "FR": "proportion",
  "IEML": "s.o.-l.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac47")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgabgaaaafgacfaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in forging values",
  "FR": "compétence en pose de valeurs",
  "IEML": "n.e.-n.a.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac48")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfacfaaaaffacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "woman",
  "FR": "femme",
  "IEML": "f.a.-m.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac49")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggaceaaaaggaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "material",
  "FR": "matériel",
  "IEML": "l.u.-l.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac4a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feabgaaaafgacfaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in self-evaluation",
  "FR": "compétence en auto-évaluation",
  "IEML": "k.e.-n.a.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac4b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffacgaaaafgacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "cleaning device",
  "FR": "instrument de nettoyage",
  "IEML": "m.i.-n.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac4c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "acabgaaaa"
  ],
  "CLASS": "1",
  "EN": "abling | enabling",
  "FR": "capacitant | habilitant",
  "IEML": "E:A:.e.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac4e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geacgaaaafeacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "monetary",
  "FR": "monétaire",
  "IEML": "d.i.-k.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac4f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fbabbaaaa"
  ],
  "CLASS": "4",
  "EN": "conversion",
  "FR": "conversion",
  "IEML": "h.wo.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac50")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hdafeaaaa"
  ],
  "CLASS": "4",
  "EN": "defect in community",
  "FR": "défaut de communauté",
  "IEML": "M:O:.k.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220df6653c32453c0ac52")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggaceaaaafgaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "occurrence | event",
  "FR": "occurrence | événement",
  "IEML": "l.u.-n.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac55")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffaceaaaaggaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "memory | recollection",
  "FR": "souvenir",
  "IEML": "m.u.-l.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac56")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geacfaaaaefacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "show production",
  "FR": "production de spectacle",
  "IEML": "d.a.-b.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac57")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggahdaaaa"
  ],
  "CLASS": "4",
  "EN": "manifestation in space of a creation-innovation cycle",
  "FR": "manifestation dans l'espace d'un cycle de création-innovation",
  "IEML": "l.M:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220df6653c32453c0ac59")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfacgaaaaffacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "sexuality",
  "FR": "sexe",
  "IEML": "f.i.-m.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac5e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gbabbaaaa"
  ],
  "CLASS": "4",
  "EN": "shift of interests | attention",
  "FR": "transformation des intérêts | de l'attention",
  "IEML": "p.wo.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac60")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aiachaaaa"
  ],
  "CLASS": "1",
  "EN": "performative mood",
  "FR": "mode performatif",
  "IEML": "E:F:.A:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "15",
  "_id": ObjectId("55d220df6653c32453c0ac61")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgacgaaaaggacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "glue | joint",
  "FR": "colle | joint",
  "IEML": "n.i.-l.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac64")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aeaebaaaa"
  ],
  "CLASS": "1",
  "EN": "set",
  "FR": "ensemble",
  "IEML": "E:S:.j.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac65")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgagcaaaa"
  ],
  "CLASS": "4",
  "EN": "transformation of the practical universe",
  "FR": "transformation de l'univers pratique",
  "IEML": "n.x.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac66")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feabfaaaaffabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "friendship",
  "FR": "amitié",
  "IEML": "k.o.-m.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac68")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffaceaaaageaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "make-up",
  "FR": "maquillage",
  "IEML": "m.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac69")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffabgaaaaeeacfaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in understanding others",
  "FR": "compétence en compréhension d'autrui",
  "IEML": "m.e.-s.a.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac6a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaceaaaaggaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "quotation",
  "FR": "citation",
  "IEML": "b.u.-l.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac6b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fcaegaaaa"
  ],
  "CLASS": "4",
  "EN": "obsolescence",
  "FR": "obsolescence",
  "IEML": "c.t.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac6c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gbafcaaaa"
  ],
  "CLASS": "4",
  "EN": "evolution of the demand",
  "FR": "évolution de la demande",
  "IEML": "p.c.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac6d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eca"
  ],
  "CLASS": "4",
  "EN": "document mutation",
  "FR": "mutation documentaire",
  "IEML": "g.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac6e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feaceaaaagfaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "holy",
  "FR": "saint",
  "IEML": "k.u.-f.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac6f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geahdaaaa"
  ],
  "CLASS": "4",
  "EN": "truth of a creation-innovation cycle | exactness & rigor of a creation-innovation cycle",
  "FR": "vérité d'un cycle de création-innovation | exactitude & rigueur d'un cycle de création-innovation",
  "IEML": "d.M:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220df6653c32453c0ac71")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egabfaaaafeabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "tradition",
  "FR": "tradition",
  "IEML": "t.o.-k.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac72")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geabfaaaaggabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "order",
  "FR": "ordre",
  "IEML": "d.o.-l.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac73")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hdaddaaaa"
  ],
  "CLASS": "4",
  "EN": "generative mutation",
  "FR": "mutation générative",
  "IEML": "M:O:.O:O:.-",
  "LAYER": "2",
  "PARADIGM": "1",
  "TAILLE": "24",
  "_id": ObjectId("55d220df6653c32453c0ac75")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhabbaaaa"
  ],
  "CLASS": "4",
  "EN": "intellectual sources of meaning",
  "FR": "sources intellectuelles du sens",
  "IEML": "M:M:.wo.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("55d220df6653c32453c0ac76")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggacgaaaaggacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "networked",
  "FR": "en réseau",
  "IEML": "l.i.-l.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac79")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffacfaaaafgacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "cause",
  "FR": "cause",
  "IEML": "m.a.-n.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac7c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geacfaaaa"
  ],
  "CLASS": "4",
  "EN": "researcher",
  "FR": "chercheur",
  "IEML": "d.a.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac7d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgaecaaaa"
  ],
  "CLASS": "4",
  "EN": "change of public behavior",
  "FR": "changement de comportement du public",
  "IEML": "n.g.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac7f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeacfaaaaefacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "role",
  "FR": "rôle",
  "IEML": "s.a.-b.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac80")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efabfaaaafeabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "communicated",
  "FR": "communiqué",
  "IEML": "b.o.-k.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac82")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fba"
  ],
  "CLASS": "4",
  "EN": "signified mutation",
  "FR": "mutation de signifié",
  "IEML": "h.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac83")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ebagfaaaa"
  ],
  "CLASS": "4",
  "EN": "lack of aesthetic sensibility",
  "FR": "absence de sensibilité esthétique",
  "IEML": "j.f.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac84")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gcaceaaaa"
  ],
  "CLASS": "4",
  "EN": "publication | delivery",
  "FR": "publication | élocution",
  "IEML": "x.u.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac86")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgaddaaaa"
  ],
  "CLASS": "4",
  "EN": "sources of meaning in the relation to the cosmos",
  "FR": "sources du sens dans le rapport au cosmos",
  "IEML": "n.O:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220df6653c32453c0ac87")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fcafcaaaa"
  ],
  "CLASS": "4",
  "EN": "social bond mutation",
  "FR": "mutation du lien social",
  "IEML": "c.c.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac8b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeaceaaaafeaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "visualized",
  "FR": "visualisé",
  "IEML": "s.u.-k.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac8d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggabfaaaaggabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "complex",
  "FR": "complexe",
  "IEML": "l.o.-l.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac8e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ecaggaaaa"
  ],
  "CLASS": "4",
  "EN": "intellectual closedness | rigidity",
  "FR": "fermeture | rigidité intellectuelle",
  "IEML": "g.l.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac90")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgacbaaaa"
  ],
  "CLASS": "4",
  "EN": "creative imagination",
  "FR": "imagination créatrice",
  "IEML": "n.wu.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac91")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffaaaaaaagaabaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "joy",
  "FR": "joie",
  "IEML": "m.-T:.U:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac92")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "acg"
  ],
  "CLASS": "1",
  "EN": "a lot | very",
  "FR": "beaucoup | très",
  "IEML": "E:A:T:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac94")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aiabcaaaa"
  ],
  "CLASS": "1",
  "EN": "plural pronoun",
  "FR": "pronom pluriel",
  "IEML": "E:F:.wa.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "5",
  "_id": ObjectId("55d220df6653c32453c0ac95")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffacgaaaa"
  ],
  "CLASS": "4",
  "EN": "toy",
  "FR": "jouet",
  "IEML": "m.i.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac99")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fbaebaaaa"
  ],
  "CLASS": "4",
  "EN": "new choice",
  "FR": "nouveau choix",
  "IEML": "h.j.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac9c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gbaegaaaa"
  ],
  "CLASS": "4",
  "EN": "waste | loss of capital | erosion of capital",
  "FR": "gaspillage | perte de capital | érosion du capital",
  "IEML": "p.t.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac9d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feacfaaaafeacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "city | political unit",
  "FR": "cité | unité politique",
  "IEML": "k.a.-k.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac9e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "abaffaaaa"
  ],
  "CLASS": "1",
  "EN": "at same level",
  "FR": "au même niveau",
  "IEML": "E:U:.m.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac9f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggacfaaaaegacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "cartographer",
  "FR": "cartographe",
  "IEML": "l.a.-t.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0aca0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeabgaaaaggaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "nature",
  "FR": "nature",
  "IEML": "s.e.-l.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0aca1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeaceaaaaeeaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "ideal",
  "FR": "idéal",
  "IEML": "s.u.-s.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0aca4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffaceaaaagfaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "pleasant",
  "FR": "agréable",
  "IEML": "m.u.-f.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0aca6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfabgaaaaeeacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "body-mind synchrony",
  "FR": "synchronie corps-esprit",
  "IEML": "f.e.-s.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0aca7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eba"
  ],
  "CLASS": "4",
  "EN": "signifier mutation",
  "FR": "mutation de signifiant",
  "IEML": "j.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0aca8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhaaaaaaaeaabaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "northern qualities",
  "FR": "qualités septentrionales",
  "IEML": "M:M:.-S:.U:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("55d220df6653c32453c0acaa")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cgaaaaaaacfaaaaaaaccafbaaaa"
  ],
  "CLASS": "2",
  "EN": "look after the infrastructure",
  "FR": "entretenir l'infrastructure",
  "IEML": "i.-a.-we.h.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0acab")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egabeaaaa"
  ],
  "CLASS": "4",
  "EN": "memory management",
  "FR": "gestion de la mémoire",
  "IEML": "t.y.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0acac")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geabfaaaagfabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "experience",
  "FR": "expérience",
  "IEML": "d.o.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0acad")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efacgaaaaffacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "jewel",
  "FR": "bijou",
  "IEML": "b.i.-m.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0acae")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feaceaaaa"
  ],
  "CLASS": "4",
  "EN": "symbol",
  "FR": "symbole",
  "IEML": "k.u.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0acaf")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgacgaaaagfacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "hand | foot",
  "FR": "main | pied",
  "IEML": "n.i.-f.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0acb2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egabfaaaaffabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "hoped for",
  "FR": "espéré",
  "IEML": "t.o.-m.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0acb6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfacfaaaaeeacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "consultation",
  "FR": "consultation",
  "IEML": "f.a.-s.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0acb7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgabgaaaagfacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "recovery",
  "FR": "guérison",
  "IEML": "n.e.-f.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0acb8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggaceaaaaeeaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "casted",
  "FR": "moulé",
  "IEML": "l.u.-s.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0acb9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffacfaaaageacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "partner",
  "FR": "partenaire",
  "IEML": "m.a.-d.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0acba")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egabgaaaafgaceaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in literary writing",
  "FR": "compétence en écriture littéraire",
  "IEML": "t.e.-n.u.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0acbb")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeacfaaaageacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "mentor",
  "FR": "mentor",
  "IEML": "s.a.-d.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0acbc")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geabfaaaageabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "investigation",
  "FR": "investigation",
  "IEML": "d.o.-d.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0acbd")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efacgaaaa"
  ],
  "CLASS": "4",
  "EN": "medium",
  "FR": "medium",
  "IEML": "b.i.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0acbe")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfabfaaaaggabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "organised",
  "FR": "organisé",
  "IEML": "f.o.-l.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0acbf")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ecahhaaaa"
  ],
  "CLASS": "4",
  "EN": "obstacle related to communication",
  "FR": "obstacle communicationnel",
  "IEML": "g.M:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("55d220df6653c32453c0acc3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geaccaaaa"
  ],
  "CLASS": "4",
  "EN": "technical constraint",
  "FR": "contrainte technique",
  "IEML": "d.we.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0acc4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffacfaaaaegacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "contract",
  "FR": "contrat",
  "IEML": "m.a.-t.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0acc5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfaceaaaageaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "remarkable",
  "FR": "remarquable",
  "IEML": "f.u.-d.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0acc6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggabgaaaaggacgaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in architecture",
  "FR": "compétence en architecture",
  "IEML": "l.e.-l.i.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0acc8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ecabbaaaa"
  ],
  "CLASS": "4",
  "EN": "initiation | new name",
  "FR": "initiation | nouveau nom",
  "IEML": "g.wo.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0acc9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggabcaaaa"
  ],
  "CLASS": "4",
  "EN": "freedom of movement",
  "FR": "liberté de circulation",
  "IEML": "l.wa.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0accb")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggabgaaaaeeacgaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in interconnecting systems",
  "FR": "compétence en interconnection de systèmes",
  "IEML": "l.e.-s.i.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0acce")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "afaecaaaa"
  ],
  "CLASS": "1",
  "EN": "selection",
  "FR": "séléction",
  "IEML": "E:B:.g.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0accf")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egaceaaaaeeaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "character | typography",
  "FR": "caractère | typographie",
  "IEML": "t.u.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0acd0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggaceaaaaegaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "quality",
  "FR": "qualité",
  "IEML": "l.u.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0acd1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feabfaaaagfabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "collaborative",
  "FR": "collaboratif",
  "IEML": "k.o.-f.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0acd5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggabgaaaaffacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "poetic world",
  "FR": "univers poétique",
  "IEML": "l.e.-m.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0acd6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egaceaaaafgaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "proper name",
  "FR": "nom propre",
  "IEML": "t.u.-n.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0acd7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efabbaaaa"
  ],
  "CLASS": "4",
  "EN": "intellectual exchange",
  "FR": "échange intellectuel",
  "IEML": "b.wo.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0acd8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feaddaaaa"
  ],
  "CLASS": "4",
  "EN": "sources of meaning in community",
  "FR": "sources du sens dans la communauté",
  "IEML": "k.O:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220df6653c32453c0acd9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgabfaaaaefabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "stylish",
  "FR": "stylé",
  "IEML": "n.o.-b.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0acda")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hdaecaaaa"
  ],
  "CLASS": "4",
  "EN": "transformation in expression",
  "FR": "transformation dans l'expression",
  "IEML": "M:O:.g.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220df6653c32453c0ace1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfacbaaaa"
  ],
  "CLASS": "4",
  "EN": "brilliance of perceptions",
  "FR": "éclat des perceptions",
  "IEML": "f.wu.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ace2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "acacfaaaa"
  ],
  "CLASS": "1",
  "EN": "committing",
  "FR": "engageant",
  "IEML": "E:A:.a.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ace3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfacfaaaageacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "repair",
  "FR": "réparation",
  "IEML": "f.a.-d.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ace5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeacfaaaaeeacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "philosopher",
  "FR": "philosophe",
  "IEML": "s.a.-s.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ace8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfabgaaaageacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "precise gesture",
  "FR": "geste précis",
  "IEML": "f.e.-d.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ace9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaceaaaafgaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "acting",
  "FR": "agissant",
  "IEML": "b.u.-n.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0acea")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egacfaaaagfacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "pharmacist",
  "FR": "pharmacien",
  "IEML": "t.a.-f.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0aceb")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggaceaaaagfaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "grain | texture",
  "FR": "grain | texture",
  "IEML": "l.u.-f.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0acec")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggacgaaaaegacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "closed | packed",
  "FR": "fermé | emballé",
  "IEML": "l.i.-t.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0aced")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhafbaaaa"
  ],
  "CLASS": "4",
  "EN": "cultural creation-innovation cycle",
  "FR": "cycle de création-innovation culturel",
  "IEML": "M:M:.h.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("55d220df6653c32453c0acee")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggacfaaaagfacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "ecologist | environmentalist",
  "FR": "écologiste | environnementaliste",
  "IEML": "l.a.-f.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0acef")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffacgaaaaffacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "fetish",
  "FR": "fétiche",
  "IEML": "m.i.-m.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0acf2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gbadhaaaa"
  ],
  "CLASS": "4",
  "EN": "referential framework",
  "FR": "cadre référentiel",
  "IEML": "p.O:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220df6653c32453c0acf5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfabgaaaaefacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "grace",
  "FR": "grâce",
  "IEML": "f.e.-b.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0acf7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feaaaaaaafaabaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "high-pitched",
  "FR": "aigu",
  "IEML": "k.-B:.U:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0acfa")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeacgaaaaefacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "multimedia studio",
  "FR": "studio multimédia",
  "IEML": "s.i.-b.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0acfc")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hdagcaaaa"
  ],
  "CLASS": "4",
  "EN": "transformation in concrete things",
  "FR": "transformation dans le concret",
  "IEML": "M:O:.x.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220df6653c32453c0acfd")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geaaaaaaaeaacaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "soft | supple",
  "FR": "mou | souple",
  "IEML": "d.-S:.A:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0acff")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fcagcaaaa"
  ],
  "CLASS": "4",
  "EN": "change of owner",
  "FR": "changement de propriétaire",
  "IEML": "c.x.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad01")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffabfaaaafgabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "wise",
  "FR": "sage",
  "IEML": "m.o.-n.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad02")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aec"
  ],
  "CLASS": "1",
  "EN": "condition",
  "FR": "condition",
  "IEML": "E:S:A:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad03")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgaceaaaageaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "tagged",
  "FR": "étiqueté",
  "IEML": "n.u.-d.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad04")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfacgaaaaggacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "frame | framework",
  "FR": "cadre | charpente",
  "IEML": "f.i.-l.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad06")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgacfaaaaefacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "journalist",
  "FR": "journaliste",
  "IEML": "n.a.-b.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad09")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgacfaaaaggacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "public order",
  "FR": "ordre public",
  "IEML": "n.a.-l.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad0a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggagcaaaa"
  ],
  "CLASS": "4",
  "EN": "moving | spatial arrangement",
  "FR": "déménagement | aménagement d'espaces",
  "IEML": "l.x.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad0b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gba"
  ],
  "CLASS": "4",
  "EN": "referent mutation",
  "FR": "mutation de référent",
  "IEML": "p.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad0c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgacgaaaaegacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "fuel",
  "FR": "carburant",
  "IEML": "n.i.-t.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad0d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgabfaaaaggabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "cosmic",
  "FR": "cosmique",
  "IEML": "n.o.-l.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad0e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffaceaaaaffaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "face",
  "FR": "visage",
  "IEML": "m.u.-m.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad0f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeaebaaaa"
  ],
  "CLASS": "4",
  "EN": "poetic project | poetic dimension of a creation-innovation project",
  "FR": "projet poétique | dimension poétique d'un projet de création-innovation",
  "IEML": "s.j.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad11")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egacfaaaagfacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "pharmacy",
  "FR": "pharmacie",
  "IEML": "t.a.-f.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad13")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgafcaaaa"
  ],
  "CLASS": "4",
  "EN": "political evolution",
  "FR": "évolution politique",
  "IEML": "n.c.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad15")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhaceaaaahhaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "semiotic functions",
  "FR": "fonctions sémiotiques",
  "IEML": "M:M:.u.-M:M:.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "81",
  "_id": ObjectId("55d220df6653c32453c0ad16")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gcabbaaaa"
  ],
  "CLASS": "4",
  "EN": "transformative chance",
  "FR": "hasard transformateur",
  "IEML": "x.wo.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad17")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeabfaaaaffabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "humor",
  "FR": "humour",
  "IEML": "s.o.-m.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad18")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ebaebaaaa"
  ],
  "CLASS": "4",
  "EN": "intellectual mutation",
  "FR": "mutation intellectuelle",
  "IEML": "j.j.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad19")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efacfaaaafeacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "activist",
  "FR": "activiste",
  "IEML": "b.a.-k.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad1b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geabgaaaa"
  ],
  "CLASS": "4",
  "EN": "sensorimotor ability",
  "FR": "habileté sensori-motrice",
  "IEML": "d.e.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad1d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaaaaaaafaacaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "fuzziness",
  "FR": "flou",
  "IEML": "b.-B:.A:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad1f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fcaecaaaa"
  ],
  "CLASS": "4",
  "EN": "confidence renewal",
  "FR": "renouvellement de la confiance",
  "IEML": "c.g.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad20")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egafbaaaa"
  ],
  "CLASS": "4",
  "EN": "spiritual heritage",
  "FR": "héritage spirituel",
  "IEML": "t.h.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad22")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeabfaaaageabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "humble",
  "FR": "humble",
  "IEML": "s.o.-d.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad26")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feafbaaaa"
  ],
  "CLASS": "4",
  "EN": "re-created community of spirit",
  "FR": "communauté d'esprit re-créée",
  "IEML": "k.h.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad27")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeacgaaaaeeacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "switch",
  "FR": "commutateur",
  "IEML": "s.i.-s.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad28")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgabfaaaafgabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "human being",
  "FR": "être humain",
  "IEML": "n.o.-n.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad2a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgaaaaaaafaacaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "metal",
  "FR": "métal",
  "IEML": "n.-B:.A:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad2b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfadhaaaa"
  ],
  "CLASS": "4",
  "EN": "life factors",
  "FR": "facteurs de vie",
  "IEML": "f.O:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220df6653c32453c0ad2c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggabfaaaaggabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "complexity",
  "FR": "complexité",
  "IEML": "l.o.-l.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad2e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgabgaaaaegacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "civilization",
  "FR": "civilisation",
  "IEML": "n.e.-t.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad2f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ecagbaaaa"
  ],
  "CLASS": "4",
  "EN": "new deliberation",
  "FR": "nouvelle délibération",
  "IEML": "g.p.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad30")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfacfaaaa"
  ],
  "CLASS": "4",
  "EN": "healer",
  "FR": "guérisseur",
  "IEML": "f.a.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad31")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egacgaaaafgacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "heating device",
  "FR": "dispositif de chauffage",
  "IEML": "t.i.-n.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad32")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggaecaaaa"
  ],
  "CLASS": "4",
  "EN": "message diffusion graph",
  "FR": "graphe de diffusion du message",
  "IEML": "l.g.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad33")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaceaaaaegaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "instruction",
  "FR": "instruction",
  "IEML": "b.u.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad35")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfaceaaaaggaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "age",
  "FR": "âge",
  "IEML": "f.u.-l.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad36")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gbagbaaaa"
  ],
  "CLASS": "4",
  "EN": "mutation of forces in play",
  "FR": "mutation des forces en jeu",
  "IEML": "p.p.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad37")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egabfaaaaefabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "narrated",
  "FR": "narré",
  "IEML": "t.o.-b.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad39")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fbafgaaaa"
  ],
  "CLASS": "4",
  "EN": "opportunism",
  "FR": "opportunisme",
  "IEML": "h.n.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad3a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aeahdaaaa"
  ],
  "CLASS": "1",
  "EN": "specifying cause",
  "FR": "cause spécifiante",
  "IEML": "E:S:.M:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220df6653c32453c0ad40")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gcaggaaaa"
  ],
  "CLASS": "4",
  "EN": "expulsion from housing | habitat destruction",
  "FR": "expulsion d'un logement | destruction d'habitat",
  "IEML": "x.l.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad42")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aiabeaaaa"
  ],
  "CLASS": "1",
  "EN": "cognitive mood",
  "FR": "mode cognitif",
  "IEML": "E:F:.y.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "5",
  "_id": ObjectId("55d220df6653c32453c0ad43")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgacfaaaafgacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "spiritual guide",
  "FR": "guide spirituel",
  "IEML": "n.a.-n.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad44")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feabgaaaafeacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "performance",
  "FR": "performance",
  "IEML": "k.e.-k.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad45")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ebafeaaaa"
  ],
  "CLASS": "4",
  "EN": "syntactic mistake | lexical inappropriateness",
  "FR": "erreur de syntaxe | impropriété lexicale",
  "IEML": "j.k.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad46")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffacfaaaaggacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "blue-collar worker",
  "FR": "ouvrier",
  "IEML": "m.a.-l.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad47")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egaceaaaafeaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "scriptures",
  "FR": "écritures",
  "IEML": "t.u.-k.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad49")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fhadhaaaa"
  ],
  "CLASS": "4",
  "EN": "being of human development",
  "FR": "être du développement humain",
  "IEML": "B:M:.O:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "18",
  "_id": ObjectId("55d220df6653c32453c0ad4b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeacfaaaafeacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "parliament",
  "FR": "parlement",
  "IEML": "s.a.-k.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad4d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ahaebaaaa"
  ],
  "CLASS": "1",
  "EN": "virtual formal cause",
  "FR": "cause formelle virtuelle",
  "IEML": "E:M:.j.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("55d220df6653c32453c0ad4e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aee"
  ],
  "CLASS": "1",
  "EN": "never",
  "FR": "jamais",
  "IEML": "E:S:S:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad4f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feacgaaaa"
  ],
  "CLASS": "4",
  "EN": "gift",
  "FR": "don",
  "IEML": "k.i.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad50")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffaaaaaaaeaabaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "fear",
  "FR": "peur",
  "IEML": "m.-S:.U:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad53")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhacgaaaahhacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "technical functions",
  "FR": "fonctions techniques",
  "IEML": "M:M:.i.-M:M:.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "81",
  "_id": ObjectId("55d220df6653c32453c0ad55")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egacgaaaagfacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "genetic code | DNA",
  "FR": "code génétique | ADN",
  "IEML": "t.i.-f.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad56")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffabfaaaageabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "sincere",
  "FR": "sincère",
  "IEML": "m.o.-d.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad59")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fbabfaaaa"
  ],
  "CLASS": "4",
  "EN": "impulse",
  "FR": "pulsion",
  "IEML": "h.o.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad5a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfaceaaaafgaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "attributed",
  "FR": "attribué",
  "IEML": "f.u.-n.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad5b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ebabbaaaa"
  ],
  "CLASS": "4",
  "EN": "reflection turning point",
  "FR": "tournant de la réflexion",
  "IEML": "j.wo.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad5d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgacgaaaagfacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "taken | possessed",
  "FR": "pris | possédé",
  "IEML": "n.i.-f.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad5e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgacfaaaaggacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "police officer",
  "FR": "policier",
  "IEML": "n.a.-l.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad60")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggaccaaaa"
  ],
  "CLASS": "4",
  "EN": "economic responsibility",
  "FR": "responsabilité économique",
  "IEML": "l.we.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad61")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhacgaaaa"
  ],
  "CLASS": "4",
  "EN": "making tool",
  "FR": "faire outil",
  "IEML": "M:M:.i.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("55d220df6653c32453c0ad62")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfacgaaaageacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "detector | sensor",
  "FR": "détecteur | capteur",
  "IEML": "f.i.-d.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad63")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ebahhaaaa"
  ],
  "CLASS": "4",
  "EN": "poetic obstacle",
  "FR": "obstacle poétique",
  "IEML": "j.M:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("55d220df6653c32453c0ad64")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ahc"
  ],
  "CLASS": "1",
  "EN": "inferential must",
  "FR": "doit inférentiel",
  "IEML": "E:M:A:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("55d220df6653c32453c0ad68")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geabgaaaaefacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "augmented communication",
  "FR": "communication augmentée",
  "IEML": "d.e.-b.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad6a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffacfaaaafgacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "volunteer",
  "FR": "bénévole",
  "IEML": "m.a.-n.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad6d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gcaddaaaa"
  ],
  "CLASS": "4",
  "EN": "material change",
  "FR": "changement matériel",
  "IEML": "x.O:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220df6653c32453c0ad6f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feabfaaaaeeabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "government",
  "FR": "gouvernement",
  "IEML": "k.o.-s.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad75")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efabgaaaaggaceaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in scientific culture",
  "FR": "compétence en culture scientifique",
  "IEML": "b.e.-l.u.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad76")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaceaaaagfaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "literary form | literary genre",
  "FR": "forme littéraire | genre littéraire",
  "IEML": "b.u.-f.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad77")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fcabeaaaa"
  ],
  "CLASS": "4",
  "EN": "diploma | credit for competency",
  "FR": "diplôme | crédit de compétence",
  "IEML": "c.y.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad78")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aef"
  ],
  "CLASS": "1",
  "EN": "sometimes",
  "FR": "parfois",
  "IEML": "E:S:B:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad7b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfaceaaaaegaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "musical note",
  "FR": "note de musique",
  "IEML": "f.u.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad7e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hdafcaaaa"
  ],
  "CLASS": "4",
  "EN": "transformation in the social relationship",
  "FR": "transformation dans le rapport social",
  "IEML": "M:O:.c.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220df6653c32453c0ad83")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffabfaaaagfabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "seductive",
  "FR": "séduisant",
  "IEML": "m.o.-f.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad84")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfabfaaaaegabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "growing",
  "FR": "en croissance",
  "IEML": "f.o.-t.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad85")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "abd"
  ],
  "CLASS": "1",
  "EN": "deconstructive mode",
  "FR": "mode déconstructif",
  "IEML": "E:U:O:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("55d220df6653c32453c0ad86")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geacfaaaaegacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "banker",
  "FR": "banquier",
  "IEML": "d.a.-t.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad88")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgaceaaaaeeaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "total | integral",
  "FR": "total | intégral",
  "IEML": "n.u.-s.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad8a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeabgaaaa"
  ],
  "CLASS": "4",
  "EN": "mastery of codes",
  "FR": "maîtrise des codes",
  "IEML": "s.e.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad8b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfabgaaaaffacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "taste",
  "FR": "goût",
  "IEML": "f.e.-m.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad8c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggabfaaaagfabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "resident",
  "FR": "résidant",
  "IEML": "l.o.-f.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad8d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgabgaaaaggacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "collective security | collective safety",
  "FR": "sécurité collective",
  "IEML": "n.e.-l.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad8f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geaebaaaa"
  ],
  "CLASS": "4",
  "EN": "originality | distinct expression",
  "FR": "originalité | expression distincte",
  "IEML": "d.j.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad90")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geaceaaaaggaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "suspected",
  "FR": "soupçonné",
  "IEML": "d.u.-l.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad92")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egafcaaaa"
  ],
  "CLASS": "4",
  "EN": "political legacy | political tradition",
  "FR": "legs politique | tradition politique",
  "IEML": "t.c.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad96")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ehadhaaaa"
  ],
  "CLASS": "4",
  "EN": "sign of human development",
  "FR": "signe du développement humain",
  "IEML": "S:M:.O:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "18",
  "_id": ObjectId("55d220df6653c32453c0ad97")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feabgaaaaegacfaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in memory training",
  "FR": "compétence en entraînement de la mémoire",
  "IEML": "k.e.-t.a.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad98")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egacfaaaaefacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "editor | publisher",
  "FR": "éditeur",
  "IEML": "t.a.-b.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad99")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggadhaaaa"
  ],
  "CLASS": "4",
  "EN": "space factors",
  "FR": "facteurs d'espace",
  "IEML": "l.O:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220df6653c32453c0ad9a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efabfaaaageabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "clarity",
  "FR": "clarté",
  "IEML": "b.o.-d.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad9b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggaaaaaaafaacaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "west",
  "FR": "ouest",
  "IEML": "l.-B:.A:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad9e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggacfaaaafgacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "defender",
  "FR": "défenseur",
  "IEML": "l.a.-n.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ada0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaaaaaaagaabaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "luminous",
  "FR": "lumineux",
  "IEML": "b.-T:.U:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ada1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geaddaaaa"
  ],
  "CLASS": "4",
  "EN": "sources of meaning in rigor",
  "FR": "sources du sens dans la rigueur",
  "IEML": "d.O:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220df6653c32453c0ada2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hdaegaaaa"
  ],
  "CLASS": "4",
  "EN": "temporal defect",
  "FR": "défaut temporel",
  "IEML": "M:O:.t.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220df6653c32453c0ada3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fcaggaaaa"
  ],
  "CLASS": "4",
  "EN": "exile",
  "FR": "exil",
  "IEML": "c.l.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ada4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feabgaaaaeeacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "psychic autonomy",
  "FR": "autonomie psychique",
  "IEML": "k.e.-s.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ada5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgabfaaaageabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "evaluated | assessed",
  "FR": "évalué | estimé",
  "IEML": "n.o.-d.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ada7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geaceaaaagfaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "presence",
  "FR": "présence",
  "IEML": "d.u.-f.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ada8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gbafeaaaa"
  ],
  "CLASS": "4",
  "EN": "company closing down | breach of contract | bankruptcy",
  "FR": "fermeture d'entreprise | rupture de contrat | faillite",
  "IEML": "p.k.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ada9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "agahdaaaa"
  ],
  "CLASS": "1",
  "EN": "realizing cause",
  "FR": "cause réalisante",
  "IEML": "E:T:.M:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220df6653c32453c0adab")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "acabbaaaa"
  ],
  "CLASS": "1",
  "EN": "possessive singular",
  "FR": "possessif singulier",
  "IEML": "E:A:.wo.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0adac")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgabfaaaagfabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "health",
  "FR": "santé",
  "IEML": "n.o.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0adad")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gca"
  ],
  "CLASS": "4",
  "EN": "material mutation",
  "FR": "mutation matérielle",
  "IEML": "x.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0adaf")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfacgaaaaegacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "fed",
  "FR": "nourri",
  "IEML": "f.i.-t.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0adb1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeacfaaaaeeacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "symbolic order",
  "FR": "ordre symbolique",
  "IEML": "s.a.-s.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0adb2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geaceaaaaegaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "hyperlink",
  "FR": "hyperlien",
  "IEML": "d.u.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0adb3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efacfaaaaeeacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "reading",
  "FR": "lecture",
  "IEML": "b.a.-s.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0adb4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeaaaaaaagaabaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "dry",
  "FR": "sec",
  "IEML": "s.-T:.U:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0adb8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgaceaaaafeaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "virtue",
  "FR": "vertu",
  "IEML": "n.u.-k.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0adba")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgabfaaaa"
  ],
  "CLASS": "4",
  "EN": "will for cosmos",
  "FR": "volonté de cosmos",
  "IEML": "n.o.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0adbb")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feacgaaaaefacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "operating system",
  "FR": "système d'exploitation",
  "IEML": "k.i.-b.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0adbc")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeabgaaaagfaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "musical performance",
  "FR": "performance musicale",
  "IEML": "s.e.-f.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0adbd")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hca"
  ],
  "CLASS": "4",
  "EN": "actual mutation",
  "FR": "mutation actuelle",
  "IEML": "M:A:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("55d220df6653c32453c0adbe")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fbaefaaaa"
  ],
  "CLASS": "4",
  "EN": "manipulative language | manipulation",
  "FR": "langage manipulateur | manipulation",
  "IEML": "h.b.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0adc0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ecageaaaa"
  ],
  "CLASS": "4",
  "EN": "calculation mistake",
  "FR": "erreur de calcul",
  "IEML": "g.d.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0adc2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "adaedaaaa"
  ],
  "CLASS": "1",
  "EN": "manner of comparison",
  "FR": "mode de comparaison",
  "IEML": "E:O:.S:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220df6653c32453c0adc3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffaceaaaageaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "made-up",
  "FR": "maquillé",
  "IEML": "m.u.-d.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0adc4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgaceaaaaefaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "proposed",
  "FR": "proposé",
  "IEML": "n.u.-b.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0adc6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aie"
  ],
  "CLASS": "1",
  "EN": "less",
  "FR": "moins",
  "IEML": "E:F:S:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "5",
  "_id": ObjectId("55d220df6653c32453c0adc7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egacbaaaa"
  ],
  "CLASS": "4",
  "EN": "connecting thread",
  "FR": "fil conducteur",
  "IEML": "t.wu.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0adc9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egacfaaaaeeacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "translator",
  "FR": "traducteur",
  "IEML": "t.a.-s.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0adcb")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aab"
  ],
  "CLASS": "1",
  "EN": "attribute of the noun",
  "FR": "attribut du nom",
  "IEML": "E:E:U:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0adcc")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efacgaaaageacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "display device",
  "FR": "dispositif d'affichage",
  "IEML": "b.i.-d.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0adcd")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "acadhaaaa"
  ],
  "CLASS": "1",
  "EN": "active voice",
  "FR": "voix active",
  "IEML": "E:A:.O:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220df6653c32453c0adce")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ababgaaaa"
  ],
  "CLASS": "1",
  "EN": "able | enabled",
  "FR": "capable | habilité",
  "IEML": "E:U:.e.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0add0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gcafbaaaa"
  ],
  "CLASS": "4",
  "EN": "new obtention",
  "FR": "nouvelle obtention",
  "IEML": "x.h.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0add1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ebabfaaaa"
  ],
  "CLASS": "4",
  "EN": "acknowledgement of the unconscious",
  "FR": "reconnaissance de l'inconscient",
  "IEML": "j.o.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0add4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feaceaaaaefaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "revealed",
  "FR": "révélé",
  "IEML": "k.u.-b.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0add6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffacgaaaaeeacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "lure",
  "FR": "appât",
  "IEML": "m.i.-s.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0add7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffabgaaaafgacfaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in moral judgement",
  "FR": "compétence en jugement moral",
  "IEML": "m.e.-n.a.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0add8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "abf"
  ],
  "CLASS": "1",
  "EN": "as good",
  "FR": "aussi bon",
  "IEML": "E:U:B:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0add9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggaceaaaageaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "sampled",
  "FR": "échantillonné",
  "IEML": "l.u.-d.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0adda")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "agafbaaaa"
  ],
  "CLASS": "1",
  "EN": "system",
  "FR": "système",
  "IEML": "E:T:.h.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0addb")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgacfaaaagfacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "physician",
  "FR": "médecin",
  "IEML": "n.a.-f.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0addf")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egacgaaaaegacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "recording device",
  "FR": "dispositif d'enregistrement",
  "IEML": "t.i.-t.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ade0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aiaceaaaa"
  ],
  "CLASS": "1",
  "EN": "expressive mood",
  "FR": "mode expressif",
  "IEML": "E:F:.u.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "5",
  "_id": ObjectId("55d220df6653c32453c0ade2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geabfaaaaegabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "learned",
  "FR": "appris",
  "IEML": "d.o.-t.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ade4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ahagfaaaa"
  ],
  "CLASS": "1",
  "EN": "relative termination",
  "FR": "terminaison relative",
  "IEML": "E:M:.f.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("55d220df6653c32453c0ade5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeabfaaaageabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "humility",
  "FR": "humilité",
  "IEML": "s.o.-d.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ade6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fcahhaaaa"
  ],
  "CLASS": "4",
  "EN": "socio-political obstacle",
  "FR": "obstacle sociopolitique",
  "IEML": "c.M:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("55d220df6653c32453c0ade9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffacgaaaaggacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "clothed | covered",
  "FR": "vêtu | recouvert",
  "IEML": "m.i.-l.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0adea")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ecaceaaaa"
  ],
  "CLASS": "4",
  "EN": "organization of ideas",
  "FR": "organisation des idées",
  "IEML": "g.u.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0adeb")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efacfaaaa"
  ],
  "CLASS": "4",
  "EN": "storyteller",
  "FR": "conteur",
  "IEML": "b.a.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0adec")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gcabeaaaa"
  ],
  "CLASS": "4",
  "EN": "experience | experimentation",
  "FR": "expérience | expérimentation",
  "IEML": "x.y.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0adef")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feacfaaaafgacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "jury",
  "FR": "juré",
  "IEML": "k.a.-n.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0adf1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fda"
  ],
  "CLASS": "4",
  "EN": "being in mutation",
  "FR": "être en mutation",
  "IEML": "B:O:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("55d220df6653c32453c0adf2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fbaeeaaaa"
  ],
  "CLASS": "4",
  "EN": "confusion",
  "FR": "confusion",
  "IEML": "h.s.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0adf7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feacgaaaaeeacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "recycling",
  "FR": "recyclage",
  "IEML": "k.i.-s.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0adf8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfaaaaaaafaacaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "bitter",
  "FR": "amer",
  "IEML": "f.-B:.A:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0adf9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "afabfaaaa"
  ],
  "CLASS": "1",
  "EN": "want now",
  "FR": "vouloir maintenant",
  "IEML": "E:B:.o.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0adfc")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggabgaaaaffacgaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in art",
  "FR": "compétence en art",
  "IEML": "l.e.-m.i.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0adfd")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfacfaaaaegacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "insurance broker",
  "FR": "assureur",
  "IEML": "f.a.-t.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0adff")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggaaaaaaaeaacaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "south",
  "FR": "sud",
  "IEML": "l.-S:.A:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae00")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geaceaaaafgaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "contextual",
  "FR": "contextuel",
  "IEML": "d.u.-n.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae01")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgacgaaaaggacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "glued | joint",
  "FR": "collé | joint",
  "IEML": "n.i.-l.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae02")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ecaddaaaa"
  ],
  "CLASS": "4",
  "EN": "message change",
  "FR": "changement de message",
  "IEML": "g.O:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220df6653c32453c0ae03")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffacgaaaafgacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "cleaned",
  "FR": "nettoyé",
  "IEML": "m.i.-n.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae06")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feacfaaaaggacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "unionized",
  "FR": "syndiqué",
  "IEML": "k.a.-l.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae08")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "acacgaaaa"
  ],
  "CLASS": "1",
  "EN": "must do",
  "FR": "devant faire",
  "IEML": "E:A:.i.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae09")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gdadhaaaa"
  ],
  "CLASS": "4",
  "EN": "condition of activity in thing",
  "FR": "condition de l'activité dans la chose",
  "IEML": "T:O:.O:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "12",
  "_id": ObjectId("55d220df6653c32453c0ae0b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ahaehaaaa"
  ],
  "CLASS": "1",
  "EN": "beginning",
  "FR": "commencement",
  "IEML": "E:M:.S:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("55d220df6653c32453c0ae0c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggabfaaaaegabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "travel",
  "FR": "voyage",
  "IEML": "l.o.-t.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae0d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "adc"
  ],
  "CLASS": "1",
  "EN": "logical must",
  "FR": "doit logique",
  "IEML": "E:O:A:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("55d220df6653c32453c0ae11")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffacgaaaaefacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "perfume",
  "FR": "parfum",
  "IEML": "m.i.-b.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae14")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeacfaaaaefacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "actor",
  "FR": "acteur",
  "IEML": "s.a.-b.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae15")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geaaaaaaahaadaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "textures",
  "FR": "textures",
  "IEML": "d.-M:.O:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220df6653c32453c0ae16")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "abe"
  ],
  "CLASS": "1",
  "EN": "worse",
  "FR": "pire",
  "IEML": "E:U:S:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae18")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geacgaaaageacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "quantitative data",
  "FR": "données quantitatives",
  "IEML": "d.i.-d.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae1c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffabgaaaaefacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "dialogue",
  "FR": "dialogue",
  "IEML": "m.e.-b.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae1f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fbahdaaaa"
  ],
  "CLASS": "4",
  "EN": "transformation on will basis",
  "FR": "transformation sur base de volonté",
  "IEML": "h.M:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220df6653c32453c0ae22")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggacfaaaageacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "company | business",
  "FR": "compagnie | entreprise",
  "IEML": "l.a.-d.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae23")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeacfaaaa"
  ],
  "CLASS": "4",
  "EN": "interpreter",
  "FR": "interprète",
  "IEML": "s.a.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae24")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggabgaaaageacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "coordinate system",
  "FR": "système de coordonnées",
  "IEML": "l.e.-d.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae26")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfaebaaaa"
  ],
  "CLASS": "4",
  "EN": "aesthetic vibration between people | aesthetic connection between people",
  "FR": "vibration esthétique entre personnes | connexion esthétique entre personnes",
  "IEML": "f.j.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae27")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffaceaaaaefaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "bewitched",
  "FR": "ensorcelé",
  "IEML": "m.u.-b.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae28")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeabgaaaaegaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "arithmetic operation",
  "FR": "opération arithmétique",
  "IEML": "s.e.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae29")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeadhaaaa"
  ],
  "CLASS": "4",
  "EN": "thought factors",
  "FR": "facteurs de pensée",
  "IEML": "s.O:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220df6653c32453c0ae2a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgabfaaaaegabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "progress",
  "FR": "progrès",
  "IEML": "n.o.-t.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae2b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geabgaaaafeacgaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in commercial know-how",
  "FR": "compétence en savoir-faire commercial",
  "IEML": "d.e.-k.i.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae2c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hdagbaaaa"
  ],
  "CLASS": "4",
  "EN": "transformation in ability",
  "FR": "transformation dans la capacité",
  "IEML": "M:O:.p.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220df6653c32453c0ae2e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gbaecaaaa"
  ],
  "CLASS": "4",
  "EN": "new judgement",
  "FR": "nouveau jugement",
  "IEML": "p.g.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae2f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egacgaaaaefacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "informative",
  "FR": "informatif",
  "IEML": "t.i.-b.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae31")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efabgaaaafgaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "literary life",
  "FR": "vie littéraire",
  "IEML": "b.e.-n.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae32")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fcagbaaaa"
  ],
  "CLASS": "4",
  "EN": "evolution of the offer",
  "FR": "évolution de l'offre",
  "IEML": "c.p.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae33")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feabgaaaageacfaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in acknowledging the facts",
  "FR": "compétence en reconnaissance des faits",
  "IEML": "k.e.-d.a.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae34")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgaceaaaafgaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "question",
  "FR": "question",
  "IEML": "n.u.-n.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae37")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffabbaaaa"
  ],
  "CLASS": "4",
  "EN": "appeal of the unknown",
  "FR": "appel de l'inconnu",
  "IEML": "m.wo.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae38")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgabgaaaaeeacfaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in giving meaning to a group",
  "FR": "compétence en indication du sens à  un groupe",
  "IEML": "n.e.-s.a.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae3a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egagbaaaa"
  ],
  "CLASS": "4",
  "EN": "accumulation | gain | benefit",
  "FR": "accumulation | gain | bénéfice",
  "IEML": "t.p.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae3c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fbagfaaaa"
  ],
  "CLASS": "4",
  "EN": "break-up",
  "FR": "rupture",
  "IEML": "h.f.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae3e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfabfaaaaggabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "organisation",
  "FR": "organisation",
  "IEML": "f.o.-l.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae3f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geabgaaaaffacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "body code | dress code",
  "FR": "code physique | code vestimentaire",
  "IEML": "d.e.-m.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae41")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggacgaaaaggacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "network",
  "FR": "réseau",
  "IEML": "l.i.-l.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae42")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bda"
  ],
  "CLASS": "2",
  "EN": "generate from the virtual",
  "FR": "générer à  partir du virtuel",
  "IEML": "U:O:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("55d220df6653c32453c0ae43")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggacfaaaaggacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "warrior",
  "FR": "guerrier",
  "IEML": "l.a.-l.a.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae44")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aeabfaaaa"
  ],
  "CLASS": "1",
  "EN": "will want",
  "FR": "vouloir au futur",
  "IEML": "E:S:.o.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae45")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggaceaaaaefaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "transcribed",
  "FR": "transcrit",
  "IEML": "l.u.-b.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae48")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egacfaaaaggacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "archive",
  "FR": "archive",
  "IEML": "t.a.-l.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae49")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ecafbaaaa"
  ],
  "CLASS": "4",
  "EN": "change of ideas",
  "FR": "changement d'idées",
  "IEML": "g.h.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae4a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "abacfaaaa"
  ],
  "CLASS": "1",
  "EN": "committed",
  "FR": "engagé",
  "IEML": "E:U:.a.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae4b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggabfaaaa"
  ],
  "CLASS": "4",
  "EN": "space organization",
  "FR": "organisation de l'espace",
  "IEML": "l.o.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae4c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ahafhaaaa"
  ],
  "CLASS": "1",
  "EN": "intermediary",
  "FR": "intermédiaire",
  "IEML": "E:M:.B:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("55d220df6653c32453c0ae4e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aid"
  ],
  "CLASS": "1",
  "EN": "logical strategy",
  "FR": "stratégie logique",
  "IEML": "E:F:O:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "10",
  "_id": ObjectId("55d220df6653c32453c0ae4f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geacfaaaaffacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "descendants",
  "FR": "descendance",
  "IEML": "d.a.-m.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae50")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeacgaaaaffacgaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "robot | mechanism",
  "FR": "robot | mécanisme",
  "IEML": "s.i.-m.i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae51")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feacfaaaafgacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "tribunal",
  "FR": "tribunal",
  "IEML": "k.a.-n.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae52")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffabfaaaaffabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "love",
  "FR": "amour",
  "IEML": "m.o.-m.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae55")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfaceaaaaggaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "aged",
  "FR": "âgé",
  "IEML": "f.u.-l.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae56")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feaceaaaageaceaaaageaceaaaa"
  ],
  "CLASS": "4",
  "EN": "illuminated",
  "FR": "illuminé",
  "IEML": "k.u.-d.u.-d.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae57")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ebaefaaaa"
  ],
  "CLASS": "4",
  "EN": "redundancy",
  "FR": "redondance",
  "IEML": "j.b.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae58")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egabfaaaaeeabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "future",
  "FR": "futur",
  "IEML": "t.o.-s.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae5a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfaceaaaagfaceaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "illusion",
  "FR": "illusion",
  "IEML": "f.u.-f.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae5b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggacgaaaafgacgaaaaegaceaaaa"
  ],
  "CLASS": "4",
  "EN": "cut | pierced",
  "FR": "découpé | percé",
  "IEML": "l.i.-n.i.-t.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae5c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egabgaaaageaceaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competence in information architecture",
  "FR": "compétence en architecture d'information",
  "IEML": "t.e.-d.u.-wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae5d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffabgaaaaeeacfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "teachings from others",
  "FR": "enseignements d'autrui",
  "IEML": "m.e.-s.a.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae5e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgabfaaaagfabfaaaaeeaceaaaa"
  ],
  "CLASS": "4",
  "EN": "healthy",
  "FR": "sain | en santé",
  "IEML": "n.o.-f.o.-s.u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae5f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gbagcaaaa"
  ],
  "CLASS": "4",
  "EN": "exchange",
  "FR": "échange",
  "IEML": "p.x.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae60")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggabfaaaagfabfaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "dwelling",
  "FR": "habitation",
  "IEML": "l.o.-f.o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ae62")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhacfaaaahhacfaaaaaaaaaaaaa",
    "hhacfaaaahhacfaaaagfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "social actors and functions",
  "FR": "fonctions et acteurs sociaux",
  "IEML": "M:M:.a.-M:M:.a.-E:.-+f.o.-'",
  "LAYER": "3",
  "PARADIGM": "1",
  "TAILLE": "162",
  "_id": ObjectId("55fb0408126f728c33dbc7e2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ehabgaaaahhaceaaaaaaaaaaaaa",
    "ehabgaaaahhaceaaaabcabgaaaa",
    "fhabgaaaahhacfaaaaaaaaaaaaa",
    "fhabgaaaahhacfaaaabcabgaaaa",
    "ghabgaaaahhacgaaaaaaaaaaaaa",
    "ghabgaaaahhacgaaaabcabgaaaa"
  ],
  "CLASS": "4",
  "EN": "competencies and objects of competencies",
  "FR": "compétences et objets de compétences",
  "ID": null,
  "IEML": "S:M:.e.-M:M:.u.-E:.-+wa.e.-'+B:M:.e.-M:M:.a.-E:.-+wa.e.-'+T:M:.e.-M:M:.i.-E:.-+wa.e.-'",
  "LAYER": "3",
  "PARADIGM": "1",
  "TAILLE": "162",
  "_id": ObjectId("562404bb660a68d9de44c878")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gdaebaaaa"
  ],
  "CLASS": "4",
  "EN": "T:O:.j.- test",
  "FR": "T:O:.j.- test again",
  "IEML": "T:O:.j.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("5643db929b2d5747911911a1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "abagfaaaa"
  ],
  "CLASS": "1",
  "EN": "under",
  "FR": "sous",
  "IEML": "E:U:.f.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a6e0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aiaeeaaaa"
  ],
  "CLASS": "1",
  "EN": "tension of exi-stance",
  "FR": "tension d'exi-stance",
  "IEML": "E:F:.s.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "5",
  "_id": ObjectId("5641463b9b2d57479119119d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aiaffaaaa"
  ],
  "CLASS": "1",
  "EN": "relation of inter-stance",
  "FR": "relation d'inter-stance",
  "IEML": "E:F:.m.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "5",
  "_id": ObjectId("5647d6b6c1d763d245621bc5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aiafeaaaa"
  ],
  "CLASS": "1",
  "EN": "tension d'inter-stance",
  "FR": "tension d'inter-stance",
  "IEML": "E:F:.k.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "5",
  "_id": ObjectId("564147f59b2d57479119119e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aiafgaaaa"
  ],
  "CLASS": "1",
  "EN": "structure of inter-stance",
  "FR": "structure d'inter-stance",
  "IEML": "E:F:.n.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "5",
  "_id": ObjectId("5647d6d4c1d763d245621bc6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aeaefaaaa"
  ],
  "CLASS": "1",
  "EN": "point of departure",
  "FR": "point de départ",
  "IEML": "E:S:.b.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad94")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "agaffaaaa"
  ],
  "CLASS": "1",
  "EN": "through",
  "FR": "à  travers",
  "IEML": "E:T:.m.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0ab26")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aiaghaaaa"
  ],
  "CLASS": "1",
  "EN": "insi-stance (spatial situation)",
  "FR": "insi-stance (situation spatiale)",
  "IEML": "E:F:.T:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "15",
  "_id": ObjectId("564d05c3c1d763d245621bcb")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ahahfaaaa"
  ],
  "CLASS": "1",
  "EN": "lateral",
  "FR": "lateral",
  "IEML": "E:M:.M:B:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("564e54cbc1d763d245621bcd")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aif"
  ],
  "CLASS": "1",
  "EN": "medium (gradient)",
  "FR": "medium (gradient)",
  "IEML": "E:F:B:.",
  "LAYER": "1",
  "PARADIGM": "0",
  "TAILLE": "5",
  "_id": ObjectId("56512725c1d763d245621bcf")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "abacbaaaa"
  ],
  "CLASS": "1",
  "EN": "demonstrative masculine",
  "FR": "démonstratif masculin",
  "IEML": "E:U:.wu.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5f0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ababbaaaa"
  ],
  "CLASS": "1",
  "EN": "demonstrative singular",
  "FR": "démonstratif singulier",
  "IEML": "E:U:.wo.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abd4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ababcaaaa"
  ],
  "CLASS": "1",
  "EN": "demonstrative plural",
  "FR": "démonstratif pluriel",
  "IEML": "E:U:.wa.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac32")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "afabcaaaa"
  ],
  "CLASS": "1",
  "EN": "second person plural",
  "FR": "deuxième personne pluriel",
  "IEML": "E:B:.wa.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0abb2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "agabcaaaa"
  ],
  "CLASS": "1",
  "EN": "third person plural",
  "FR": "troisième personne plurielle",
  "IEML": "E:T:.wa.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0adca")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aeabbaaaa"
  ],
  "CLASS": "1",
  "EN": "first person singular | I | me",
  "FR": "première personne singulier | je | moi",
  "IEML": "E:S:.wo.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac58")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "acaddaaaa"
  ],
  "CLASS": "1",
  "EN": "possessive pronoun",
  "FR": "pronom possessif",
  "IEML": "E:A:.O:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220dd6653c32453c0a999")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aeaddaaaa"
  ],
  "CLASS": "1",
  "EN": "pronoun in the first person",
  "FR": "pronom à la première personne",
  "IEML": "E:S:.O:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220dc6653c32453c0a614")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "afaddaaaa"
  ],
  "CLASS": "1",
  "EN": "pronoun in the second person",
  "FR": "pronom à la deuxième personne",
  "IEML": "E:B:.O:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220de6653c32453c0ab81")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "agaddaaaa"
  ],
  "CLASS": "1",
  "EN": "pronoun in the third person",
  "FR": "pronom à troisième personne",
  "IEML": "E:T:.O:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "4",
  "_id": ObjectId("55d220dd6653c32453c0a89d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aeabdaaaa"
  ],
  "CLASS": "1",
  "EN": "pronoun of number in the first person",
  "FR": "pronom de nombre à la première personne",
  "IEML": "E:S:.U:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("565131b0c1d763d245621bd0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aeacdaaaa"
  ],
  "CLASS": "1",
  "EN": "pronoun of gender in the first person",
  "FR": "pronom de genre à la première personne",
  "IEML": "E:S:.A:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("565131d7c1d763d245621bd1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aeadbaaaa"
  ],
  "CLASS": "1",
  "EN": "pronoun in the first person masculine singular",
  "FR": "pronom à la première personne masculin singulier",
  "IEML": "E:S:.O:U:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("565132eec1d763d245621bd2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aeadcaaaa"
  ],
  "CLASS": "1",
  "EN": "pronoun at the first person plural feminine",
  "FR": "pronom à la première personne du pluriel féminin",
  "IEML": "E:S:.O:A:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("56513333c1d763d245621bd3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "afabdaaaa"
  ],
  "CLASS": "1",
  "EN": "pronoun of number in the second person",
  "FR": "pronom de nombre à la deuxième personne",
  "IEML": "E:B:.U:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("565133a1c1d763d245621bd4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "afacdaaaa"
  ],
  "CLASS": "1",
  "EN": "pronoun of gender in the second person",
  "FR": "pronom de genre à la seconde personne",
  "IEML": "E:B:.A:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("565133ccc1d763d245621bd5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "afadbaaaa"
  ],
  "CLASS": "1",
  "EN": "pronoun in the second person masculine singular",
  "FR": "pronom deuxième personne masculin singulier",
  "IEML": "E:B:.O:U:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("56513416c1d763d245621bd6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "afadcaaaa"
  ],
  "CLASS": "1",
  "EN": "pronoun in the second person feminine plural",
  "FR": "pronom à la seconde deuxième personne féminin pluriel",
  "IEML": "E:B:.O:A:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("5651344bc1d763d245621bd7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "agabdaaaa"
  ],
  "CLASS": "1",
  "EN": "pronoun of number in the third person",
  "FR": "pronom de nombre à la troisième personne",
  "IEML": "E:T:.U:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("5651349bc1d763d245621bd8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "agadbaaaa"
  ],
  "CLASS": "1",
  "EN": "pronoun in the third person masculine singular",
  "FR": "pronom à la troisième personne masculin singulier",
  "IEML": "E:T:.O:U:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("565134d1c1d763d245621bd9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "agadcaaaa"
  ],
  "CLASS": "1",
  "EN": "pronoun in the third person feminine plural",
  "FR": "pronom à la troisième personne féminin pluriel",
  "IEML": "E:T:.O:A:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("5651350cc1d763d245621bda")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "acabdaaaa"
  ],
  "CLASS": "1",
  "EN": "possessive pronoun of number",
  "FR": "pronom possessif de nombre",
  "IEML": "E:A:.U:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("565135f6c1d763d245621bdb")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "acacdaaaa"
  ],
  "CLASS": "1",
  "EN": "possessive pronoun of gender",
  "FR": "pronom possessif de genre",
  "IEML": "E:A:.A:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("5651361dc1d763d245621bdc")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "acadbaaaa"
  ],
  "CLASS": "1",
  "EN": "possessive pronoun masculine singular",
  "FR": "pronom possessif masculin singulier",
  "IEML": "E:A:.O:U:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("56513647c1d763d245621bdd")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "acadcaaaa"
  ],
  "CLASS": "1",
  "EN": "possessive pronoun feminine plural",
  "FR": "pronom possessif féminin pluriel",
  "IEML": "E:A:.O:A:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("5651366ec1d763d245621bde")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ababdaaaa"
  ],
  "CLASS": "1",
  "EN": "demonstrative pronoun of number",
  "FR": "pronom démonstratif de nombre",
  "IEML": "E:U:.U:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("565136d0c1d763d245621bdf")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "abacdaaaa"
  ],
  "CLASS": "1",
  "EN": "demonstrative pronoun of gender",
  "FR": "pronom démonstratif de genre",
  "IEML": "E:U:.A:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("565136f6c1d763d245621be0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "abadbaaaa"
  ],
  "CLASS": "1",
  "EN": "demonstrative pronoun masculine singular",
  "FR": "pronom démonstratif masculin singulier",
  "IEML": "E:U:.O:U:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("56513723c1d763d245621be1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "abadcaaaa"
  ],
  "CLASS": "1",
  "EN": "demonstrative pronoun feminine plural",
  "FR": "pronom démonstratif féminin pluriel",
  "IEML": "E:U:.O:A:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("56513759c1d763d245621be2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ahabbaaaa"
  ],
  "CLASS": "1",
  "EN": "singular pronoun of person",
  "FR": "pronom de personne singulier",
  "IEML": "E:M:.wo.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("56513810c1d763d245621be4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ahabcaaaa"
  ],
  "CLASS": "1",
  "EN": "plural pronoun of person",
  "FR": "pronom de personne pluriel",
  "IEML": "E:M:.wa.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("56513842c1d763d245621be5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ahacbaaaa"
  ],
  "CLASS": "1",
  "EN": "masculine pronoun of person",
  "FR": "pronom de personne masculin",
  "IEML": "E:M:.wu.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("56513860c1d763d245621be6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ahaccaaaa"
  ],
  "CLASS": "1",
  "EN": "feminine pronoun of person",
  "FR": "pronom de personne féminin",
  "IEML": "E:M:.we.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("5651387dc1d763d245621be7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ahaddaaaa"
  ],
  "CLASS": "1",
  "EN": "pronoun of person (first, second, third)",
  "FR": "pronom de personne (première, deuxième, troisième)",
  "IEML": "E:M:.O:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "12",
  "_id": ObjectId("565137d8c1d763d245621be3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "adaddaaaa"
  ],
  "CLASS": "1",
  "EN": "possessive | demonstrative pronoun",
  "FR": "pronom démonstratif | possessif",
  "IEML": "E:O:.O:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "8",
  "_id": ObjectId("56513903c1d763d245621be8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "adabbaaaa"
  ],
  "CLASS": "1",
  "EN": "possessive | demonstrative singular",
  "FR": "possessif | démonstratif singulier",
  "IEML": "E:O:.wo.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("5651394cc1d763d245621be9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "adabcaaaa"
  ],
  "CLASS": "1",
  "EN": "possessive | demonstrative plural",
  "FR": "possessif | démonstratif pluriel",
  "IEML": "E:O:.wa.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("56513973c1d763d245621bea")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "adacbaaaa"
  ],
  "CLASS": "1",
  "EN": "possessive | demonstrative masculine",
  "FR": "possessif | demonstratif masculin",
  "IEML": "E:O:.wu.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("5651399bc1d763d245621beb")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "adaccaaaa"
  ],
  "CLASS": "1",
  "EN": "possessive | demonstrative feminine",
  "FR": "possessif | demonstratif féminin",
  "IEML": "E:O:.we.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("565139cec1d763d245621bec")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "abaceaaaa"
  ],
  "CLASS": "1",
  "EN": "expressed",
  "FR": "exprimé",
  "IEML": "E:U:.u.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("5653a78007c239ab72d2b5dd")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aeabeaaaa"
  ],
  "CLASS": "1",
  "EN": "will know",
  "FR": "connaître au futur",
  "IEML": "E:S:.y.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a7c4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aeabgaaaa"
  ],
  "CLASS": "1",
  "EN": "will be able",
  "FR": "pouvoir au futur",
  "IEML": "E:S:.e.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a613")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aeacfaaaa"
  ],
  "CLASS": "1",
  "EN": "will commit",
  "FR": "s'engager au futur",
  "IEML": "E:S:.a.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a695")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "abacgaaaa"
  ],
  "CLASS": "1",
  "EN": "must be done",
  "FR": "devant être fait",
  "IEML": "E:U:.i.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ad3d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "agabeaaaa"
  ],
  "CLASS": "1",
  "EN": "knowing in the past",
  "FR": "connaître au passé",
  "IEML": "E:T:.y.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0adf5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "agabfaaaa"
  ],
  "CLASS": "1",
  "EN": "want in the past",
  "FR": "vouloir au passé",
  "IEML": "E:T:.o.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a88e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "agabgaaaa"
  ],
  "CLASS": "1",
  "EN": "can in the past",
  "FR": "pouvoir au passé",
  "IEML": "E:T:.e.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0a9f5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "agaceaaaa"
  ],
  "CLASS": "1",
  "EN": "express in the past",
  "FR": "exprimer au passé",
  "IEML": "E:T:.u.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220df6653c32453c0ac31")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "agacfaaaa"
  ],
  "CLASS": "1",
  "EN": "commit in the past",
  "FR": "s'engager au passé",
  "IEML": "E:T:.a.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aaa1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ababhaaaa"
  ],
  "CLASS": "1",
  "EN": "virtual passive voice",
  "FR": "voix passive virtuelle",
  "IEML": "E:U:.U:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("5653ac2107c239ab72d2b5de")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "abachaaaa"
  ],
  "CLASS": "1",
  "EN": "actual passive voice",
  "FR": "voix passive actuelle",
  "IEML": "E:U:.A:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("5653ac3f07c239ab72d2b5df")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "abadeaaaa"
  ],
  "CLASS": "1",
  "EN": "passive voice according to sign",
  "FR": "voix passive selon le signe",
  "IEML": "E:U:.O:S:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("5653ac6007c239ab72d2b5e0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "abadfaaaa"
  ],
  "CLASS": "1",
  "EN": "passive voice according to being",
  "FR": "voix passive selon l'être",
  "IEML": "E:U:.O:B:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("5653ac7e07c239ab72d2b5e1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "abadgaaaa"
  ],
  "CLASS": "1",
  "EN": "passive voice according to thing",
  "FR": "voix passive selon la chose",
  "IEML": "E:U:.O:T:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("5653ac9a07c239ab72d2b5e2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "agacdaaaa"
  ],
  "CLASS": "1",
  "EN": "gender pronoun at the third person",
  "FR": "pronom de genre à la troisième personne",
  "IEML": "E:T:.A:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("565f43c8ddd8757dcd083891")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "acadeaaaa"
  ],
  "CLASS": "1",
  "EN": "active voice according to sign",
  "FR": "voix active selon le signe",
  "IEML": "E:A:.O:S:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("565f457addd8757dcd083892")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "acadfaaaa"
  ],
  "CLASS": "1",
  "EN": "active voice according to being",
  "FR": "voix active selon l'être",
  "IEML": "E:A:.O:B:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("565f459dddd8757dcd083893")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "acadgaaaa"
  ],
  "CLASS": "1",
  "EN": "active voice according to thing",
  "FR": "voix active selon la chose",
  "IEML": "E:A:.O:T:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("565f45b9ddd8757dcd083894")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "acabhaaaa"
  ],
  "CLASS": "1",
  "EN": "virtual active voice",
  "FR": "voix active virtuelle",
  "IEML": "E:A:.U:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("565f45dbddd8757dcd083895")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "acachaaaa"
  ],
  "CLASS": "1",
  "EN": "actual active voice",
  "FR": "voix active actuelle",
  "IEML": "E:A:.A:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("565f45f1ddd8757dcd083896")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aeadeaaaa"
  ],
  "CLASS": "1",
  "EN": "future according to sign",
  "FR": "futur selon le signe",
  "IEML": "E:S:.O:S:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("565f4631ddd8757dcd083897")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aeadfaaaa"
  ],
  "CLASS": "1",
  "EN": "future according to being",
  "FR": "futur selon l'être",
  "IEML": "E:S:.O:B:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("565f4654ddd8757dcd083898")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aeadgaaaa"
  ],
  "CLASS": "1",
  "EN": "future according to thing",
  "FR": "futur selon la chose",
  "IEML": "E:S:.O:T:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("565f4672ddd8757dcd083899")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aeabhaaaa"
  ],
  "CLASS": "1",
  "EN": "virtual future",
  "FR": "futur virtuel",
  "IEML": "E:S:.U:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("565f468fddd8757dcd08389a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "afadeaaaa"
  ],
  "CLASS": "1",
  "EN": "present according to sign",
  "FR": "présent selon le signe",
  "IEML": "E:B:.O:S:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("565f46bcddd8757dcd08389b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "afadfaaaa"
  ],
  "CLASS": "1",
  "EN": "present according to being",
  "FR": "présent selon l'être",
  "IEML": "E:B:.O:B:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("565f46d2ddd8757dcd08389c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "afadgaaaa"
  ],
  "CLASS": "1",
  "EN": "present according to thing",
  "FR": "présent selon la chose",
  "IEML": "E:B:.O:T:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("565f46eaddd8757dcd08389d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "afabhaaaa"
  ],
  "CLASS": "1",
  "EN": "virtual present",
  "FR": "présent virtuel",
  "IEML": "E:B:.U:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("565f46ffddd8757dcd08389e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "afachaaaa"
  ],
  "CLASS": "1",
  "EN": "actual present",
  "FR": "présent actuel",
  "IEML": "E:B:.A:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("565f4715ddd8757dcd08389f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "agadeaaaa"
  ],
  "CLASS": "1",
  "EN": "past according to sign",
  "FR": "passé selon le signe",
  "IEML": "E:T:.O:S:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("565f473cddd8757dcd0838a0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "agadfaaaa"
  ],
  "CLASS": "1",
  "EN": "past according to being",
  "FR": "passé selon l'être",
  "IEML": "E:T:.O:B:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("565f4751ddd8757dcd0838a1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "agadgaaaa"
  ],
  "CLASS": "1",
  "EN": "past according to thing",
  "FR": "passé selon la chose",
  "IEML": "E:T:.O:T:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("565f4766ddd8757dcd0838a2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "agabhaaaa"
  ],
  "CLASS": "1",
  "EN": "virtual past",
  "FR": "passé virtuel",
  "IEML": "E:T:.U:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("565f477addd8757dcd0838a3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "agachaaaa"
  ],
  "CLASS": "1",
  "EN": "actual past",
  "FR": "passé actuel",
  "IEML": "E:T:.A:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("565f4793ddd8757dcd0838a4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "agagbaaaa"
  ],
  "CLASS": "1",
  "EN": "finality | of an action",
  "FR": "finalité | but d'une action",
  "IEML": "E:T:.p.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a5e9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aeafdaaaa"
  ],
  "CLASS": "1",
  "EN": "functional role",
  "FR": "rôle fonctionnel",
  "IEML": "E:S:.B:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("565f4b13ddd8757dcd0838a6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aeaedaaaa"
  ],
  "CLASS": "1",
  "EN": "set-element role",
  "FR": "rôle ensembliste",
  "IEML": "E:S:.S:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("565f4b49ddd8757dcd0838a7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "afaedaaaa"
  ],
  "CLASS": "1",
  "EN": "evolutionary role",
  "FR": "rôle évolutif",
  "IEML": "E:B:.S:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("565f4c2bddd8757dcd0838aa")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "afafdaaaa"
  ],
  "CLASS": "1",
  "EN": "operational role",
  "FR": "rôle opératoire",
  "IEML": "E:B:.B:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("565f4c7eddd8757dcd0838ab")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "afagdaaaa"
  ],
  "CLASS": "1",
  "EN": "action role",
  "FR": "rôle d'action",
  "IEML": "E:B:.T:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("565f4d10ddd8757dcd0838ac")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "agagcaaaa"
  ],
  "CLASS": "1",
  "EN": "mean | instrument of an action",
  "FR": "moyen | instrument d'une action",
  "IEML": "E:T:.x.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dc6653c32453c0a787")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "agaedaaaa"
  ],
  "CLASS": "1",
  "EN": "matter-form relationship",
  "FR": "relation matière-forme",
  "IEML": "E:T:.S:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("565f4ddcddd8757dcd0838ad")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "agaebaaaa"
  ],
  "CLASS": "1",
  "EN": "form | structure",
  "FR": "forme | structure",
  "IEML": "E:T:.j.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a8f0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "agagdaaaa"
  ],
  "CLASS": "1",
  "EN": "mean-end relationship",
  "FR": "relation fin-moyen",
  "IEML": "E:T:.T:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("565f4e42ddd8757dcd0838ae")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "agafdaaaa"
  ],
  "CLASS": "1",
  "EN": "system-state relationship",
  "FR": "relation système-état",
  "IEML": "E:T:.B:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("565f4e9cddd8757dcd0838af")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "agahcaaaa"
  ],
  "CLASS": "1",
  "EN": "actual realization",
  "FR": "réalisation actuelle",
  "IEML": "E:T:.M:A:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("565f4f6addd8757dcd0838b1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "afahbaaaa"
  ],
  "CLASS": "1",
  "EN": "virtualising cause",
  "FR": "cause virtualisante",
  "IEML": "E:B:.M:U:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("565f50d4ddd8757dcd0838b2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "afahcaaaa"
  ],
  "CLASS": "1",
  "EN": "actualizing cause",
  "FR": "cause actualisante",
  "IEML": "E:B:.M:A:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("565f50f1ddd8757dcd0838b3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aeahcaaaa"
  ],
  "CLASS": "1",
  "EN": "actualising specification",
  "FR": "spécification actualisante",
  "IEML": "E:S:.M:A:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("565f4bb3ddd8757dcd0838a9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "aeahbaaaa"
  ],
  "CLASS": "1",
  "EN": "virtualizing specification",
  "FR": "spécification virtualisante",
  "IEML": "E:S:.M:U:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("565f4b9cddd8757dcd0838a8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "agahbaaaa"
  ],
  "CLASS": "1",
  "EN": "virtual realization",
  "FR": "réalisation virtuelle",
  "IEML": "E:T:.M:U:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("565f4f55ddd8757dcd0838b0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "adaebaaaa"
  ],
  "CLASS": "1",
  "EN": "manner of resemblance",
  "FR": "manière de ressemblance",
  "IEML": "E:O:.j.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("55d220de6653c32453c0a9de")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "acaebaaaa"
  ],
  "CLASS": "1",
  "EN": "by analogy | in a similar manner | as",
  "FR": "par analogie | d'une manière semblable | comme",
  "IEML": "E:A:.j.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220de6653c32453c0aba4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "abahbaaaa"
  ],
  "CLASS": "1",
  "EN": "virtual negativity",
  "FR": "négativité virtuelle",
  "IEML": "E:U:.M:U:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("565f68a7ddd8757dcd0838b4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "abahcaaaa"
  ],
  "CLASS": "1",
  "EN": "actual negativity",
  "FR": "négativité actuelle",
  "IEML": "E:U:.M:A:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("565f68c5ddd8757dcd0838b5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "abaedaaaa"
  ],
  "CLASS": "1",
  "EN": "negative comparison",
  "FR": "comparaison négative",
  "IEML": "E:U:.S:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("565f68eaddd8757dcd0838b6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "abafdaaaa"
  ],
  "CLASS": "1",
  "EN": "negative orientation",
  "FR": "orientation négative",
  "IEML": "E:U:.B:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("565f6967ddd8757dcd0838b7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "acaedaaaa"
  ],
  "CLASS": "1",
  "EN": "positive comparison",
  "FR": "comparaison positive",
  "IEML": "E:A:.S:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("565f69a3ddd8757dcd0838b8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "acafdaaaa"
  ],
  "CLASS": "1",
  "EN": "positive orientation",
  "FR": "orientation positive",
  "IEML": "E:A:.B:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("565f69b7ddd8757dcd0838b9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "acagdaaaa"
  ],
  "CLASS": "1",
  "EN": "positive definition",
  "FR": "définition positive",
  "IEML": "E:A:.T:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("565f69e0ddd8757dcd0838ba")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "acahbaaaa"
  ],
  "CLASS": "1",
  "EN": "virtual positivity",
  "FR": "positivité virtuelle",
  "IEML": "E:A:.M:U:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("565f6a1bddd8757dcd0838bb")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "acahcaaaa"
  ],
  "CLASS": "1",
  "EN": "actual positivity",
  "FR": "positivité actuelle",
  "IEML": "E:A:.M:A:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("565f6a32ddd8757dcd0838bc")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "abagdaaaa"
  ],
  "CLASS": "1",
  "EN": "negative definition",
  "FR": "définition négative",
  "IEML": "E:U:.T:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("565f6a95ddd8757dcd0838bd")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ehabgaaaa"
  ],
  "CLASS": "4",
  "EN": "know how of the sign",
  "FR": "savoir faire du signe",
  "IEML": "S:M:.e.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("566395e94cb331bd5293408b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fhabgaaaa"
  ],
  "CLASS": "4",
  "EN": "know how of the being",
  "FR": "savoir faire de l'être",
  "IEML": "B:M:.e.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("566396174cb331bd52934090")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ghabgaaaa"
  ],
  "CLASS": "4",
  "EN": "know how of the thing",
  "FR": "savoir faire de la chose",
  "IEML": "T:M:.e.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("566396374cb331bd52934095")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bbabdaaaa"
  ],
  "CLASS": "2",
  "EN": "going through the waxing phase of the symbolic cycle",
  "FR": "traverser la phase croissante du cycle symbolique",
  "IEML": "wo.U:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("566488824cb331bd5293409f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bbacdaaaa"
  ],
  "CLASS": "2",
  "EN": "going through the waning phase of the symbolic cycle",
  "FR": "traverser la phase décroissante du cycle symbolique",
  "IEML": "wo.A:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("566488db4cb331bd529340a4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bbadbaaaa"
  ],
  "CLASS": "2",
  "EN": "begin a phase of the symbolic cycle",
  "FR": "commencer une phase du cycle symbolique",
  "IEML": "wo.O:U:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("566489414cb331bd529340a9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bbadcaaaa"
  ],
  "CLASS": "2",
  "EN": "end a phase of the symbolic phase",
  "FR": "terminer une phase du cycle symbolique",
  "IEML": "wo.O:A:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("5664896b4cb331bd529340ae")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bcabdaaaa"
  ],
  "CLASS": "2",
  "EN": "going through the waxing phase of the daily cycle",
  "FR": "traverser la phase croissante du cycle quotidien",
  "IEML": "wa.U:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("56648a9e4cb331bd529340b3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bcacdaaaa"
  ],
  "CLASS": "2",
  "EN": "going through the waning phase of the daily cycle",
  "FR": "traverser la phase décroissante du cycle quotidien",
  "IEML": "wa.A:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("56648b9f4cb331bd529340b8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bcadbaaaa"
  ],
  "CLASS": "2",
  "EN": "begin a phase of the daily cycle",
  "FR": "commencer une phase du cycle quotidien",
  "IEML": "wa.O:U:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("56648c4a4cb331bd529340bd")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bcadcaaaa"
  ],
  "CLASS": "2",
  "EN": "end a phase of the daily cycle",
  "FR": "terminer une phase du cycle quotidien",
  "IEML": "wa.O:A:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("56648c7c4cb331bd529340c2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cbabdaaaa"
  ],
  "CLASS": "2",
  "EN": "going through the waxing phase of the age cycle",
  "FR": "traverser la phase croissante du cycle des âges",
  "IEML": "wu.U:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("56648d1c4cb331bd529340c7")
});
db.getCollection("terms").insert({
  "IEML": "wu.A:O:.-",
  "FR": "traverser la phase décroissante du cycle des âges",
  "EN": "going through the waning phase of the age cycle",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "cbacdaaaa"
  ],
  "_id": ObjectId("56648d624cb331bd529340cc")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cbadbaaaa"
  ],
  "CLASS": "2",
  "EN": "begin a phase of the age cycle",
  "FR": "commencer une phase du cycle des âges",
  "IEML": "wu.O:U:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("56648dc94cb331bd529340d1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cbadcaaaa"
  ],
  "CLASS": "2",
  "EN": "end a phase of the age cycle",
  "FR": "terminer une phase du cycle des âges",
  "IEML": "wu.O:A:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("56648e1b4cb331bd529340d6")
});
db.getCollection("terms").insert({
  "IEML": "we.U:O:.-",
  "FR": "traverser la phase croissante du cycle reproducteur",
  "EN": "going through the waxing phase of the reproductive cycle",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "ccabdaaaa"
  ],
  "_id": ObjectId("56648eac4cb331bd529340db")
});
db.getCollection("terms").insert({
  "IEML": "we.A:O:.-",
  "FR": "traverser la phase décroissante du cycle reproducteur",
  "EN": "going through the waning phase of the reproductive cycle",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "ccacdaaaa"
  ],
  "_id": ObjectId("56648ee54cb331bd529340e0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ccadbaaaa"
  ],
  "CLASS": "2",
  "EN": "begin a phase of the reproductive cycle",
  "FR": "commencer une phase du cycle reproducteur",
  "IEML": "we.O:U:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("56648f334cb331bd529340e5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ccadcaaaa"
  ],
  "CLASS": "2",
  "EN": "end a phase of the reproductive cycle",
  "FR": "terminer une phase du cycle reproducteur",
  "IEML": "we.O:A:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("56648f644cb331bd529340ea")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bdabbaaaa"
  ],
  "CLASS": "2",
  "EN": "begin the waxing phase of the symbolic and daily cycles",
  "FR": "commencer la phase croissante des cycles symbolique et quotidien",
  "IEML": "U:O:.wo.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("566493e14cb331bd529340ef")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cdabbaaaa"
  ],
  "CLASS": "2",
  "EN": "begin the waxing phase of the age and reproductive cycles",
  "FR": "commencer la phase croissante des cycles des âges et reproducteur",
  "IEML": "A:O:.wo.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("5664943c4cb331bd529340f4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dbabbaaaa"
  ],
  "CLASS": "2",
  "EN": "begin the waxing phase of the symbolic and age cycles",
  "FR": "commencer la phase croissante des cycles symbolique et des âges",
  "IEML": "O:U:.wo.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("566494994cb331bd529340f9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dcabbaaaa"
  ],
  "CLASS": "2",
  "EN": "begin the waxing phase of the daily and reproductive cycles",
  "FR": "commencer la phase croissante des cycles quotidien et reproducteur",
  "IEML": "O:A:.wo.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("566494e04cb331bd529340fe")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bdabcaaaa"
  ],
  "CLASS": "2",
  "EN": "end the waxing phase of the symbolic and daily cycles",
  "FR": "terminer la phase croissante des cycles symbolique et quotidien",
  "IEML": "U:O:.wa.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("566495664cb331bd52934103")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cdabcaaaa"
  ],
  "CLASS": "2",
  "EN": "end the waxing phase of the age and reproductive cycles",
  "FR": "terminer la phase croissante des cycles des âges et reproducteur",
  "IEML": "A:O:.wa.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("566495a94cb331bd52934108")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dbabcaaaa"
  ],
  "CLASS": "2",
  "EN": "end the waxing phase of the symbolic and age cycles",
  "FR": "terminer la phase croissante des cycles symbolique et des âges",
  "IEML": "O:U:.wa.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("566495ee4cb331bd5293410d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dcabcaaaa"
  ],
  "CLASS": "2",
  "EN": "end the waxing phase of the daily and reproductive cycles",
  "FR": "terminer la phase croissante des cycles quotidien et reproducteur",
  "IEML": "O:A:.wa.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("566496244cb331bd52934112")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bdacbaaaa"
  ],
  "CLASS": "2",
  "EN": "begin the waning phase of the symbolic and daily cycles",
  "FR": "commencer la phase décroissante des cycles symbolique et quotidien",
  "IEML": "U:O:.wu.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("5664968f4cb331bd52934117")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cdacbaaaa"
  ],
  "CLASS": "2",
  "EN": "begin the waning phase of the age and reproductive cycles",
  "FR": "commencer la phase décroissante des cycles des âges et reproducteur",
  "IEML": "A:O:.wu.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("566496d34cb331bd5293411c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dbacbaaaa"
  ],
  "CLASS": "2",
  "EN": "begin the waning phase of the symbolic and age cycles",
  "FR": "commencer la phase décroissante des cycles symbolique et des âges",
  "IEML": "O:U:.wu.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("5664971b4cb331bd52934121")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dcacbaaaa"
  ],
  "CLASS": "2",
  "EN": "begin the waning phase of the daily and reproductive cycles",
  "FR": "commencer la phase décroissante des cycles quotidien et reproducteur",
  "IEML": "O:A:.wu.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("5664976b4cb331bd52934126")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bdaccaaaa"
  ],
  "CLASS": "2",
  "EN": "end the waning phase of the symbolic and daily cycles",
  "FR": "terminer la phase décroissante des cycles symbolique et quotidien",
  "IEML": "U:O:.we.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("566497e24cb331bd5293412b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cdaccaaaa"
  ],
  "CLASS": "2",
  "EN": "end the waning phase of the age and reproductive cycle",
  "FR": "terminer la phase décroissante des cycles des âges et reproducteur",
  "IEML": "A:O:.we.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("566498294cb331bd52934130")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dbaccaaaa"
  ],
  "CLASS": "2",
  "EN": "end the waning phase of the symbolic and age cycles",
  "FR": "terminer la phase décroissante des cycles symbolique et des âges",
  "IEML": "O:U:.we.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("5664988e4cb331bd52934135")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dcaccaaaa"
  ],
  "CLASS": "2",
  "EN": "end the waning phase of the daily and reproductive cycles",
  "FR": "terminer la phase décroissante des cycles quotidien et reproducteur",
  "IEML": "O:A:.we.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("566498c64cb331bd5293413a")
});
db.getCollection("terms").insert({
  "IEML": "O:.-M:M:.e.-'",
  "FR": "acquérir l'habileté",
  "EN": "gain the ability",
  "PARADIGM": "1",
  "LAYER": "3",
  "CLASS": "2",
  "TAILLE": "18",
  "CANONICAL": [
    "daaaaaaaahhabgaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("5664e2ef4cb331bd5293413f")
});
db.getCollection("terms").insert({
  "IEML": "U:.-M:M:.e.-'",
  "FR": "habileté virtuelle (acquérir)",
  "EN": "virtual ability (gain)",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "2",
  "TAILLE": "9",
  "CANONICAL": [
    "baaaaaaaahhabgaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("5664e4134cb331bd52934144")
});
db.getCollection("terms").insert({
  "IEML": "A:.-M:M:.e.-'",
  "FR": "habileté actuelle (acquérir)",
  "EN": "actual ability (gain)",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "2",
  "TAILLE": "9",
  "CANONICAL": [
    "caaaaaaaahhabgaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("5664e4c24cb331bd52934149")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "daaaaaaaaeeabgaaaaaaaaaaaaa"
  ],
  "CLASS": "2",
  "EN": "mastering of the code (gain)",
  "FR": "maîtrise du code (acquérir)",
  "IEML": "O:.-s.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("5664e58a4cb331bd5293414e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "daaaaaaaaefabgaaaaaaaaaaaaa"
  ],
  "CLASS": "2",
  "EN": "reasoning (gain)",
  "FR": "raisonnement (acquérir)",
  "IEML": "O:.-b.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("5664e5f54cb331bd52934153")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "daaaaaaaaegabgaaaaaaaaaaaaa"
  ],
  "CLASS": "2",
  "EN": "persuasion (gain)",
  "FR": "persuasion (acquérir)",
  "IEML": "O:.-t.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("5664e65d4cb331bd52934158")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "daaaaaaaafeabgaaaaaaaaaaaaa"
  ],
  "CLASS": "2",
  "EN": "self-control (gain)",
  "FR": "maîtrise de soi (acquérir)",
  "IEML": "O:.-k.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("5664e6f44cb331bd5293415d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "daaaaaaaaffabgaaaaaaaaaaaaa"
  ],
  "CLASS": "2",
  "EN": "mastering negotiation (gain)",
  "FR": "maîtrise de la négociation (acquérir)",
  "IEML": "O:.-m.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("5664e7d54cb331bd52934162")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "daaaaaaaafgabgaaaaaaaaaaaaa"
  ],
  "CLASS": "2",
  "EN": "ability to lead (gain)",
  "FR": "capacité de diriger (acquérir)",
  "IEML": "O:.-n.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("5664e80c4cb331bd52934167")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "daaaaaaaageabgaaaaaaaaaaaaa"
  ],
  "CLASS": "2",
  "EN": "improve sensori-motor abilities",
  "FR": "perfectionner la sensorimotricité",
  "IEML": "O:.-d.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("5664e8a84cb331bd5293416c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "daaaaaaaagfabgaaaaaaaaaaaaa"
  ],
  "CLASS": "2",
  "EN": "technical (gain)",
  "FR": "capacités technique (acquérir)",
  "IEML": "O:.-f.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("5664e8f44cb331bd52934171")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "daaaaaaaaggabgaaaaaaaaaaaaa"
  ],
  "CLASS": "2",
  "EN": "engineering abilities (gain)",
  "FR": "habileté en ingénierie (acquérir)",
  "IEML": "O:.-l.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("5664ea064cb331bd52934176")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "baaaaaaaaeeabgaaaaaaaaaaaaa"
  ],
  "CLASS": "2",
  "EN": "symbolic systems (master)",
  "FR": "systèmes symboliques (maîtriser les)",
  "IEML": "U:.-s.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("5664eab84cb331bd5293417b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "caaaaaaaaeeabgaaaaaaaaaaaaa"
  ],
  "CLASS": "2",
  "EN": "corpus (master the)",
  "FR": "corpus (maîtriser le)",
  "IEML": "A:.-s.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("5664eaef4cb331bd52934180")
});
db.getCollection("terms").insert({
  "IEML": "U:.-b.e.-'",
  "FR": "logique (maîtriser la conversation rationnelle)",
  "EN": "logic (mastering rational conversation)",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "2",
  "TAILLE": "1",
  "CANONICAL": [
    "baaaaaaaaefabgaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("5664eb794cb331bd52934185")
});
db.getCollection("terms").insert({
  "IEML": "A:.-b.e.-'",
  "FR": "analytique (maîtriser la catégorisation)",
  "EN": "analytics (mastering categorization)",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "2",
  "TAILLE": "1",
  "CANONICAL": [
    "caaaaaaaaefabgaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("5664ebe34cb331bd5293418a")
});
db.getCollection("terms").insert({
  "IEML": "A:.-t.e.-'",
  "FR": "topique (maîtriser les lieux communs)",
  "EN": "topic (mastering common place)",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "2",
  "TAILLE": "1",
  "CANONICAL": [
    "caaaaaaaaegabgaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("5664ec914cb331bd5293418f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "baaaaaaaaegabgaaaaaaaaaaaaa"
  ],
  "CLASS": "2",
  "EN": "tropic (mastering logos, pathos and ethos)",
  "FR": "tropique (maîtriser le logos, le pathos et l'éthos)",
  "IEML": "U:.-t.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("5664ecfb4cb331bd52934194")
});
db.getCollection("terms").insert({
  "IEML": "U:.-k.e.-'",
  "FR": "aspiration à l'auto-développement (acquérir)",
  "EN": "aspiration to self-development (gain)",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "2",
  "TAILLE": "1",
  "CANONICAL": [
    "baaaaaaaafeabgaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("5664ee174cb331bd52934199")
});
db.getCollection("terms").insert({
  "IEML": "A:.-k.e.-'",
  "FR": "autonomie personnelle (acquérir)",
  "EN": "personal autonomy (gain)",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "2",
  "TAILLE": "1",
  "CANONICAL": [
    "caaaaaaaafeabgaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("566a0f84e255c1e5da60ddd5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "baaaaaaaaffabgaaaaaaaaaaaaa"
  ],
  "CLASS": "2",
  "EN": "mastering social conventions",
  "FR": "maîtriser les conventions sociales",
  "IEML": "U:.-m.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("566b598b3b7897b48ba5235f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "caaaaaaaaffabgaaaaaaaaaaaaa"
  ],
  "CLASS": "2",
  "EN": "respect for the interlocutor (gain)",
  "FR": "respect de l'interlocuteur (acquérir)",
  "IEML": "A:.-m.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("566b59fe3b7897b48ba52364")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "baaaaaaaafgabgaaaaaaaaaaaaa"
  ],
  "CLASS": "2",
  "EN": "vision (gain)",
  "FR": "vision (acquérir)",
  "IEML": "U:.-n.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("566b5a3d3b7897b48ba52369")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "caaaaaaaafgabgaaaaaaaaaaaaa"
  ],
  "CLASS": "2",
  "EN": "inspire (gain the ability to)",
  "FR": "inspirer (acquérir la capacité d')",
  "IEML": "A:.-n.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("566b5a8f3b7897b48ba5236e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "baaaaaaaaggabgaaaaaaaaaaaaa"
  ],
  "CLASS": "2",
  "EN": "master the networks",
  "FR": "maîtriser les réseaux",
  "IEML": "U:.-l.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("566b5aef3b7897b48ba52373")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "caaaaaaaaggabgaaaaaaaaaaaaa"
  ],
  "CLASS": "2",
  "EN": "mastering the engines",
  "FR": "maîtriser les moteurs",
  "IEML": "A:.-l.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("566b5b393b7897b48ba52378")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "baaaaaaaagfabgaaaaaaaaaaaaa"
  ],
  "CLASS": "2",
  "EN": "master the tools",
  "FR": "maîtriser les outils",
  "IEML": "U:.-f.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("566b5bff3b7897b48ba5237d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "caaaaaaaagfabgaaaaaaaaaaaaa"
  ],
  "CLASS": "2",
  "EN": "master the transformations",
  "FR": "maîtriser les transformations",
  "IEML": "A:.-f.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("566b5c2e3b7897b48ba52382")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "baaaaaaaageabgaaaaaaaaaaaaa"
  ],
  "CLASS": "2",
  "EN": "improve sensorial abilities",
  "FR": "perfectionner les habiletés sensibles",
  "IEML": "U:.-d.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("566b5c903b7897b48ba52387")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "caaaaaaaageabgaaaaaaaaaaaaa"
  ],
  "CLASS": "2",
  "EN": "improve motor abilities",
  "FR": "perfectionner les capacités motrices",
  "IEML": "A:.-d.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("566b5cbe3b7897b48ba5238c")
});
db.getCollection("terms").insert({
  "IEML": "U:O:.T:.-",
  "FR": "manipuler et afficher un mouvement",
  "EN": "manipulate and display a movement",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "bdagaaaaa"
  ],
  "_id": ObjectId("566b6aca3b7897b48ba52391")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cdagaaaaa"
  ],
  "CLASS": "2",
  "EN": "recognize and stop a movement",
  "FR": "reconnaître et stopper un mouvement",
  "IEML": "A:O:.T:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("566b6b303b7897b48ba52396")
});
db.getCollection("terms").insert({
  "IEML": "O:U:.T:.-",
  "FR": "provoquer et reconnaître un mouvement",
  "EN": "provoke and recognize a movement",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dbagaaaaa"
  ],
  "_id": ObjectId("566b6b793b7897b48ba5239b")
});
db.getCollection("terms").insert({
  "IEML": "O:A:.T:.-",
  "FR": "afficher et stopper un mouvement",
  "EN": "display and stop a movement",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dcagaaaaa"
  ],
  "_id": ObjectId("566b6bc23b7897b48ba523a0")
});
db.getCollection("terms").insert({
  "IEML": "O:A:.y.-",
  "FR": "maîtriser et reconstruire les savoirs",
  "EN": "master and rebuild the knowledge",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dcabeaaaa"
  ],
  "_id": ObjectId("566b6ca33b7897b48ba523a5")
});
db.getCollection("terms").insert({
  "IEML": "O:U:.y.-",
  "FR": "s'orienter dans les savoirs et les questionner",
  "EN": "navigate the knowledge and question it",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dbabeaaaa"
  ],
  "_id": ObjectId("566b6d1c3b7897b48ba523aa")
});
db.getCollection("terms").insert({
  "IEML": "U:O:.y.-",
  "FR": "s'orienter dans les savoirs et les maîtriser",
  "EN": "navigate and master the knowledge",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "bdabeaaaa"
  ],
  "_id": ObjectId("566b6d543b7897b48ba523af")
});
db.getCollection("terms").insert({
  "IEML": "A:O:.y.-",
  "FR": "questionner et reconstruire les savoirs",
  "EN": "question and rebuild the knowledge",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "cdabeaaaa"
  ],
  "_id": ObjectId("566b6d793b7897b48ba523b4")
});
db.getCollection("terms").insert({
  "IEML": "wo.U:M:.-",
  "FR": "identifier les points virtuels",
  "EN": "identify virtual points",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "bbabhaaaa"
  ],
  "_id": ObjectId("566b6e183b7897b48ba523b9")
});
db.getCollection("terms").insert({
  "IEML": "wo.A:M:.-",
  "FR": "identifier les points actuels",
  "EN": "identitify actual points",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "bbachaaaa"
  ],
  "_id": ObjectId("566b6e423b7897b48ba523be")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bbadeaaaa"
  ],
  "CLASS": "2",
  "EN": "identify key-points according to sign",
  "FR": "identifier les points clés selon le signe",
  "IEML": "wo.O:S:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("566b6e8d3b7897b48ba523c3")
});
db.getCollection("terms").insert({
  "IEML": "wo.O:B:.-",
  "FR": "identifier les points-clés selon l'être",
  "EN": "identify key-points according to being",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "bbadfaaaa"
  ],
  "_id": ObjectId("566b6eda3b7897b48ba523c8")
});
db.getCollection("terms").insert({
  "IEML": "wo.O:T:.-",
  "FR": "identifier les points-clés selon la chose",
  "EN": "identify key-points according to thing",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "bbadgaaaa"
  ],
  "_id": ObjectId("566b6f033b7897b48ba523cd")
});
db.getCollection("terms").insert({
  "IEML": "U:O:.o.-",
  "FR": "établir des principes et s'y tenir",
  "EN": "establish principles and stick to them",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "bdabfaaaa"
  ],
  "_id": ObjectId("566c67133b7897b48ba523d2")
});
db.getCollection("terms").insert({
  "IEML": "A:O:.o.-",
  "FR": "se remettre en question et renouveler les objectifs",
  "EN": "question oneself and renew objectives",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "cdabfaaaa"
  ],
  "_id": ObjectId("566c67bd3b7897b48ba523d7")
});
db.getCollection("terms").insert({
  "IEML": "O:U:.o.-",
  "FR": "établir des principes et se remettre en question",
  "EN": "establish principles and question oneself",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dbabfaaaa"
  ],
  "_id": ObjectId("566c680f3b7897b48ba523dc")
});
db.getCollection("terms").insert({
  "IEML": "O:A:.o.-",
  "FR": "s'en tenir aux principes et renouveler les objectifs",
  "EN": "stick to principles and renew objectives",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dcabfaaaa"
  ],
  "_id": ObjectId("566c686a3b7897b48ba523e1")
});
db.getCollection("terms").insert({
  "IEML": "U:O:.e.-",
  "FR": "identifier et maîtriser les compétences",
  "EN": "identify and master competencies",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "bdabgaaaa"
  ],
  "_id": ObjectId("566c68a73b7897b48ba523e6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cdabgaaaa"
  ],
  "CLASS": "2",
  "EN": "assess and renew the competencies",
  "FR": "évaluer et renouveler les compétences",
  "IEML": "A:O:.e.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("566c68c93b7897b48ba523eb")
});
db.getCollection("terms").insert({
  "IEML": "O:U:.e.-",
  "FR": "identifier et évaluer les compétences",
  "EN": "identity and assess the competencies",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dbabgaaaa"
  ],
  "_id": ObjectId("566c691d3b7897b48ba523f0")
});
db.getCollection("terms").insert({
  "IEML": "O:A:.e.-",
  "FR": "maîtriser et renouveler les compétences",
  "EN": "master and renew the competencies",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dcabgaaaa"
  ],
  "_id": ObjectId("566c693d3b7897b48ba523f5")
});
db.getCollection("terms").insert({
  "IEML": "U:O:.u.-",
  "FR": "suivre la conversation et trouver l'information",
  "EN": "follow the conversation and find the information",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "bdaceaaaa"
  ],
  "_id": ObjectId("566c69ac3b7897b48ba523fa")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cdaceaaaa"
  ],
  "CLASS": "2",
  "EN": "navigate the communication channels and update one's documentation",
  "FR": "s'orienter dans les canaux de communication et mettre à jour sa documentation",
  "IEML": "A:O:.u.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("566c6a163b7897b48ba523ff")
});
db.getCollection("terms").insert({
  "IEML": "O:U:.u.-",
  "FR": "suivre la conversation et s'orienter dans les canaux de communication",
  "EN": "follow the conversation and navigate the communication channels",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dbaceaaaa"
  ],
  "_id": ObjectId("566c6add3b7897b48ba52404")
});
db.getCollection("terms").insert({
  "IEML": "O:A:.u.-",
  "FR": "trouver l'information et mettre à jour sa documentation",
  "EN": "find the information and update one's documentation",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dcaceaaaa"
  ],
  "_id": ObjectId("566c6b123b7897b48ba52409")
});
db.getCollection("terms").insert({
  "IEML": "U:O:.a.-",
  "FR": "trouver sa place et cultiver son caractère",
  "EN": "find one's place and cultivate one's character",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "bdacfaaaa"
  ],
  "_id": ObjectId("566c6c563b7897b48ba5240e")
});
db.getCollection("terms").insert({
  "IEML": "A:O:.a.-",
  "FR": "discerner les caractères et renouveler ses engagements",
  "EN": "discern the characters and renew one's commitments",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "cdacfaaaa"
  ],
  "_id": ObjectId("566c6c863b7897b48ba52413")
});
db.getCollection("terms").insert({
  "IEML": "O:U:.a.-",
  "FR": "trouver sa place et discerner les charactères",
  "EN": "find one's place and discern the characters",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dbacfaaaa"
  ],
  "_id": ObjectId("566c6cae3b7897b48ba52418")
});
db.getCollection("terms").insert({
  "IEML": "O:A:.a.-",
  "FR": "cultiver son caractère et renouveler ses engagements",
  "EN": "cultivate one's character and renew one's commitments",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dcacfaaaa"
  ],
  "_id": ObjectId("566c6cdf3b7897b48ba5241d")
});
db.getCollection("terms").insert({
  "IEML": "U:O:.i.-",
  "FR": "choisir et utiliser l'équipement",
  "EN": "choose and use the equipment",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "bdacgaaaa"
  ],
  "_id": ObjectId("566c6d233b7897b48ba52422")
});
db.getCollection("terms").insert({
  "IEML": "A:O:.i.-",
  "FR": "tester et renouveler l'équipement",
  "EN": "test and renew the equipment",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "cdacgaaaa"
  ],
  "_id": ObjectId("566c6d423b7897b48ba52427")
});
db.getCollection("terms").insert({
  "IEML": "O:U:.i.-",
  "FR": "choisir et tester l'équipement",
  "EN": "choose and test the equipment",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dbacgaaaa"
  ],
  "_id": ObjectId("566c6d743b7897b48ba5242c")
});
db.getCollection("terms").insert({
  "IEML": "wa.U:M:.-",
  "FR": "maîtriser l'activité virtuelle",
  "EN": "master the virtual activity",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "bcabhaaaa"
  ],
  "_id": ObjectId("566c6e9e3b7897b48ba52431")
});
db.getCollection("terms").insert({
  "IEML": "wa.A:M:.-",
  "FR": "maîtriser l'activité actuelle",
  "EN": "master the actual activity",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "bcachaaaa"
  ],
  "_id": ObjectId("566c6ebe3b7897b48ba52436")
});
db.getCollection("terms").insert({
  "IEML": "wa.O:S:.-",
  "FR": "maîtriser l'activité selon le signe",
  "EN": "master the activity according to the sign",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "bcadeaaaa"
  ],
  "_id": ObjectId("566c6ee33b7897b48ba5243b")
});
db.getCollection("terms").insert({
  "IEML": "wa.O:B:.-",
  "FR": "maîtriser l'activité selon l'être",
  "EN": "master the activity according to the being",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "bcadfaaaa"
  ],
  "_id": ObjectId("566c6f2c3b7897b48ba52440")
});
db.getCollection("terms").insert({
  "IEML": "wa.O:T:.-",
  "FR": "maîtriser l'activité selon la chose",
  "EN": "master the activity according to the thing",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "bcadgaaaa"
  ],
  "_id": ObjectId("566c6fe33b7897b48ba52445")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cbabhaaaa"
  ],
  "CLASS": "2",
  "EN": "exercise critical judgement into the virtual",
  "FR": "exercer son jugement critique dans le virtuel",
  "IEML": "wu.U:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("566c70783b7897b48ba5244a")
});
db.getCollection("terms").insert({
  "IEML": "wu.A:M:.-",
  "FR": "exercer son jugement critique dans l'actuel",
  "EN": "exercise critical judgement into the actual",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "cbachaaaa"
  ],
  "_id": ObjectId("566c70b23b7897b48ba5244f")
});
db.getCollection("terms").insert({
  "IEML": "wu.O:S:.-",
  "FR": "exercer son jugement critique selon le signe",
  "EN": "exercise critical judgement according to the sign",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "cbadeaaaa"
  ],
  "_id": ObjectId("566c70eb3b7897b48ba52454")
});
db.getCollection("terms").insert({
  "IEML": "wu.O:B:.-",
  "FR": "exercer son jugement critique selon l'être",
  "EN": "exercise critical jugement according to the being",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "cbadfaaaa"
  ],
  "_id": ObjectId("566c71153b7897b48ba52459")
});
db.getCollection("terms").insert({
  "IEML": "wu.O:T:.-",
  "FR": "exercer son jugement critique selon la chose",
  "EN": "exercise critical judgement according to the thing",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "cbadgaaaa"
  ],
  "_id": ObjectId("566c715c3b7897b48ba5245e")
});
db.getCollection("terms").insert({
  "IEML": "we.U:M:.-",
  "FR": "renouveler l'activité virtuelle",
  "EN": "renew the virtual activity",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "ccabhaaaa"
  ],
  "_id": ObjectId("566c71eb3b7897b48ba52463")
});
db.getCollection("terms").insert({
  "IEML": "we.A:M:.-",
  "FR": "renouveler l'activité actuelle",
  "EN": "renew the actual activity",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "ccachaaaa"
  ],
  "_id": ObjectId("566c721b3b7897b48ba52468")
});
db.getCollection("terms").insert({
  "IEML": "we.O:S:.-",
  "FR": "renouveler l'activité selon le signe",
  "EN": "renew the activity according to the sign",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "ccadeaaaa"
  ],
  "_id": ObjectId("566c72463b7897b48ba5246d")
});
db.getCollection("terms").insert({
  "IEML": "we.O:B:.-",
  "FR": "renouveler l'activité selon l'être",
  "EN": "renew the activity according to the being",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "ccadfaaaa"
  ],
  "_id": ObjectId("566c72743b7897b48ba52472")
});
db.getCollection("terms").insert({
  "IEML": "we.O:T:.-",
  "FR": "renouveler l'activité selon la chose",
  "EN": "renew the activity according to the thing",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "ccadgaaaa"
  ],
  "_id": ObjectId("566c729c3b7897b48ba52477")
});
db.getCollection("terms").insert({
  "IEML": "wo.M:U:.-",
  "FR": "questionner les cadres virtuels",
  "EN": "questionning virtual frameworks",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "bbahbaaaa"
  ],
  "_id": ObjectId("566c769c3b7897b48ba5247c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bbahcaaaa"
  ],
  "CLASS": "2",
  "EN": "questioning actual frameworks",
  "FR": "questionner les cadres actuels",
  "IEML": "wo.M:A:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("566c76ce3b7897b48ba52481")
});
db.getCollection("terms").insert({
  "IEML": "wo.S:O:.-",
  "FR": "questionner les cadres selon le signe",
  "EN": "question frameworks according to sign",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "bbaedaaaa"
  ],
  "_id": ObjectId("566c77183b7897b48ba52486")
});
db.getCollection("terms").insert({
  "IEML": "wo.B:O:.-",
  "FR": "questionner les cadres de l'activité selon l'être",
  "EN": "question frameworks according to being",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "bbafdaaaa"
  ],
  "_id": ObjectId("566c77473b7897b48ba5248b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bbagdaaaa"
  ],
  "CLASS": "2",
  "EN": "questioning frameworks according to thing",
  "FR": "questionner les cadres de l'activité selon la chose",
  "IEML": "wo.T:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("566c777f3b7897b48ba52490")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bcahbaaaa"
  ],
  "CLASS": "2",
  "EN": "improve the virtual frameworks",
  "FR": "améliorer les cadres virtuels de l'activité",
  "IEML": "wa.M:U:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("566c77fb3b7897b48ba52495")
});
db.getCollection("terms").insert({
  "IEML": "wa.M:A:.-",
  "FR": "améliorer les cadres actuels de l'activité",
  "EN": "improve the actual frameworks",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "bcahcaaaa"
  ],
  "_id": ObjectId("566c78213b7897b48ba5249a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bcaedaaaa"
  ],
  "CLASS": "2",
  "EN": "improve the \"sign\" dimension",
  "FR": "améliorer la dimension \"signe\"",
  "IEML": "wa.S:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("566c78cf3b7897b48ba5249f")
});
db.getCollection("terms").insert({
  "IEML": "wa.B:O:.-",
  "FR": "améliorer la dimension \"être\"",
  "EN": "improve the \"being\" dimension",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "bcafdaaaa"
  ],
  "_id": ObjectId("566c78fa3b7897b48ba524a4")
});
db.getCollection("terms").insert({
  "IEML": "wa.T:O:.-",
  "FR": "améliorer la dimension \"chose\"",
  "EN": "improve the \"thing\" dimension",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "bcagdaaaa"
  ],
  "_id": ObjectId("566c79193b7897b48ba524a9")
});
db.getCollection("terms").insert({
  "IEML": "wu.M:U:.-",
  "FR": "évaluer le virtuel",
  "EN": "assess the virtual",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "cbahbaaaa"
  ],
  "_id": ObjectId("566c798a3b7897b48ba524ae")
});
db.getCollection("terms").insert({
  "IEML": "wu.M:A:.-",
  "FR": "évaluer l'actuel",
  "EN": "assess the actual",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "cbahcaaaa"
  ],
  "_id": ObjectId("566c799f3b7897b48ba524b3")
});
db.getCollection("terms").insert({
  "IEML": "wu.S:O:.-",
  "FR": "évaluer la dimension \"signe\"",
  "EN": "assess the \"sign\" dimension",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "cbaedaaaa"
  ],
  "_id": ObjectId("566c79c93b7897b48ba524b8")
});
db.getCollection("terms").insert({
  "IEML": "wu.B:O:.-",
  "FR": "évaluer la dimension \"être\"",
  "EN": "assess the \"being\" dimension",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "cbafdaaaa"
  ],
  "_id": ObjectId("566c79ed3b7897b48ba524bd")
});
db.getCollection("terms").insert({
  "IEML": "wu.T:O:.-",
  "FR": "évaluer la dimension \"chose\"",
  "EN": "assess the \"thing\" dimension",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "cbagdaaaa"
  ],
  "_id": ObjectId("566c7a4b3b7897b48ba524c2")
});
db.getCollection("terms").insert({
  "IEML": "we.M:U:.-",
  "FR": "unifier le virtuel",
  "EN": "unify the virtual",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "ccahbaaaa"
  ],
  "_id": ObjectId("566c7a963b7897b48ba524c7")
});
db.getCollection("terms").insert({
  "IEML": "we.M:A:.-",
  "FR": "unifier l'actuel",
  "EN": "unify the actual",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "ccahcaaaa"
  ],
  "_id": ObjectId("566c7aaf3b7897b48ba524cc")
});
db.getCollection("terms").insert({
  "IEML": "we.S:O:.-",
  "FR": "unifier la dimension \"signe\"",
  "EN": "unify the \"sign\" dimension",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "ccaedaaaa"
  ],
  "_id": ObjectId("566c7ade3b7897b48ba524d1")
});
db.getCollection("terms").insert({
  "IEML": "we.B:O:.-",
  "FR": "unifier la dimension \"être\"",
  "EN": "unify the \"being\" dimension",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "ccafdaaaa"
  ],
  "_id": ObjectId("566c7b063b7897b48ba524d6")
});
db.getCollection("terms").insert({
  "IEML": "we.T:O:.-",
  "FR": "unifier la dimension \"chose\"",
  "EN": "unify the \"thing\" dimension",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "ccagdaaaa"
  ],
  "_id": ObjectId("566c7b2d3b7897b48ba524db")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cdaebaaaa"
  ],
  "CLASS": "2",
  "EN": "assess and unify the symbolic system",
  "FR": "évaluer et unifier le système symbolique",
  "IEML": "A:O:.j.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("566c7b9b3b7897b48ba524e0")
});
db.getCollection("terms").insert({
  "IEML": "U:O:.j.-",
  "FR": "comparer et perfectionner le système symbolique",
  "EN": "compare and improve the symbolic system",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "bdaebaaaa"
  ],
  "_id": ObjectId("566c7d173b7897b48ba524e5")
});
db.getCollection("terms").insert({
  "IEML": "O:U:.j.-",
  "FR": "comparer et évaluer le système symbolique",
  "EN": "compare and assess the symbolic system",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dbaebaaaa"
  ],
  "_id": ObjectId("566c7d493b7897b48ba524ea")
});
db.getCollection("terms").insert({
  "IEML": "O:A:.j.-",
  "FR": "perfectionner et unifier le système symbolique",
  "EN": "improve and unify the symbolic system",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dcaebaaaa"
  ],
  "_id": ObjectId("566c7d723b7897b48ba524ef")
});
db.getCollection("terms").insert({
  "IEML": "U:O:.h.-",
  "FR": "questionner et approfondir le sens",
  "EN": "question and deepen the meaning",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "bdafbaaaa"
  ],
  "_id": ObjectId("566c7e133b7897b48ba524f4")
});
db.getCollection("terms").insert({
  "IEML": "A:O:.h.-",
  "FR": "évaluer l'interprétation et unifier le sens",
  "EN": "assess the interpretation and unify the meaning",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "cdafbaaaa"
  ],
  "_id": ObjectId("566c7e483b7897b48ba524f9")
});
db.getCollection("terms").insert({
  "IEML": "O:U:.h.-",
  "FR": "questionner le sens et évaluer l'interprétation",
  "EN": "question the meaning and assess the interpretation",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dbafbaaaa"
  ],
  "_id": ObjectId("566c7e783b7897b48ba524fe")
});
db.getCollection("terms").insert({
  "IEML": "O:A:.h.-",
  "FR": "approfondir et unifier le sens",
  "EN": "deepen and unify the meaning",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dcafbaaaa"
  ],
  "_id": ObjectId("566c7e9d3b7897b48ba52503")
});
db.getCollection("terms").insert({
  "IEML": "U:O:.p.-",
  "FR": "redéfinir et atteindre les objectifs",
  "EN": "redefine and meet the objectives",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "bdagbaaaa"
  ],
  "_id": ObjectId("566c7ef53b7897b48ba52508")
});
db.getCollection("terms").insert({
  "IEML": "A:O:.p.-",
  "FR": "unifier et mesurer la distance aux objectifs",
  "EN": "unify and measure the distance to the objectives",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "cdagbaaaa"
  ],
  "_id": ObjectId("566c7f283b7897b48ba5250d")
});
db.getCollection("terms").insert({
  "IEML": "O:U:.p.-",
  "FR": "mesurer la distance aux objectifs et les redéfinir",
  "EN": "measure the distance to the objectives and redefine them",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dbagbaaaa"
  ],
  "_id": ObjectId("566c7f643b7897b48ba52512")
});
db.getCollection("terms").insert({
  "IEML": "O:A:.p.-",
  "FR": "unifier et atteindre les objectifs",
  "EN": "unify and meet the objectives",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dcagbaaaa"
  ],
  "_id": ObjectId("566c7f863b7897b48ba52517")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bdaecaaaa"
  ],
  "CLASS": "2",
  "EN": "compare and improve the communication",
  "FR": "comparer et perfectionner la communication",
  "IEML": "U:O:.g.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("566c803d3b7897b48ba5251c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cdaecaaaa"
  ],
  "CLASS": "2",
  "EN": "assess and unify the communication",
  "FR": "évaluer et unifier la communication",
  "IEML": "A:O:.g.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("566c80633b7897b48ba52521")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dbaecaaaa"
  ],
  "CLASS": "2",
  "EN": "compare and assess the communication",
  "FR": "comparer et évaluer la communication",
  "IEML": "O:U:.g.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("566c80923b7897b48ba52526")
});
db.getCollection("terms").insert({
  "IEML": "O:A:.g.-",
  "FR": "perfectionner et unifier la communication",
  "EN": "improve and unify the communication",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dcaecaaaa"
  ],
  "_id": ObjectId("566c80ff3b7897b48ba5252b")
});
db.getCollection("terms").insert({
  "IEML": "U:O:.c.-",
  "FR": "questionner et renouveler la communauté",
  "EN": "question and renew the community",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "bdafcaaaa"
  ],
  "_id": ObjectId("566c81513b7897b48ba52530")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cdafcaaaa"
  ],
  "CLASS": "2",
  "EN": "assess the community and bring it together",
  "FR": "évaluer et rassembler la communauté",
  "IEML": "A:O:.c.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("566c81743b7897b48ba52535")
});
db.getCollection("terms").insert({
  "IEML": "O:U:.c.-",
  "FR": "questionner et évaluer la communauté",
  "EN": "question and assess the community",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dbafcaaaa"
  ],
  "_id": ObjectId("566c81ac3b7897b48ba5253a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dcafcaaaa"
  ],
  "CLASS": "2",
  "EN": "renew the community and bring it together",
  "FR": "renouveler et rassembler la communauté",
  "IEML": "O:A:.c.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("566c81ca3b7897b48ba5253f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cdagcaaaa"
  ],
  "CLASS": "2",
  "EN": "assess and unify the technology",
  "FR": "évaluer et unifier le système technique",
  "IEML": "A:O:.x.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("566c82c83b7897b48ba52544")
});
db.getCollection("terms").insert({
  "IEML": "U:O:.x.-",
  "FR": "questionner et perfectionner le système technique",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "bdagcaaaa"
  ],
  "_id": ObjectId("566c83233b7897b48ba52549")
});
db.getCollection("terms").insert({
  "IEML": "O:U:.x.-",
  "FR": "questionner et évaluer le système technique",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dbagcaaaa"
  ],
  "_id": ObjectId("566c83693b7897b48ba5254e")
});
db.getCollection("terms").insert({
  "IEML": "O:A:.x.-",
  "FR": "améliorer et unifier le système technique",
  "EN": "improve and unify the technology",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dcagcaaaa"
  ],
  "_id": ObjectId("566c83ac3b7897b48ba52553")
});
db.getCollection("terms").insert({
  "IEML": "U:M:.wo.-",
  "FR": "gagner en puissance créative virtuelle",
  "EN": "gain in virtual creative power",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "bhabbaaaa"
  ],
  "_id": ObjectId("566c9f373b7897b48ba52558")
});
db.getCollection("terms").insert({
  "IEML": "A:M:.wo.-",
  "FR": "gagner en puissance créative actuelle",
  "EN": "gain in actual creative power",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "chabbaaaa"
  ],
  "_id": ObjectId("566c9f643b7897b48ba5255d")
});
db.getCollection("terms").insert({
  "IEML": "O:S:.wo.-",
  "FR": "gagner en puissance créative selon le signe",
  "EN": "gain in creative power according to the sign",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "deabbaaaa"
  ],
  "_id": ObjectId("566c9fa93b7897b48ba52562")
});
db.getCollection("terms").insert({
  "IEML": "O:B:.wo.-",
  "FR": "gagner en puissance créative selon l'être",
  "EN": "gain in creative power according to the being",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dfabbaaaa"
  ],
  "_id": ObjectId("566c9fd33b7897b48ba52567")
});
db.getCollection("terms").insert({
  "IEML": "O:T:.wo.-",
  "FR": "gagner en puissance créative selon la chose",
  "EN": "gain in creative power according to the thing",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dgabbaaaa"
  ],
  "_id": ObjectId("566c9ffb3b7897b48ba5256c")
});
db.getCollection("terms").insert({
  "IEML": "U:M:.wa.-",
  "FR": "gagner en puissance économique virtuelle",
  "EN": "gain in virtual economic power",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "bhabcaaaa"
  ],
  "_id": ObjectId("566ca0a03b7897b48ba52571")
});
db.getCollection("terms").insert({
  "IEML": "A:M:.wa.-",
  "FR": "gagner en puissance économique actuelle",
  "EN": "gain in actual economic power",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "chabcaaaa"
  ],
  "_id": ObjectId("566ca0bc3b7897b48ba52576")
});
db.getCollection("terms").insert({
  "IEML": "O:S:.wa.-",
  "FR": "gagner en puissance économique selon le signe",
  "EN": "gain in economic power according to the sign",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "deabcaaaa"
  ],
  "_id": ObjectId("566ca0f73b7897b48ba5257b")
});
db.getCollection("terms").insert({
  "IEML": "O:B:.wa.-",
  "FR": "gagner en puissance économique selon l'être",
  "EN": "gain in economic power according to the being",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dfabcaaaa"
  ],
  "_id": ObjectId("566ca11d3b7897b48ba52580")
});
db.getCollection("terms").insert({
  "IEML": "O:T:.wa.-",
  "FR": "gagner en puissance économique selon la chose",
  "EN": "gain in economic power according to the thing",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dgabcaaaa"
  ],
  "_id": ObjectId("566ca1473b7897b48ba52585")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bhacbaaaa"
  ],
  "CLASS": "2",
  "EN": "gain in virtual citizen empowerment",
  "FR": "gagner en puissance citoyenne virtuelle",
  "IEML": "U:M:.wu.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("566ca1cd3b7897b48ba5258a")
});
db.getCollection("terms").insert({
  "IEML": "A:M:.wu.-",
  "FR": "gagner en puissance citoyenne actuelle",
  "EN": "gain in actual citizen empowermrnt",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "chacbaaaa"
  ],
  "_id": ObjectId("566ca2293b7897b48ba5258f")
});
db.getCollection("terms").insert({
  "IEML": "O:S:.wu.-",
  "FR": "gagner en puissance citoyenne selon le signe",
  "EN": "gain in citizen empowerment according to the sign",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "deacbaaaa"
  ],
  "_id": ObjectId("566ca2623b7897b48ba52594")
});
db.getCollection("terms").insert({
  "IEML": "O:B:.wu.-",
  "FR": "gagner en puissance citoyenne selon l'être",
  "EN": "gain in citizen empowerment according to being",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dfacbaaaa"
  ],
  "_id": ObjectId("566ca2943b7897b48ba52599")
});
db.getCollection("terms").insert({
  "IEML": "O:T:.wu.-",
  "FR": "gagner en puissance citoyenne selon la chose",
  "EN": "gain in citizen empowerment according to the thing",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dgacbaaaa"
  ],
  "_id": ObjectId("566ca2c63b7897b48ba5259e")
});
db.getCollection("terms").insert({
  "IEML": "U:M:.we.-",
  "FR": "gagner en puissance familiale virtuelle",
  "EN": "gain in virtual family empowerment",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "bhaccaaaa"
  ],
  "_id": ObjectId("566ca43c3b7897b48ba525a3")
});
db.getCollection("terms").insert({
  "IEML": "A:M:.we.-",
  "FR": "gagner en puissance familiale actuelle",
  "EN": "gain in actual family empowerment",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "chaccaaaa"
  ],
  "_id": ObjectId("566ca4803b7897b48ba525a8")
});
db.getCollection("terms").insert({
  "IEML": "O:S:.we.-",
  "FR": "gagner en puissance familiale selon le signe",
  "EN": "gain in family empowerment according to the sign",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "deaccaaaa"
  ],
  "_id": ObjectId("566ca4b53b7897b48ba525ad")
});
db.getCollection("terms").insert({
  "IEML": "O:B:.we.-",
  "FR": "gagner en puissance familiale selon l'être",
  "EN": "gain in family empowerment according to the being",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dfaccaaaa"
  ],
  "_id": ObjectId("566ca4e53b7897b48ba525b2")
});
db.getCollection("terms").insert({
  "IEML": "O:T:.we.-",
  "FR": "gagner en puissance familiale selon la chose",
  "EN": "gain in family empowerment according to the thing",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dgaccaaaa"
  ],
  "_id": ObjectId("566ca5093b7897b48ba525b7")
});
db.getCollection("terms").insert({
  "IEML": "y.O:U:.-",
  "FR": "assumer une identité individuelle",
  "EN": "assume an individual identity",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "beadbaaaa"
  ],
  "_id": ObjectId("566ca7403b7897b48ba525bc")
});
db.getCollection("terms").insert({
  "IEML": "y.O:A:.-",
  "FR": "assumer une identité collective",
  "EN": "assume a collective identity",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "beadcaaaa"
  ],
  "_id": ObjectId("566ca75d3b7897b48ba525c1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "beacdaaaa"
  ],
  "CLASS": "2",
  "EN": "assume one's roots",
  "FR": "assumer ses racines",
  "IEML": "y.A:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("566ca7b93b7897b48ba525c6")
});
db.getCollection("terms").insert({
  "IEML": "y.U:O:.-",
  "FR": "assumer son chemin",
  "EN": "assume one's path",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "beabdaaaa"
  ],
  "_id": ObjectId("566ca86c3b7897b48ba525cb")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bfadbaaaa"
  ],
  "CLASS": "2",
  "EN": "rule the relations between actors",
  "FR": "régler les relations entre acteurs",
  "IEML": "o.O:U:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("566ca8fb3b7897b48ba525d0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bfadcaaaa"
  ],
  "CLASS": "2",
  "EN": "rule the relations between roles",
  "FR": "régler les relations entre rôles",
  "IEML": "o.O:A:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("566ca93a3b7897b48ba525d5")
});
db.getCollection("terms").insert({
  "IEML": "o.A:O:.-",
  "FR": "régler les relations interpersonnelles",
  "EN": "rule interpersonal relations",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "bfacdaaaa"
  ],
  "_id": ObjectId("566caa183b7897b48ba525da")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bfabdaaaa"
  ],
  "CLASS": "2",
  "EN": "rule mixed relations",
  "FR": "régler les relations mixtes",
  "IEML": "o.U:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("566caa883b7897b48ba525df")
});
db.getCollection("terms").insert({
  "IEML": "e.U:O:.-",
  "FR": "contrôle economique",
  "EN": "economic control",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "bgabdaaaa"
  ],
  "_id": ObjectId("566cabd43b7897b48ba525e4")
});
db.getCollection("terms").insert({
  "IEML": "e.A:O:.-",
  "FR": "contrôle physique",
  "EN": "physical control",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "bgacdaaaa"
  ],
  "_id": ObjectId("566cac203b7897b48ba525e9")
});
db.getCollection("terms").insert({
  "IEML": "e.O:A:.-",
  "FR": "contrôle direct",
  "EN": "direct control",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "bgadcaaaa"
  ],
  "_id": ObjectId("566cac8b3b7897b48ba525ee")
});
db.getCollection("terms").insert({
  "IEML": "e.O:U:.-",
  "FR": "contrôle indirect",
  "EN": "indirect control",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "bgadbaaaa"
  ],
  "_id": ObjectId("566caca13b7897b48ba525f3")
});
db.getCollection("terms").insert({
  "IEML": "u.A:O:.-",
  "FR": "s'exposer",
  "EN": "expose oneself",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "ceacdaaaa"
  ],
  "_id": ObjectId("566cad653b7897b48ba525f8")
});
db.getCollection("terms").insert({
  "IEML": "u.U:O:.-",
  "FR": "exposer quelque chose",
  "EN": "expose something",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "ceabdaaaa"
  ],
  "_id": ObjectId("566cad913b7897b48ba525fd")
});
db.getCollection("terms").insert({
  "IEML": "u.O:U:.-",
  "FR": "exposer le virtuel",
  "EN": "expose the virtual",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "ceadbaaaa"
  ],
  "_id": ObjectId("566cade83b7897b48ba52602")
});
db.getCollection("terms").insert({
  "IEML": "u.O:A:.-",
  "FR": "exposer l'actuel",
  "EN": "expose the actual",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "ceadcaaaa"
  ],
  "_id": ObjectId("566cadfc3b7897b48ba52607")
});
db.getCollection("terms").insert({
  "IEML": "a.A:O:.-",
  "FR": "créer la société",
  "EN": "create the society",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "cfacdaaaa"
  ],
  "_id": ObjectId("566cae5b3b7897b48ba5260c")
});
db.getCollection("terms").insert({
  "IEML": "a.U:O:.-",
  "FR": "créer de la richesse",
  "EN": "create some wealth",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "cfabdaaaa"
  ],
  "_id": ObjectId("566cae8c3b7897b48ba52611")
});
db.getCollection("terms").insert({
  "IEML": "a.O:U:.-",
  "FR": "créer virtuellement",
  "EN": "create virtually",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "cfadbaaaa"
  ],
  "_id": ObjectId("566caef93b7897b48ba52616")
});
db.getCollection("terms").insert({
  "IEML": "a.O:A:.-",
  "FR": "créer actuellement",
  "EN": "create actually",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "cfadcaaaa"
  ],
  "_id": ObjectId("566caf183b7897b48ba5261b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cgacdaaaa"
  ],
  "CLASS": "2",
  "EN": "equip a actual community",
  "FR": "équiper une communauté actuelle",
  "IEML": "i.A:O:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("566caf983b7897b48ba52620")
});
db.getCollection("terms").insert({
  "IEML": "i.U:O:.-",
  "FR": "équiper une communauté virtuelle",
  "EN": "equip a virtual community",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "cgabdaaaa"
  ],
  "_id": ObjectId("566cafc83b7897b48ba52625")
});
db.getCollection("terms").insert({
  "IEML": "i.O:U:.-",
  "FR": "équiper la vie culturelle",
  "EN": "equip cultural life",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "cgadbaaaa"
  ],
  "_id": ObjectId("566cb0b73b7897b48ba5262a")
});
db.getCollection("terms").insert({
  "IEML": "i.O:A:.-",
  "FR": "équiper la reproduction concrète",
  "EN": "equip concrete reproduction",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "cgadcaaaa"
  ],
  "_id": ObjectId("566cb10e3b7897b48ba5262f")
});
db.getCollection("terms").insert({
  "IEML": "U:M:.B:.-",
  "FR": "bouger-couler des éléments",
  "EN": "move-leak elements",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "bhafaaaaa"
  ],
  "_id": ObjectId("566dbe3b3b7897b48ba52634")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "deafaaaaa"
  ],
  "CLASS": "2",
  "EN": "move-leak by sliping",
  "FR": "bouger-couler en glissant",
  "IEML": "O:S:.B:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("566dbeba3b7897b48ba52639")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dfafaaaaa"
  ],
  "CLASS": "2",
  "EN": "move-leak by containing",
  "FR": "bouger-couler en contenant",
  "IEML": "O:B:.B:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("566dbeed3b7897b48ba5263e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "chafaaaaa"
  ],
  "CLASS": "2",
  "EN": "move-leak oneself",
  "FR": "bouger-couler soi-même",
  "IEML": "A:M:.B:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("566dbf4a3b7897b48ba52643")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dgafaaaaa"
  ],
  "CLASS": "2",
  "EN": "move-leak by displacing",
  "FR": "bouger-couler en déplaçant",
  "IEML": "O:T:.B:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("566dbf873b7897b48ba52648")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bhaeaaaaa"
  ],
  "CLASS": "2",
  "EN": "move-blow elements",
  "FR": "bouger-souffler des éléments",
  "IEML": "U:M:.S:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("566dc0e03b7897b48ba5264d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "chaeaaaaa"
  ],
  "CLASS": "2",
  "EN": "move-blow oneself",
  "FR": "bouger-souffler soi-même",
  "IEML": "A:M:.S:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("566dc12b3b7897b48ba52652")
});
db.getCollection("terms").insert({
  "IEML": "O:B:.S:.-",
  "FR": "bouger-souffler en contenant",
  "EN": "move-blow by containing",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dfaeaaaaa"
  ],
  "_id": ObjectId("566dc1993b7897b48ba52657")
});
db.getCollection("terms").insert({
  "IEML": "O:S:.S:.-",
  "FR": "bouger-souffler en glissant",
  "EN": "move-blow by sliping",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "deaeaaaaa"
  ],
  "_id": ObjectId("566dc1d43b7897b48ba5265c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dgaeaaaaa"
  ],
  "CLASS": "2",
  "EN": "move-blow by displacing",
  "FR": "bouger-souffler en déplaçant",
  "IEML": "O:T:.S:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("566dc2143b7897b48ba52661")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "chagaaaaa"
  ],
  "CLASS": "2",
  "EN": "move-stick oneself",
  "FR": "bouger-coller soi-même",
  "IEML": "A:M:.T:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("566dc30c3b7897b48ba52666")
});
db.getCollection("terms").insert({
  "IEML": "U:M:.T:.-",
  "FR": "bouger-coller des éléments",
  "EN": "move-stick elements",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "bhagaaaaa"
  ],
  "_id": ObjectId("566dc32d3b7897b48ba5266b")
});
db.getCollection("terms").insert({
  "IEML": "O:S:.T:.-",
  "FR": "bouger-coller en glissant",
  "EN": "move-stick by sliping",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "deagaaaaa"
  ],
  "_id": ObjectId("566dc4763b7897b48ba52670")
});
db.getCollection("terms").insert({
  "IEML": "O:B:.T:.-",
  "FR": "bouger-coller en contenant",
  "EN": "move-stick by containing",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dfagaaaaa"
  ],
  "_id": ObjectId("566dc49a3b7897b48ba52675")
});
db.getCollection("terms").insert({
  "IEML": "O:T:.T:.-",
  "FR": "bouger-coller en déplaçant",
  "EN": "move-stick by displacing",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dgagaaaaa"
  ],
  "_id": ObjectId("566dc4b83b7897b48ba5267a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "chabaaaaa"
  ],
  "CLASS": "2",
  "EN": "move oneself centripetally",
  "FR": "bouger soi-même de façon centripète",
  "IEML": "A:M:.U:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("566dc5143b7897b48ba5267f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bhabaaaaa"
  ],
  "CLASS": "2",
  "EN": "move elements centripetally",
  "FR": "bouger des éléments de façon centripète",
  "IEML": "U:M:.U:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("566dc5383b7897b48ba52684")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "deabaaaaa"
  ],
  "CLASS": "2",
  "EN": "move-slip in",
  "FR": "bouger-glisser dedans",
  "IEML": "O:S:.U:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("566dc57b3b7897b48ba52689")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dfabaaaaa"
  ],
  "CLASS": "2",
  "EN": "move-contain in",
  "FR": "bouger-contenir dedans",
  "IEML": "O:B:.U:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("566dc5a43b7897b48ba5268e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dgabaaaaa"
  ],
  "CLASS": "2",
  "EN": "move-displace in",
  "FR": "bouger-déplacer dedans",
  "IEML": "O:T:.U:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("566dc5ce3b7897b48ba52693")
});
db.getCollection("terms").insert({
  "IEML": "A:M:.A:.-",
  "FR": "bouger soi-même de façon centrifuge",
  "EN": "move oneself centrifugally",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "chacaaaaa"
  ],
  "_id": ObjectId("566dc6e53b7897b48ba52698")
});
db.getCollection("terms").insert({
  "IEML": "U:M:.A:.-",
  "FR": "bouger des éléments de manière centrifuge",
  "EN": "move elements centrifugally",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "bhacaaaaa"
  ],
  "_id": ObjectId("566dc7073b7897b48ba5269d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "deacaaaaa"
  ],
  "CLASS": "2",
  "EN": "move-slip out",
  "FR": "bouger-glisser dehors",
  "IEML": "O:S:.A:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("566dc7453b7897b48ba526a2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dfacaaaaa"
  ],
  "CLASS": "2",
  "EN": "move-contain out",
  "FR": "bouger-contenir dehors",
  "IEML": "O:B:.A:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("566dc7ab3b7897b48ba526a7")
});
db.getCollection("terms").insert({
  "IEML": "O:T:.A:.-",
  "FR": "bouger déplacer dehors",
  "EN": "move-displace out",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dgacaaaaa"
  ],
  "_id": ObjectId("566dc8013b7897b48ba526ac")
});
db.getCollection("terms").insert({
  "IEML": "y.O:S:.-",
  "FR": "performer à partir du savoir selon le sign",
  "EN": "perform from knowledge according to sign",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "beadeaaaa"
  ],
  "_id": ObjectId("566dcd453b7897b48ba526b1")
});
db.getCollection("terms").insert({
  "IEML": "y.O:B:.-",
  "FR": "performer à partir du savoir selon le signe",
  "EN": "perform from knowledge according to being",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "beadfaaaa"
  ],
  "_id": ObjectId("566dcd743b7897b48ba526b6")
});
db.getCollection("terms").insert({
  "IEML": "y.O:T:.-",
  "FR": "performer à partir du savoir selon la chose",
  "EN": "perform form knowledge according to thing",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "beadgaaaa"
  ],
  "_id": ObjectId("566dcd9c3b7897b48ba526bb")
});
db.getCollection("terms").insert({
  "IEML": "y.U:M:.-",
  "FR": "performer virtuellement à partir du savoir",
  "EN": "perform virtually from knowledge",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "beabhaaaa"
  ],
  "_id": ObjectId("566dcdd53b7897b48ba526c0")
});
db.getCollection("terms").insert({
  "IEML": "y.A:M:.-",
  "FR": "performer actuellement à partir du savoir",
  "EN": "perform actually from knowledge",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "beachaaaa"
  ],
  "_id": ObjectId("566dcdfa3b7897b48ba526c5")
});
db.getCollection("terms").insert({
  "IEML": "o.U:M:.-",
  "FR": "performer virtuellement à partir de la volonté",
  "EN": "perform virtually from the will",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "bfabhaaaa"
  ],
  "_id": ObjectId("566dcf463b7897b48ba526ca")
});
db.getCollection("terms").insert({
  "IEML": "o.A:M:.-",
  "FR": "performer actuellement à partir de la volonté",
  "EN": "perform actually from the will",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "bfachaaaa"
  ],
  "_id": ObjectId("566dcf683b7897b48ba526cf")
});
db.getCollection("terms").insert({
  "IEML": "o.O:S:.-",
  "FR": "performer à partir de la volonté selon le signe",
  "EN": "perform from the will according to sign",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "bfadeaaaa"
  ],
  "_id": ObjectId("566dcf9d3b7897b48ba526d4")
});
db.getCollection("terms").insert({
  "IEML": "o.O:B:.-",
  "FR": "performer à partir de la volonté selon l'être",
  "EN": "perform from the will according to being",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "bfadfaaaa"
  ],
  "_id": ObjectId("566dcfd03b7897b48ba526d9")
});
db.getCollection("terms").insert({
  "IEML": "o.O:T:.-",
  "FR": "performer à partir de la volonté selon la chose",
  "EN": "perform from the will according to thing",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "bfadgaaaa"
  ],
  "_id": ObjectId("566dcff83b7897b48ba526de")
});
db.getCollection("terms").insert({
  "IEML": "e.A:M:.-",
  "FR": "performer à partir de la compétence actuellement",
  "EN": "perform actually from the competency",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "bgachaaaa"
  ],
  "_id": ObjectId("566dd9633b7897b48ba526e3")
});
db.getCollection("terms").insert({
  "IEML": "e.U:M:.-",
  "FR": "performer virtuellement à partir de la compétence",
  "EN": "perform virtually from the competency",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "bgabhaaaa"
  ],
  "_id": ObjectId("566dd9973b7897b48ba526e8")
});
db.getCollection("terms").insert({
  "IEML": "e.O:S:.-",
  "FR": "performer à partir de la compétence selon le signe",
  "EN": "perform from competency according to sign",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "bgadeaaaa"
  ],
  "_id": ObjectId("566dd9cb3b7897b48ba526ed")
});
db.getCollection("terms").insert({
  "IEML": "e.O:B:.-",
  "FR": "performer à partir de la compétence selon l'être",
  "EN": "perform from the competency according to being",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "bgadfaaaa"
  ],
  "_id": ObjectId("566dd9f63b7897b48ba526f2")
});
db.getCollection("terms").insert({
  "IEML": "e.O:T:.-",
  "FR": "performer à partir de la compétence selon la chose",
  "EN": "perform from the competency according to thing",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "bgadgaaaa"
  ],
  "_id": ObjectId("566dda2e3b7897b48ba526f7")
});
db.getCollection("terms").insert({
  "IEML": "u.U:M:.-",
  "FR": "performer virtuellement à partir de l'expression",
  "EN": "perform virtually from the expression",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "ceabhaaaa"
  ],
  "_id": ObjectId("566dda8d3b7897b48ba526fc")
});
db.getCollection("terms").insert({
  "IEML": "u.A:M:.-",
  "FR": "performer actuellement à partir de l'expression",
  "EN": "perform actually from the expression",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "ceachaaaa"
  ],
  "_id": ObjectId("566ddaac3b7897b48ba52701")
});
db.getCollection("terms").insert({
  "IEML": "u.O:S:.-",
  "FR": "performer à partir de l'expression selon le signe",
  "EN": "perform from the expression according to sign",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "ceadeaaaa"
  ],
  "_id": ObjectId("566ddae23b7897b48ba52706")
});
db.getCollection("terms").insert({
  "IEML": "u.O:B:.-",
  "FR": "performer à partir de l'expression selon l'être",
  "EN": "perform from the expression according to being",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "ceadfaaaa"
  ],
  "_id": ObjectId("566ddb063b7897b48ba5270b")
});
db.getCollection("terms").insert({
  "IEML": "u.O:T:.-",
  "FR": "performer à partir de l'expression selon la chose",
  "EN": "perform from the expression according to thing",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "ceadgaaaa"
  ],
  "_id": ObjectId("566ddb253b7897b48ba52710")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfabhaaaa"
  ],
  "CLASS": "2",
  "EN": "perform virtually on a social basis",
  "FR": "performer virtuellement sur une base sociale",
  "IEML": "a.U:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("566ddb5e3b7897b48ba52715")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfachaaaa"
  ],
  "CLASS": "2",
  "EN": "perform actually on a social basis",
  "FR": "performer actuellement sur une base sociale",
  "IEML": "a.A:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("566ddc063b7897b48ba5271a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfadeaaaa"
  ],
  "CLASS": "2",
  "EN": "perform on a social basis according to sign",
  "FR": "performer sur une base sociale selon le signe",
  "IEML": "a.O:S:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("566ddc423b7897b48ba5271f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfadfaaaa"
  ],
  "CLASS": "2",
  "EN": "perform on a social basis according to being",
  "FR": "performer sur une base sociale selon l'être",
  "IEML": "a.O:B:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("566ddc683b7897b48ba52724")
});
db.getCollection("terms").insert({
  "IEML": "a.O:T:.-",
  "FR": "performer sur une base sociale selon la chose",
  "EN": "perform on a social basis according to thing",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "cfadgaaaa"
  ],
  "_id": ObjectId("566ddc8d3b7897b48ba52729")
});
db.getCollection("terms").insert({
  "IEML": "i.U:M:.-",
  "FR": "performer virtuellement sur une base concrète",
  "EN": "perform virtually on a concrete basis",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "cgabhaaaa"
  ],
  "_id": ObjectId("566ddd653b7897b48ba5272e")
});
db.getCollection("terms").insert({
  "IEML": "i.A:M:.-",
  "FR": "performer actuellement sur une base concrète",
  "EN": "perform actually on a concrete basis",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "cgachaaaa"
  ],
  "_id": ObjectId("566ddd933b7897b48ba52733")
});
db.getCollection("terms").insert({
  "IEML": "i.O:S:.-",
  "FR": "performer sur une base concrète selon le signe",
  "EN": "perform on a concrete basis according to sign",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "cgadeaaaa"
  ],
  "_id": ObjectId("566dddba3b7897b48ba52738")
});
db.getCollection("terms").insert({
  "IEML": "i.O:B:.-",
  "FR": "performer sur une base concrète selon l'être",
  "EN": "perform on a concrete basis according to being",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "cgadfaaaa"
  ],
  "_id": ObjectId("566ddde13b7897b48ba5273d")
});
db.getCollection("terms").insert({
  "IEML": "i.O:T:.-",
  "FR": "performer sur une base concrète selon la chose",
  "EN": "perform on a concrete basis according to thing",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "cgadgaaaa"
  ],
  "_id": ObjectId("566dde103b7897b48ba52742")
});
db.getCollection("terms").insert({
  "IEML": "U:M:.y.-",
  "FR": "performer virtuellement dans le savoir",
  "EN": "perform virtually into knowledge",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "bhabeaaaa"
  ],
  "_id": ObjectId("566dde713b7897b48ba52747")
});
db.getCollection("terms").insert({
  "IEML": "A:M:.y.-",
  "FR": "performer actuellement dans le savoir",
  "EN": "perform actually into knowledge",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "chabeaaaa"
  ],
  "_id": ObjectId("566dde8f3b7897b48ba5274c")
});
db.getCollection("terms").insert({
  "IEML": "O:S:.y.-",
  "FR": "performer dans le savoir selon le signe",
  "EN": "perform into knowledge according to sign",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "deabeaaaa"
  ],
  "_id": ObjectId("566ddeb83b7897b48ba52751")
});
db.getCollection("terms").insert({
  "IEML": "O:B:.y.-",
  "FR": "performer dans le savoir selon l'être",
  "EN": "perform into knowledge according to being",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dfabeaaaa"
  ],
  "_id": ObjectId("566dded93b7897b48ba52756")
});
db.getCollection("terms").insert({
  "IEML": "O:T:.y.-",
  "FR": "performer dans le savoir selon la chose",
  "EN": "perform into knowledge according to thing",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dgabeaaaa"
  ],
  "_id": ObjectId("566ddef93b7897b48ba5275b")
});
db.getCollection("terms").insert({
  "IEML": "U:M:.o.-",
  "FR": "performer dans la volonté virtuellement",
  "EN": "perform virtually into will",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "bhabfaaaa"
  ],
  "_id": ObjectId("566de9353b7897b48ba52760")
});
db.getCollection("terms").insert({
  "IEML": "A:M:.o.-",
  "FR": "performer dans la volonté actuellement",
  "EN": "perform actually into will",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "chabfaaaa"
  ],
  "_id": ObjectId("566de9613b7897b48ba52765")
});
db.getCollection("terms").insert({
  "IEML": "O:S:.o.-",
  "FR": "performer dans la volonté selon le signe",
  "EN": "perform into will according to sign",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "deabfaaaa"
  ],
  "_id": ObjectId("566de9953b7897b48ba5276a")
});
db.getCollection("terms").insert({
  "IEML": "O:B:.o.-",
  "FR": "performer dans la volonté selon l'être",
  "EN": "perform into will according to being",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dfabfaaaa"
  ],
  "_id": ObjectId("566de9c13b7897b48ba5276f")
});
db.getCollection("terms").insert({
  "IEML": "O:T:.o.-",
  "FR": "performer dans la volonté selon la chose",
  "EN": "perform into will according to thing",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dgabfaaaa"
  ],
  "_id": ObjectId("566de9e33b7897b48ba52774")
});
db.getCollection("terms").insert({
  "IEML": "U:M:.e.-",
  "FR": "performer virtuellement dans la compétence",
  "EN": "perform virtually into competency",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "bhabgaaaa"
  ],
  "_id": ObjectId("566dea9e3b7897b48ba52779")
});
db.getCollection("terms").insert({
  "IEML": "A:M:.e.-",
  "FR": "performer actuellement dans la compétence",
  "EN": "perform actually into competency",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "chabgaaaa"
  ],
  "_id": ObjectId("566deaba3b7897b48ba5277e")
});
db.getCollection("terms").insert({
  "IEML": "O:S:.e.-",
  "FR": "performer dans la compétence selon le signe",
  "EN": "perform into competency according to sign",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "deabgaaaa"
  ],
  "_id": ObjectId("566deae23b7897b48ba52783")
});
db.getCollection("terms").insert({
  "IEML": "O:B:.e.-",
  "FR": "performer dans la compétence selon l'être",
  "EN": "perform into competency according to being",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dfabgaaaa"
  ],
  "_id": ObjectId("566deb053b7897b48ba52788")
});
db.getCollection("terms").insert({
  "IEML": "O:T:.e.-",
  "FR": "performer dans la competence selon la chose",
  "EN": "perform into competency according to thing",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dgabgaaaa"
  ],
  "_id": ObjectId("566deb3c3b7897b48ba5278d")
});
db.getCollection("terms").insert({
  "IEML": "U:M:.u.-",
  "FR": "performer dans l'expression virtuellement",
  "EN": "perform virtually into expression",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "bhaceaaaa"
  ],
  "_id": ObjectId("566debe63b7897b48ba52792")
});
db.getCollection("terms").insert({
  "IEML": "A:M:.u.-",
  "FR": "performer dans l'expression actuellement",
  "EN": "perform actually into expression",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "chaceaaaa"
  ],
  "_id": ObjectId("566dec1c3b7897b48ba52797")
});
db.getCollection("terms").insert({
  "IEML": "O:S:.u.-",
  "FR": "performer dans l'expression selon le signe",
  "EN": "perform into expression according to sign",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "deaceaaaa"
  ],
  "_id": ObjectId("566dec3b3b7897b48ba5279c")
});
db.getCollection("terms").insert({
  "IEML": "O:B:.u.-",
  "FR": "performer dans l'expression selon l'être",
  "EN": "perform into expression according to being",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dfaceaaaa"
  ],
  "_id": ObjectId("566dec6a3b7897b48ba527a1")
});
db.getCollection("terms").insert({
  "IEML": "O:T:.u.-",
  "FR": "performer dans l'expression selon la chose",
  "EN": "perform into expression according to thing",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dgaceaaaa"
  ],
  "_id": ObjectId("566dec8c3b7897b48ba527a6")
});
db.getCollection("terms").insert({
  "IEML": "U:M:.a.-",
  "FR": "performer virtuellement dans la relation sociale",
  "EN": "perform virtually into social relation",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "bhacfaaaa"
  ],
  "_id": ObjectId("566decef3b7897b48ba527ab")
});
db.getCollection("terms").insert({
  "IEML": "A:M:.a.-",
  "FR": "performer actuellement dans la relation sociale",
  "EN": "perform actually into social relation",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "chacfaaaa"
  ],
  "_id": ObjectId("566ded1b3b7897b48ba527b0")
});
db.getCollection("terms").insert({
  "IEML": "O:S:.a.-",
  "FR": "performer dans la relation sociale selon le signe",
  "EN": "perform into social relation according to sign",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "deacfaaaa"
  ],
  "_id": ObjectId("566ded413b7897b48ba527b5")
});
db.getCollection("terms").insert({
  "IEML": "O:B:.a.-",
  "FR": "performer dans la relation sociale selon l'être",
  "EN": "perform into social relation according to being",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dfacfaaaa"
  ],
  "_id": ObjectId("566ded753b7897b48ba527ba")
});
db.getCollection("terms").insert({
  "IEML": "O:T:.a.-",
  "FR": "performer dans la relation sociale selon la chose",
  "EN": "perform into social relation according to thing",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dgacfaaaa"
  ],
  "_id": ObjectId("566ded953b7897b48ba527bf")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bhacgaaaa"
  ],
  "CLASS": "2",
  "EN": "perform virtually into concrete matters",
  "FR": "performer virtuellement dans le concret",
  "IEML": "U:M:.i.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("566dedf63b7897b48ba527c4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "chacgaaaa"
  ],
  "CLASS": "2",
  "EN": "perform actually into concrete matters",
  "FR": "performer actuellement dans le concret",
  "IEML": "A:M:.i.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("566dee163b7897b48ba527c9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "deacgaaaa"
  ],
  "CLASS": "2",
  "EN": "perform into concrete matters according to sign",
  "FR": "performer dans le concret selon le signe",
  "IEML": "O:S:.i.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("566dee783b7897b48ba527ce")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dfacgaaaa"
  ],
  "CLASS": "2",
  "EN": "perform into concrete matters according to being",
  "FR": "performer dans le concret selon l'être",
  "IEML": "O:B:.i.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("566dee9d3b7897b48ba527d3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dgacgaaaa"
  ],
  "CLASS": "2",
  "EN": "perform into concrete matters according to thing",
  "FR": "performer dans le concret selon la chose",
  "IEML": "O:T:.i.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("566deeca3b7897b48ba527d8")
});
db.getCollection("terms").insert({
  "IEML": "s.O:O:.F:.-",
  "FR": "cognition symbolique",
  "EN": "symbolic cognition",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "20",
  "CANONICAL": [
    "eeaddaiaa"
  ],
  "_id": ObjectId("566df5c33b7897b48ba527f2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeaccaiaa"
  ],
  "CLASS": "4",
  "EN": "system of symbols",
  "FR": "système de symboles",
  "IEML": "s.we.F:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "5",
  "_id": ObjectId("566df6fe3b7897b48ba527f9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeacbaiaa"
  ],
  "CLASS": "4",
  "EN": "system of concepts (sensorium)",
  "FR": "système de concepts (sensorium)",
  "IEML": "s.wu.F:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "5",
  "_id": ObjectId("566df7203b7897b48ba52800")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeabcaiaa"
  ],
  "CLASS": "4",
  "EN": "communication of ideas",
  "FR": "communication des idées",
  "IEML": "s.wa.F:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "5",
  "_id": ObjectId("566df74e3b7897b48ba52807")
});
db.getCollection("terms").insert({
  "IEML": "s.wo.F:.-",
  "FR": "intelligence réflexive",
  "EN": "reflexive intelligence",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "5",
  "CANONICAL": [
    "eeabbaiaa"
  ],
  "_id": ObjectId("566df84c3b7897b48ba5280e")
});
db.getCollection("terms").insert({
  "IEML": "s.we.U:.-",
  "FR": "système de signifiés",
  "EN": "system of signifieds",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "eeaccabaa"
  ],
  "_id": ObjectId("566df89a3b7897b48ba52815")
});
db.getCollection("terms").insert({
  "IEML": "s.we.A:.-",
  "FR": "système de signifiants",
  "EN": "system of signifiers",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "eeaccacaa"
  ],
  "_id": ObjectId("566df8b43b7897b48ba5281c")
});
db.getCollection("terms").insert({
  "IEML": "s.we.S:.-",
  "FR": "code symbolique",
  "EN": "symbolic code",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "eeaccaeaa"
  ],
  "_id": ObjectId("566df8ee3b7897b48ba52823")
});
db.getCollection("terms").insert({
  "IEML": "s.we.B:.-",
  "FR": "système de mobilisation",
  "EN": "mobilisation system",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "eeaccafaa"
  ],
  "_id": ObjectId("566df91c3b7897b48ba5282a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeacbacaa"
  ],
  "CLASS": "4",
  "EN": "intuition des relations",
  "FR": "intuition des relations",
  "IEML": "s.wu.A:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("566df9ff3b7897b48ba5283f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeacbaeaa"
  ],
  "CLASS": "4",
  "EN": "symbols",
  "FR": "symboles",
  "IEML": "s.wu.S:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("566dfa553b7897b48ba52846")
});
db.getCollection("terms").insert({
  "IEML": "s.wu.B:.-",
  "FR": "interprétants",
  "EN": "interpreters",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "eeacbafaa"
  ],
  "_id": ObjectId("566dfa893b7897b48ba5284d")
});
db.getCollection("terms").insert({
  "IEML": "s.wu.T:.-",
  "FR": "références",
  "EN": "references",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "eeacbagaa"
  ],
  "_id": ObjectId("566dfaa23b7897b48ba52854")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeabcaeaa"
  ],
  "CLASS": "4",
  "EN": "concepts",
  "FR": "concepts",
  "IEML": "s.wa.S:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("566dfacb3b7897b48ba5285b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeabbaeaa"
  ],
  "CLASS": "4",
  "EN": "self-analysis",
  "FR": "auto-analyse",
  "IEML": "s.wo.S:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("566dfb0c3b7897b48ba52862")
});
db.getCollection("terms").insert({
  "IEML": "s.wo.B:.-",
  "FR": "auto-synthèse",
  "EN": "self-synthesis",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "eeabbafaa"
  ],
  "_id": ObjectId("566dfb373b7897b48ba52869")
});
db.getCollection("terms").insert({
  "IEML": "s.wo.T:.-",
  "FR": "auto-compréhension",
  "EN": "self-understanding",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "eeabbagaa"
  ],
  "_id": ObjectId("566dfb4e3b7897b48ba52870")
});
db.getCollection("terms").insert({
  "IEML": "s.wo.U:.-",
  "FR": "continuum de conscience",
  "EN": "consciousness continuum",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "eeabbabaa"
  ],
  "_id": ObjectId("566dfbe23b7897b48ba52877")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeabbacaa"
  ],
  "CLASS": "4",
  "EN": "ecosystem of ideas",
  "FR": "écosystème d'idées",
  "IEML": "s.wo.A:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("566dfc2d3b7897b48ba5287e")
});
db.getCollection("terms").insert({
  "IEML": "s.wa.B:.-",
  "FR": "affects",
  "EN": "affects",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "eeabcafaa"
  ],
  "_id": ObjectId("566dfd163b7897b48ba52885")
});
db.getCollection("terms").insert({
  "IEML": "s.wa.T:.-",
  "FR": "percepts",
  "EN": "percepts",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "eeabcagaa"
  ],
  "_id": ObjectId("566dfd263b7897b48ba5288c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeabcacaa"
  ],
  "CLASS": "4",
  "EN": "communities",
  "FR": "communautés",
  "IEML": "s.wa.A:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("566dfe313b7897b48ba52893")
});
db.getCollection("terms").insert({
  "IEML": "s.wa.U:.-",
  "FR": "règles (jeux de langages)",
  "EN": "rules (language games)",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "eeabcabaa"
  ],
  "_id": ObjectId("566dfe693b7897b48ba5289a")
});
db.getCollection("terms").insert({
  "IEML": "y.M:U:.-",
  "FR": "examiner les possibles virtuels",
  "EN": "ponder the virtual possibilities",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "beahbaaaa"
  ],
  "_id": ObjectId("566efb913b7897b48ba528a1")
});
db.getCollection("terms").insert({
  "IEML": "y.M:A:.-",
  "FR": "examiner les possibles actuels",
  "EN": "ponder the actual possibilities",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "beahcaaaa"
  ],
  "_id": ObjectId("566efbae3b7897b48ba528a6")
});
db.getCollection("terms").insert({
  "IEML": "y.S:O:.-",
  "FR": "examiner les possibles selon le signe",
  "EN": "ponder the possibilities according to sign",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "beaedaaaa"
  ],
  "_id": ObjectId("566efbe33b7897b48ba528ab")
});
db.getCollection("terms").insert({
  "IEML": "y.B:O:.-",
  "FR": "examiner les possibles selon l'être",
  "EN": "ponder possibilities according to being",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "beafdaaaa"
  ],
  "_id": ObjectId("566efc033b7897b48ba528b0")
});
db.getCollection("terms").insert({
  "IEML": "y.T:O:.-",
  "FR": "examiner les possibles selon la chose",
  "EN": "ponder possibilities according to thing",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "beagdaaaa"
  ],
  "_id": ObjectId("566efc263b7897b48ba528b5")
});
db.getCollection("terms").insert({
  "IEML": "o.M:U:.-",
  "FR": "orienter une production virtuellement",
  "EN": "orient a production virtually",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "bfahbaaaa"
  ],
  "_id": ObjectId("566efc803b7897b48ba528ba")
});
db.getCollection("terms").insert({
  "IEML": "o.M:A:.-",
  "FR": "orienter une production actuellement",
  "EN": "orient a production actually",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "bfahcaaaa"
  ],
  "_id": ObjectId("566efc9e3b7897b48ba528bf")
});
db.getCollection("terms").insert({
  "IEML": "o.S:O:.-",
  "FR": "orienter une production selon le signe",
  "EN": "orient a production according to sign",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "bfaedaaaa"
  ],
  "_id": ObjectId("566efcd03b7897b48ba528c4")
});
db.getCollection("terms").insert({
  "IEML": "o.B:O:.-",
  "FR": "orienter une production selon l'être",
  "EN": "orient a production according to being",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "bfafdaaaa"
  ],
  "_id": ObjectId("566efcf13b7897b48ba528c9")
});
db.getCollection("terms").insert({
  "IEML": "o.T:O:.-",
  "FR": "orienter une production selon la chose",
  "EN": "orient a production according to thing",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "bfagdaaaa"
  ],
  "_id": ObjectId("566efd0e3b7897b48ba528ce")
});
db.getCollection("terms").insert({
  "IEML": "e.M:U:.-",
  "FR": "maîtriser une production virtuellement",
  "EN": "master a production virtually",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "bgahbaaaa"
  ],
  "_id": ObjectId("566efd5f3b7897b48ba528d3")
});
db.getCollection("terms").insert({
  "IEML": "e.M:A:.-",
  "FR": "maîtriser une production actuellement",
  "EN": "master a production actually",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "bgahcaaaa"
  ],
  "_id": ObjectId("566efd7c3b7897b48ba528d8")
});
db.getCollection("terms").insert({
  "IEML": "e.S:O:.-",
  "FR": "maîtriser une production selon le signe",
  "EN": "master a production according to sign",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "bgaedaaaa"
  ],
  "_id": ObjectId("566efd9f3b7897b48ba528dd")
});
db.getCollection("terms").insert({
  "IEML": "e.B:O:.-",
  "FR": "maîtriser une production selon l'être",
  "EN": "master a production according to being",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "bgafdaaaa"
  ],
  "_id": ObjectId("566efdbb3b7897b48ba528e2")
});
db.getCollection("terms").insert({
  "IEML": "e.T:O:.-",
  "FR": "maîtriser une production selon la chose",
  "EN": "master a production according to thing",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "bgagdaaaa"
  ],
  "_id": ObjectId("566efddc3b7897b48ba528e7")
});
db.getCollection("terms").insert({
  "IEML": "u.M:U:.-",
  "FR": "communiquer une oeuvre virtuellement",
  "EN": "communicate a work virtually",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "ceahbaaaa"
  ],
  "_id": ObjectId("566efe363b7897b48ba528ec")
});
db.getCollection("terms").insert({
  "IEML": "u.M:A:.-",
  "FR": "communiquer une oeuvre actuellement",
  "EN": "communicate a work actually",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "ceahcaaaa"
  ],
  "_id": ObjectId("566efe523b7897b48ba528f1")
});
db.getCollection("terms").insert({
  "IEML": "u.S:O:.-",
  "FR": "communiquer une oeuvre selon le signe",
  "EN": "communicate a work according to sign",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "ceaedaaaa"
  ],
  "_id": ObjectId("566efe743b7897b48ba528f6")
});
db.getCollection("terms").insert({
  "IEML": "u.B:O:.-",
  "FR": "communiquer une oeuvre selon l'être",
  "EN": "communicate a work according to being",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "ceafdaaaa"
  ],
  "_id": ObjectId("566efea23b7897b48ba528fb")
});
db.getCollection("terms").insert({
  "IEML": "u.T:O:.-",
  "FR": "communiquer une oeuvre selon la chose",
  "EN": "communicate a work according to thing",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "ceagdaaaa"
  ],
  "_id": ObjectId("566efec33b7897b48ba52900")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfahbaaaa"
  ],
  "CLASS": "2",
  "EN": "commit to a work virtually",
  "FR": "s'engager dans une oeuvre virtuellement",
  "IEML": "a.M:U:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("566eff193b7897b48ba52905")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfahcaaaa"
  ],
  "CLASS": "2",
  "EN": "commit to a work actually",
  "FR": "s'engager dans une oeuvre actuellement",
  "IEML": "a.M:A:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("566eff3e3b7897b48ba5290a")
});
db.getCollection("terms").insert({
  "IEML": "a.S:O:.-",
  "FR": "s'engager dans une oeuvre selon le sign",
  "EN": "commit to a work according to sign",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "cfaedaaaa"
  ],
  "_id": ObjectId("566effc93b7897b48ba5290f")
});
db.getCollection("terms").insert({
  "IEML": "a.B:O:.-",
  "FR": "s'engager dans une oeuvre selon l'être",
  "EN": "commit to a work according to being",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "cfafdaaaa"
  ],
  "_id": ObjectId("566effe83b7897b48ba52914")
});
db.getCollection("terms").insert({
  "IEML": "a.T:O:.-",
  "FR": "s'engager dans une oeuvre selon la chose",
  "EN": "commit to a work according to thing",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "cfagdaaaa"
  ],
  "_id": ObjectId("566f00053b7897b48ba52919")
});
db.getCollection("terms").insert({
  "IEML": "i.M:U:.-",
  "FR": "parachever une oeuvre virtuellement",
  "EN": "achieve a work virtually",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "cgahbaaaa"
  ],
  "_id": ObjectId("566f00663b7897b48ba5291e")
});
db.getCollection("terms").insert({
  "IEML": "i.M:A:.-",
  "FR": "parachever une oeuvre actuellement",
  "EN": "achieve a work actually",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "cgahcaaaa"
  ],
  "_id": ObjectId("566f00ae3b7897b48ba52923")
});
db.getCollection("terms").insert({
  "IEML": "i.S:O:.-",
  "FR": "parachever une oeuvre selon le signe",
  "EN": "achieve a work according to sign",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "cgaedaaaa"
  ],
  "_id": ObjectId("566f00d73b7897b48ba52928")
});
db.getCollection("terms").insert({
  "IEML": "i.B:O:.-",
  "FR": "parachever une oeuvre selon l'être",
  "EN": "achieve a work according to being",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "cgafdaaaa"
  ],
  "_id": ObjectId("566f00f63b7897b48ba5292d")
});
db.getCollection("terms").insert({
  "IEML": "i.T:O:.-",
  "FR": "parachever une oeuvre selon la chose",
  "EN": "achieve a work according to thing",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "cgagdaaaa"
  ],
  "_id": ObjectId("566f011d3b7897b48ba52932")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bhaebaaaa"
  ],
  "CLASS": "2",
  "EN": "work on the medium virtually",
  "FR": "travailler le médium virtuellement",
  "IEML": "U:M:.j.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("566f017a3b7897b48ba52937")
});
db.getCollection("terms").insert({
  "IEML": "A:M:.j.-",
  "FR": "travailler le médium actuellement",
  "EN": "work on the medium actually",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "chaebaaaa"
  ],
  "_id": ObjectId("566f01a23b7897b48ba5293c")
});
db.getCollection("terms").insert({
  "IEML": "O:S:.j.-",
  "FR": "travailler le médium selon le signe",
  "EN": "work on the medium according to sign",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "deaebaaaa"
  ],
  "_id": ObjectId("566f01e83b7897b48ba52941")
});
db.getCollection("terms").insert({
  "IEML": "O:B:.j.-",
  "FR": "travailler le médium selon l'être",
  "EN": "work on the medium according to being",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dfaebaaaa"
  ],
  "_id": ObjectId("566f021c3b7897b48ba52946")
});
db.getCollection("terms").insert({
  "IEML": "O:T:.j.-",
  "FR": "travailler le médium selon la chose",
  "EN": "work on the medium according to thing",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dgaebaaaa"
  ],
  "_id": ObjectId("566f023a3b7897b48ba5294b")
});
db.getCollection("terms").insert({
  "IEML": "U:M:.h.-",
  "FR": "travailler l'interprétation virtuellement",
  "EN": "work on the interpretation virtually",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "bhafbaaaa"
  ],
  "_id": ObjectId("566f42fd3b7897b48ba52950")
});
db.getCollection("terms").insert({
  "IEML": "A:M:.h.-",
  "FR": "travailler l'interprétation actuellement",
  "EN": "work on the interpretation actually",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "chafbaaaa"
  ],
  "_id": ObjectId("566f43323b7897b48ba52955")
});
db.getCollection("terms").insert({
  "IEML": "O:S:.h.-",
  "FR": "travailler l'interprétation selon le sign",
  "EN": "work on the interpretation according to sign",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "deafbaaaa"
  ],
  "_id": ObjectId("566f43693b7897b48ba5295a")
});
db.getCollection("terms").insert({
  "IEML": "O:B:.h.-",
  "FR": "travailler l'interprétation selon l'être",
  "EN": "work on the interpretation according to being",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dfafbaaaa"
  ],
  "_id": ObjectId("566f438f3b7897b48ba5295f")
});
db.getCollection("terms").insert({
  "IEML": "O:T:.h.-",
  "FR": "travailler l'interprétation selon la chose",
  "EN": "work on the interpretation according to thing",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dgafbaaaa"
  ],
  "_id": ObjectId("566f43b63b7897b48ba52964")
});
db.getCollection("terms").insert({
  "IEML": "U:M:.p.-",
  "FR": "travailler sur un sujet virtuellement",
  "EN": "work on a subject virtually",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "bhagbaaaa"
  ],
  "_id": ObjectId("566f442a3b7897b48ba52969")
});
db.getCollection("terms").insert({
  "IEML": "A:M:.p.-",
  "FR": "travailler sur un sujet actuellement",
  "EN": "work on a subject actually",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "chagbaaaa"
  ],
  "_id": ObjectId("566f444f3b7897b48ba5296e")
});
db.getCollection("terms").insert({
  "IEML": "O:S:.p.-",
  "FR": "travailler sur un sujet selon le signe",
  "EN": "work on a subject according to sign",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "deagbaaaa"
  ],
  "_id": ObjectId("566f447c3b7897b48ba52973")
});
db.getCollection("terms").insert({
  "IEML": "O:B:.p.-",
  "FR": "travailler un sujet selon l'être",
  "EN": "work on a subject according to being",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dfagbaaaa"
  ],
  "_id": ObjectId("566f44b53b7897b48ba52978")
});
db.getCollection("terms").insert({
  "IEML": "O:T:.p.-",
  "FR": "travailler un sujet selon la chose",
  "EN": "work on a subject according to thing",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dgagbaaaa"
  ],
  "_id": ObjectId("566f44d33b7897b48ba5297d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bhagcaaaa"
  ],
  "CLASS": "2",
  "EN": "work on a method virtually",
  "FR": "travailler une méthode virtuellement",
  "IEML": "U:M:.x.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("566f453c3b7897b48ba52982")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "chagcaaaa"
  ],
  "CLASS": "2",
  "EN": "work on a method actually",
  "FR": "travailler une méthode actuellement",
  "IEML": "A:M:.x.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("566f45593b7897b48ba52987")
});
db.getCollection("terms").insert({
  "IEML": "O:S:.x.-",
  "FR": "travailler une méthode selon le sign",
  "EN": "work on a method according to sign",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "deagcaaaa"
  ],
  "_id": ObjectId("566f45853b7897b48ba5298c")
});
db.getCollection("terms").insert({
  "IEML": "O:B:.x.-",
  "FR": "travailler une méthode selon l'être",
  "EN": "work on a method according to being",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dfagcaaaa"
  ],
  "_id": ObjectId("566f46353b7897b48ba52991")
});
db.getCollection("terms").insert({
  "IEML": "O:T:.x.-",
  "FR": "travailler une méthode selon la chose",
  "EN": "work on a method according to thing",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dgagcaaaa"
  ],
  "_id": ObjectId("566f46723b7897b48ba52996")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bhaecaaaa"
  ],
  "CLASS": "2",
  "EN": "work on a statement virtually",
  "FR": "travailler une démarche virtuellement",
  "IEML": "U:M:.g.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("566f46e63b7897b48ba5299b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dhaecaaaa"
  ],
  "CLASS": "2",
  "EN": "work on an artist statement | a narrative",
  "FR": "travailler une démarche artistique | un récit",
  "IEML": "O:M:.g.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("55d220dc6653c32453c0a720")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "chaecaaaa"
  ],
  "CLASS": "2",
  "EN": "work on a statement actually",
  "FR": "travailler une démarche actuellement",
  "IEML": "A:M:.g.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("566f47f53b7897b48ba529a0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "deaecaaaa"
  ],
  "CLASS": "2",
  "EN": "work on a statement according to sign",
  "FR": "travailler une démarche selon le signe",
  "IEML": "O:S:.g.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("566f48153b7897b48ba529a5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dfaecaaaa"
  ],
  "CLASS": "2",
  "EN": "work on a statement according to being",
  "FR": "travailler une démarche selon l'être",
  "IEML": "O:B:.g.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("566f483c3b7897b48ba529aa")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dgaecaaaa"
  ],
  "CLASS": "2",
  "EN": "work on a statement according to thing",
  "FR": "travailler une démarche selon la chose",
  "IEML": "O:T:.g.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("566f485e3b7897b48ba529af")
});
db.getCollection("terms").insert({
  "IEML": "U:M:.c.-",
  "FR": "travailler sur soi virtuellement",
  "EN": "work on oneself virtually",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "bhafcaaaa"
  ],
  "_id": ObjectId("566f4a113b7897b48ba529b4")
});
db.getCollection("terms").insert({
  "IEML": "A:M:.c.-",
  "FR": "travailler sur soi actuellement",
  "EN": "work on oneself actually",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "chafcaaaa"
  ],
  "_id": ObjectId("566f4a333b7897b48ba529b9")
});
db.getCollection("terms").insert({
  "IEML": "O:S:.c.-",
  "FR": "travailler sur soi selon le signe",
  "EN": "work on oneself according to sign",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "deafcaaaa"
  ],
  "_id": ObjectId("566f4a523b7897b48ba529be")
});
db.getCollection("terms").insert({
  "IEML": "O:B:.c.-",
  "FR": "travailler sur soi selon l'être",
  "EN": "work on oneself according to being",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dfafcaaaa"
  ],
  "_id": ObjectId("566f4a7b3b7897b48ba529c3")
});
db.getCollection("terms").insert({
  "IEML": "O:T:.c.-",
  "FR": "travailler sur soi selon la chose",
  "EN": "work on oneself according to thing",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dgafcaaaa"
  ],
  "_id": ObjectId("566f4beb3b7897b48ba529c8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dhahhaaaa",
    "hhadhaaaa"
  ],
  "CLASS": "6",
  "EN": "determinants of human development",
  "FR": "déterminants du développement humain",
  "IEML": "O:M:.M:M:.-+M:M:.O:M:.-",
  "LAYER": "2",
  "PARADIGM": "1",
  "TAILLE": "108",
  "_id": ObjectId("566f4ef83b7897b48ba529cd")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeabhaaaa"
  ],
  "CLASS": "4",
  "EN": "virtual thought factors",
  "FR": "facteurs virtuels de pensée",
  "IEML": "s.U:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("5670705d3b7897b48ba529ce")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeachaaaa"
  ],
  "CLASS": "4",
  "EN": "actual thought factors",
  "FR": "facteurs actuels de pensée",
  "IEML": "s.A:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("5670707e3b7897b48ba529d3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeadeaaaa"
  ],
  "CLASS": "4",
  "EN": "abstract thought factors",
  "FR": "facteurs abstraits de pensée",
  "IEML": "s.O:S:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("567070b63b7897b48ba529d8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeadfaaaa"
  ],
  "CLASS": "4",
  "EN": "existential thought factors",
  "FR": "facteurs existentiels de pensée",
  "IEML": "s.O:B:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("567070e63b7897b48ba529dd")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeadgaaaa"
  ],
  "CLASS": "4",
  "EN": "concrete thought factors",
  "FR": "facteurs concrets de pensée",
  "IEML": "s.O:T:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("567071053b7897b48ba529e2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efabhaaaa"
  ],
  "CLASS": "4",
  "EN": "virtual language factors",
  "FR": "facteurs virtuels de langage",
  "IEML": "b.U:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("5670718f3b7897b48ba529e7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efachaaaa"
  ],
  "CLASS": "4",
  "EN": "actual language factors",
  "FR": "facteurs actuels de langage",
  "IEML": "b.A:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("567071b33b7897b48ba529ec")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efadeaaaa"
  ],
  "CLASS": "4",
  "EN": "abstract language factors",
  "FR": "facteurs abstraits de langage",
  "IEML": "b.O:S:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("567071db3b7897b48ba529f1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efadfaaaa"
  ],
  "CLASS": "4",
  "EN": "existential language factors",
  "FR": "facteurs existentiels de langage",
  "IEML": "b.O:B:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("567072213b7897b48ba529f6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efadgaaaa"
  ],
  "CLASS": "4",
  "EN": "concrete language factors",
  "FR": "facteurs concrets de langage",
  "IEML": "b.O:T:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("5670724f3b7897b48ba529fb")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egabhaaaa"
  ],
  "CLASS": "4",
  "EN": "virtual memory factors",
  "FR": "facteurs virtuels de mémoire",
  "IEML": "t.U:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("567072b83b7897b48ba52a00")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egadeaaaa"
  ],
  "CLASS": "4",
  "EN": "abstract memory factors",
  "FR": "facteurs abstraits de mémoire",
  "IEML": "t.O:S:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("567072df3b7897b48ba52a05")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egachaaaa"
  ],
  "CLASS": "4",
  "EN": "actual memory factors",
  "FR": "facteurs actuels de mémoire",
  "IEML": "t.A:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("567073153b7897b48ba52a0a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egadfaaaa"
  ],
  "CLASS": "4",
  "EN": "existential memory factors",
  "FR": "facteurs existentiels de mémoire",
  "IEML": "t.O:B:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("5670733c3b7897b48ba52a0f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egadgaaaa"
  ],
  "CLASS": "4",
  "EN": "concrete memory factors",
  "FR": "facteurs concrets de mémoire",
  "IEML": "t.O:T:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("5670735a3b7897b48ba52a14")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feabhaaaa"
  ],
  "CLASS": "4",
  "EN": "virtual society factors",
  "FR": "facteurs virtuels de société",
  "IEML": "k.U:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("567073b93b7897b48ba52a19")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feachaaaa"
  ],
  "CLASS": "4",
  "EN": "actual society factors",
  "FR": "facteurs actuels de société",
  "IEML": "k.A:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("567073d83b7897b48ba52a1e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feadeaaaa"
  ],
  "CLASS": "4",
  "EN": "abstract society factors",
  "FR": "facteurs abstraits de société",
  "IEML": "k.O:S:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("567073f83b7897b48ba52a23")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feadfaaaa"
  ],
  "CLASS": "4",
  "EN": "existential society factors",
  "FR": "facteurs existentiels de société",
  "IEML": "k.O:B:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("5670741c3b7897b48ba52a28")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feadgaaaa"
  ],
  "CLASS": "4",
  "EN": "concrete society factors",
  "FR": "facteurs concrets de société",
  "IEML": "k.O:T:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("567074423b7897b48ba52a2d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffabhaaaa"
  ],
  "CLASS": "4",
  "EN": "virtual factors of affective bond",
  "FR": "facteurs virtuels de lien affectif",
  "IEML": "m.U:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("567074af3b7897b48ba52a32")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffachaaaa"
  ],
  "CLASS": "4",
  "EN": "actual factors of affective bond",
  "FR": "facteurs actuels de lien affectif",
  "IEML": "m.A:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("567074c83b7897b48ba52a37")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffadeaaaa"
  ],
  "CLASS": "4",
  "EN": "abstract factors of an affective bond",
  "FR": "facteurs abstraits de lien affectif",
  "IEML": "m.O:S:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("567074e63b7897b48ba52a3c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffadfaaaa"
  ],
  "CLASS": "4",
  "EN": "existential production of an affective bond",
  "FR": "production existentielle de lien affectif",
  "IEML": "m.O:B:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("567075113b7897b48ba52a41")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffadgaaaa"
  ],
  "CLASS": "4",
  "EN": "concrete production of an affective bond",
  "FR": "production concrète de lien affectif",
  "IEML": "m.O:T:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("5670752d3b7897b48ba52a46")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgabhaaaa"
  ],
  "CLASS": "4",
  "EN": "virtual world factors",
  "FR": "facteurs virtuels de monde",
  "IEML": "n.U:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("567075883b7897b48ba52a4b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgachaaaa"
  ],
  "CLASS": "4",
  "EN": "actual world factors",
  "FR": "facteurs actuels de monde",
  "IEML": "n.A:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("567075aa3b7897b48ba52a50")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgadeaaaa"
  ],
  "CLASS": "4",
  "EN": "abstract world factors",
  "FR": "facteurs abstraits de monde",
  "IEML": "n.O:S:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("567075de3b7897b48ba52a55")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgadfaaaa"
  ],
  "CLASS": "4",
  "EN": "existential world factors",
  "FR": "facteurs existentiels de monde",
  "IEML": "n.O:B:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("567076023b7897b48ba52a5a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgadgaaaa"
  ],
  "CLASS": "4",
  "EN": "concrete world factors",
  "FR": "facteurs concrets de monde",
  "IEML": "n.O:T:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("5670762a3b7897b48ba52a5f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geabhaaaa"
  ],
  "CLASS": "4",
  "EN": "virtual truth factors",
  "FR": "facteurs virtuels de vérité",
  "IEML": "d.U:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("567076873b7897b48ba52a64")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geachaaaa"
  ],
  "CLASS": "4",
  "EN": "actual truth factors",
  "FR": "facteurs actuels de vérité",
  "IEML": "d.A:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("567076a33b7897b48ba52a69")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geadeaaaa"
  ],
  "CLASS": "4",
  "EN": "abstract factors of truth",
  "FR": "facteurs abstraits de vérité",
  "IEML": "d.O:S:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("567076c53b7897b48ba52a6e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geadfaaaa"
  ],
  "CLASS": "4",
  "EN": "existential factors of truth",
  "FR": "facteurs existentiels de vérité",
  "IEML": "d.O:B:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("567076e63b7897b48ba52a73")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geadgaaaa"
  ],
  "CLASS": "4",
  "EN": "concrete factors of truth",
  "FR": "facteurs concrets de vérité",
  "IEML": "d.O:T:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("567077033b7897b48ba52a78")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfabhaaaa"
  ],
  "CLASS": "4",
  "EN": "virtual life factors",
  "FR": "facteurs virtuels de vie",
  "IEML": "f.U:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("567077783b7897b48ba52a7d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfachaaaa"
  ],
  "CLASS": "4",
  "EN": "actual life factors",
  "FR": "facteurs actuels de vie",
  "IEML": "f.A:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("567077943b7897b48ba52a82")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfadeaaaa"
  ],
  "CLASS": "4",
  "EN": "abstract life factors",
  "FR": "facteurs abstraits de vie",
  "IEML": "f.O:S:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("567077b33b7897b48ba52a87")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfadfaaaa"
  ],
  "CLASS": "4",
  "EN": "existential life factors",
  "FR": "facteurs existentiels de vie",
  "IEML": "f.O:B:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("567077d23b7897b48ba52a8c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfadgaaaa"
  ],
  "CLASS": "4",
  "EN": "concrete life factors",
  "FR": "facteurs concrets de vie",
  "IEML": "f.O:T:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("567077ed3b7897b48ba52a91")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggabhaaaa"
  ],
  "CLASS": "4",
  "EN": "virtual space factors",
  "FR": "facteurs virtuels d'espace",
  "IEML": "l.U:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("5670783d3b7897b48ba52a96")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggachaaaa"
  ],
  "CLASS": "4",
  "EN": "actual space factors",
  "FR": "facteurs actuels d'espace",
  "IEML": "l.A:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("567078683b7897b48ba52a9b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggadeaaaa"
  ],
  "CLASS": "4",
  "EN": "abstract space factors",
  "FR": "facteurs abstraits d'espace",
  "IEML": "l.O:S:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("5670788b3b7897b48ba52aa0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggadfaaaa"
  ],
  "CLASS": "4",
  "EN": "existential space factors",
  "FR": "facteurs existentiels d'espace",
  "IEML": "l.O:B:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("567078ac3b7897b48ba52aa5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggadgaaaa"
  ],
  "CLASS": "4",
  "EN": "concrete space factors",
  "FR": "facteiurs concrets d'espace",
  "IEML": "l.O:T:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("567078c73b7897b48ba52aaa")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ehabeaaaa"
  ],
  "CLASS": "4",
  "EN": "knowing power of sign",
  "FR": "pouvoir savoir du signe",
  "IEML": "S:M:.y.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("56707b173b7897b48ba52aaf")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fhabeaaaa"
  ],
  "CLASS": "4",
  "EN": "knowing power of being",
  "FR": "pouvoir savoir de l'être",
  "IEML": "B:M:.y.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("56707b363b7897b48ba52ab4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ghabeaaaa"
  ],
  "CLASS": "4",
  "EN": "knowing power of thing",
  "FR": "pouvoir savoir de la chose",
  "IEML": "T:M:.y.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("56707b533b7897b48ba52ab9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "heabeaaaa"
  ],
  "CLASS": "4",
  "EN": "cognition becoming sign",
  "FR": "devenir signe de la cognition",
  "IEML": "M:S:.y.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("56707bb53b7897b48ba52abe")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hfabeaaaa"
  ],
  "CLASS": "4",
  "EN": "cognition becoming being",
  "FR": "devenir être de la cognition",
  "IEML": "M:B:.y.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("56707bd13b7897b48ba52ac3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hgabeaaaa"
  ],
  "CLASS": "4",
  "EN": "cognition becoming thing",
  "FR": "devenir chose de la cognition",
  "IEML": "M:T:.y.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("56707bf03b7897b48ba52ac8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ehabfaaaa"
  ],
  "CLASS": "4",
  "EN": "will to be of the sign",
  "FR": "vouloir être du signe",
  "IEML": "S:M:.o.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("56707c793b7897b48ba52acd")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fhabfaaaa"
  ],
  "CLASS": "4",
  "EN": "will to be of the being",
  "FR": "vouloir être de l'être",
  "IEML": "B:M:.o.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("56707c973b7897b48ba52ad2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ghabfaaaa"
  ],
  "CLASS": "4",
  "EN": "will to be of the thing",
  "FR": "vouloir être de la chose",
  "IEML": "T:M:.o.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("56707cbc3b7897b48ba52ad7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "heabfaaaa"
  ],
  "CLASS": "4",
  "EN": "ethics becoming sign",
  "FR": "devenir signe de l'éthique",
  "IEML": "M:S:.o.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("56707cd63b7897b48ba52adc")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hfabfaaaa"
  ],
  "CLASS": "4",
  "EN": "ethics becoming being",
  "FR": "devenir être de l'éthique",
  "IEML": "M:B:.o.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("56707cf23b7897b48ba52ae1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hgabfaaaa"
  ],
  "CLASS": "4",
  "EN": "ethics becoming thing",
  "FR": "devenir chose de l'éthique",
  "IEML": "M:T:.o.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("56707d153b7897b48ba52ae6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ehaceaaaa"
  ],
  "CLASS": "4",
  "EN": "making sense of the sign",
  "FR": "faire sens du signe",
  "IEML": "S:M:.u.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("56707eba3b7897b48ba52aeb")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fhaceaaaa"
  ],
  "CLASS": "4",
  "EN": "making sense of being",
  "FR": "faire sens de l'être",
  "IEML": "B:M:.u.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("56707ecf3b7897b48ba52af0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ghaceaaaa"
  ],
  "CLASS": "4",
  "EN": "sense making of thing",
  "FR": "faire sens de la chose",
  "IEML": "T:M:.u.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("56707ee63b7897b48ba52af5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "heaceaaaa"
  ],
  "CLASS": "4",
  "EN": "meaning becoming sign",
  "FR": "devenir signe du sens",
  "IEML": "M:S:.u.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("56707f1a3b7897b48ba52afa")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hfaceaaaa"
  ],
  "CLASS": "4",
  "EN": "meaning becoming being",
  "FR": "devenir être du sens",
  "IEML": "M:B:.u.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("56707f363b7897b48ba52aff")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hgaceaaaa"
  ],
  "CLASS": "4",
  "EN": "meaning becoming thing",
  "FR": "devenir chose du sens",
  "IEML": "M:T:.u.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("56707f4e3b7897b48ba52b04")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ehacfaaaa"
  ],
  "CLASS": "4",
  "EN": "making society of the sign",
  "FR": "faire société du signe",
  "IEML": "S:M:.a.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("567082443b7897b48ba52b09")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fhacfaaaa"
  ],
  "CLASS": "4",
  "EN": "making society of being",
  "FR": "faire société de l'être",
  "IEML": "B:M:.a.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("567082813b7897b48ba52b0e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ghacfaaaa"
  ],
  "CLASS": "4",
  "EN": "society making of thing",
  "FR": "faire société de la chose",
  "IEML": "T:M:.a.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("5670829e3b7897b48ba52b13")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "heacfaaaa"
  ],
  "CLASS": "4",
  "EN": "society becoming sign",
  "FR": "devenir signe de la société",
  "IEML": "M:S:.a.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("567082c33b7897b48ba52b18")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hfacfaaaa"
  ],
  "CLASS": "4",
  "EN": "society becoming being",
  "FR": "devenir être de la société",
  "IEML": "M:B:.a.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("567082e23b7897b48ba52b1d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hgacfaaaa"
  ],
  "CLASS": "4",
  "EN": "society becoming thing",
  "FR": "devenir chose de la société",
  "IEML": "M:T:.a.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("567082fe3b7897b48ba52b22")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ehacgaaaa"
  ],
  "CLASS": "4",
  "EN": "tool making of the sign",
  "FR": "faire outil du signe",
  "IEML": "S:M:.i.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("567083523b7897b48ba52b27")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fhacgaaaa"
  ],
  "CLASS": "4",
  "EN": "tool making of the being",
  "FR": "faire outil de l'être",
  "IEML": "B:M:.i.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("5670837e3b7897b48ba52b2c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ghacgaaaa"
  ],
  "CLASS": "4",
  "EN": "tool making of thing",
  "FR": "faire outil de la chose",
  "IEML": "T:M:.i.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("5670839e3b7897b48ba52b31")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "heacgaaaa"
  ],
  "CLASS": "4",
  "EN": "tool becoming sign",
  "FR": "devenir signe de l'outil",
  "IEML": "M:S:.i.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("567083c73b7897b48ba52b36")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hfacgaaaa"
  ],
  "CLASS": "4",
  "EN": "tool becoming being",
  "FR": "devenir être de l'outil",
  "IEML": "M:B:.i.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("567083e43b7897b48ba52b3b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hgacgaaaa"
  ],
  "CLASS": "4",
  "EN": "tool becoming thing",
  "FR": "devenir chose de l'outil",
  "IEML": "M:T:.i.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("567084013b7897b48ba52b40")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "beaehaaaa"
  ],
  "CLASS": "2",
  "EN": "ignore sign",
  "FR": "ignorer le signe",
  "IEML": "y.S:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("5671dcc53b7897b48ba52b45")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "beafhaaaa"
  ],
  "CLASS": "2",
  "EN": "ignore being",
  "FR": "ignorer l'être",
  "IEML": "y.B:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("5671dce23b7897b48ba52b4a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "beaghaaaa"
  ],
  "CLASS": "2",
  "EN": "ignore thing",
  "FR": "ignorer la chose",
  "IEML": "y.T:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("5671dcfc3b7897b48ba52b4f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "beaheaaaa"
  ],
  "CLASS": "2",
  "EN": "show the sign of ignorance",
  "FR": "montrer le signe de l'ignorance",
  "IEML": "y.M:S:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("5671dee93b7897b48ba52b54")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "beahfaaaa"
  ],
  "CLASS": "2",
  "EN": "show the being of ignorance",
  "FR": "montrer l'être de l'ignorance",
  "IEML": "y.M:B:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("5671df153b7897b48ba52b59")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "beahgaaaa"
  ],
  "CLASS": "2",
  "EN": "show the thing of ignorance",
  "FR": "montrer la chose de l'ignorance",
  "IEML": "y.M:T:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("5671e01d3b7897b48ba52b5e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bfaehaaaa"
  ],
  "CLASS": "2",
  "EN": "darken the sign",
  "FR": "assombrir le signe",
  "IEML": "o.S:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("5671e1c03b7897b48ba52b63")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bfafhaaaa"
  ],
  "CLASS": "2",
  "EN": "darken the being",
  "FR": "assombrir l'être",
  "IEML": "o.B:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("5671e59e3b7897b48ba52b68")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bfaghaaaa"
  ],
  "CLASS": "2",
  "EN": "darken the thing",
  "FR": "assombrir la chose",
  "IEML": "o.T:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("5671e5f73b7897b48ba52b6d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bfaheaaaa"
  ],
  "CLASS": "2",
  "EN": "show the sign of darkness",
  "FR": "montrer le signe de l'obscurité",
  "IEML": "o.M:S:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("5671e6273b7897b48ba52b72")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bfahfaaaa"
  ],
  "CLASS": "2",
  "EN": "show the being of darkness",
  "FR": "monter l'être de l'obscurité",
  "IEML": "o.M:B:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("5671e6a23b7897b48ba52b77")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bfahgaaaa"
  ],
  "CLASS": "2",
  "EN": "show the thing of darkness",
  "FR": "montrer la chose de l'obscurité",
  "IEML": "o.M:T:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("5671e6c93b7897b48ba52b7c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bfaegaaaa"
  ],
  "CLASS": "2",
  "EN": "be late | procrastinate | miss the opportunity",
  "FR": "être en retard | procrastiner | manquer l'occasion",
  "IEML": "o.t.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("55d220dd6653c32453c0a824")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bgaehaaaa"
  ],
  "CLASS": "2",
  "EN": "lack skills in the trivium of the sign",
  "FR": "manquer d'habiletés dans le trivium du signe",
  "IEML": "e.S:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("5671e80d3b7897b48ba52b81")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bgaheaaaa"
  ],
  "CLASS": "2",
  "EN": "lack grammatical skills",
  "FR": "manquer d'habiletés grammaticales",
  "IEML": "e.M:S:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("5671e85d3b7897b48ba52b86")
});
db.getCollection("terms").insert({
  "IEML": "e.M:B:.-",
  "FR": "manquer d'habiletés dialectiques",
  "EN": "lack dialectical skills",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "bgahfaaaa"
  ],
  "_id": ObjectId("5671e87c3b7897b48ba52b8b")
});
db.getCollection("terms").insert({
  "IEML": "e.M:T:.-",
  "FR": "manquer d'habiletés rhétoriques",
  "EN": "lack rhetorical skills",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "bgahgaaaa"
  ],
  "_id": ObjectId("5671e8ed3b7897b48ba52b90")
});
db.getCollection("terms").insert({
  "IEML": "e.B:M:.-",
  "FR": "manquer d'habiletés dans le trivium de l'être",
  "EN": "lack skills in the trivium of the being",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "bgafhaaaa"
  ],
  "_id": ObjectId("5671e9513b7897b48ba52b95")
});
db.getCollection("terms").insert({
  "IEML": "e.T:M:.-",
  "FR": "manquer d'habileté dans le trivium de la chose",
  "EN": "lack skills in the trivium of the thing",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "bgaghaaaa"
  ],
  "_id": ObjectId("5671ea953b7897b48ba52b9a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ceaehaaaa"
  ],
  "CLASS": "2",
  "EN": "destroy the sign of meaning",
  "FR": "détruire le signe de la signification",
  "IEML": "u.S:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("5671eb933b7897b48ba52b9f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ceafhaaaa"
  ],
  "CLASS": "2",
  "EN": "destroy the being of meaning",
  "FR": "détruire l'être de la signification",
  "IEML": "u.B:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("5671ebbb3b7897b48ba52ba4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ceaghaaaa"
  ],
  "CLASS": "2",
  "EN": "destroy the thing of meaning",
  "FR": "détruire la chose de la signification",
  "IEML": "u.T:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("5671ebe93b7897b48ba52ba9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ceaheaaaa"
  ],
  "CLASS": "2",
  "EN": "show the sign of destroyed signification",
  "FR": "montrer le signe de la signification détruite",
  "IEML": "u.M:S:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("5671ec113b7897b48ba52bae")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ceahfaaaa"
  ],
  "CLASS": "2",
  "EN": "show the being of destroyed meaning",
  "FR": "montrer l'être de la signification détruite",
  "IEML": "u.M:B:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("5671ec2f3b7897b48ba52bb3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ceahgaaaa"
  ],
  "CLASS": "2",
  "EN": "show the thing of the destroyed meaning",
  "FR": "montrer la chose de la signification détruite",
  "IEML": "u.M:T:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("5671ec4d3b7897b48ba52bb8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfaehaaaa"
  ],
  "CLASS": "2",
  "EN": "destroy the sign of social relations",
  "FR": "détruire le signe des relations sociales",
  "IEML": "a.S:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("56721d843b7897b48ba52bbd")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfafhaaaa"
  ],
  "CLASS": "2",
  "EN": "destroy the being of social relations",
  "FR": "détruire l'être des relations sociales",
  "IEML": "a.B:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("56721db83b7897b48ba52bc2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfaghaaaa"
  ],
  "CLASS": "2",
  "EN": "destroy the thing of social relations",
  "FR": "détruire la chose des relations sociales",
  "IEML": "a.T:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("56721de23b7897b48ba52bc7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfaheaaaa"
  ],
  "CLASS": "2",
  "EN": "show the sign of destroyed relationships",
  "FR": "montrer le signe des relations détruites",
  "IEML": "a.M:S:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("56721e133b7897b48ba52bcc")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfahfaaaa"
  ],
  "CLASS": "2",
  "EN": "show the being of destroyed relationships",
  "FR": "montrer l'être des relations détruites",
  "IEML": "a.M:B:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("56721e4c3b7897b48ba52bd1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cfahgaaaa"
  ],
  "CLASS": "2",
  "EN": "show the thing of destroyed relationship",
  "FR": "montrer la chose des relations détruites",
  "IEML": "a.M:T:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("56721ea23b7897b48ba52bd6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cgaehaaaa"
  ],
  "CLASS": "2",
  "EN": "destroy the sign technically",
  "FR": "détruire le signe techniquement",
  "IEML": "i.S:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("56758ab1b9fe1f5ab16a294e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cgafhaaaa"
  ],
  "CLASS": "2",
  "EN": "destroy the being technically",
  "FR": "détruire l'être techniquement",
  "IEML": "i.B:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("56758ca8b9fe1f5ab16a2953")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cgaghaaaa"
  ],
  "CLASS": "2",
  "EN": "destroy the thing technically",
  "FR": "détruire la chose techniquement",
  "IEML": "i.T:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("56758cedb9fe1f5ab16a2958")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cgaheaaaa"
  ],
  "CLASS": "2",
  "EN": "show the sign of technical destruction",
  "FR": "montrer le signe de la destruction technique",
  "IEML": "i.M:S:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("56758d2ab9fe1f5ab16a295d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cgahfaaaa"
  ],
  "CLASS": "2",
  "EN": "show the being of technical destruction",
  "FR": "montrer l'être de la destruction technique",
  "IEML": "i.M:B:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("56758d51b9fe1f5ab16a2962")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cgahgaaaa"
  ],
  "CLASS": "2",
  "EN": "show the thing of technical destruction",
  "FR": "montrer la chose de la destruction technique",
  "IEML": "i.M:T:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("56758d77b9fe1f5ab16a2967")
});
db.getCollection("terms").insert({
  "IEML": "U:M:.s.-",
  "FR": "miner la pensée virtuellement",
  "EN": "undermine thought virtually",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "bhaeeaaaa"
  ],
  "_id": ObjectId("56758e44b9fe1f5ab16a296c")
});
db.getCollection("terms").insert({
  "IEML": "A:M:.s.-",
  "FR": "miner la pensée actuellement",
  "EN": "undermine thought actually",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "chaeeaaaa"
  ],
  "_id": ObjectId("56758e73b9fe1f5ab16a2971")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "deaeeaaaa"
  ],
  "CLASS": "2",
  "EN": "undermine thought in an abstract way",
  "FR": "miner la pensée abstraitement",
  "IEML": "O:S:.s.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("56758eb7b9fe1f5ab16a2976")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dfaeeaaaa"
  ],
  "CLASS": "2",
  "EN": "undermine thought in an existential way",
  "FR": "miner la pensée existentiellement",
  "IEML": "O:B:.s.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("56758ed1b9fe1f5ab16a297b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dgaeeaaaa"
  ],
  "CLASS": "2",
  "EN": "undermine thought in a concrete way",
  "FR": "miner la pensée concrètement",
  "IEML": "O:T:.s.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("56758eedb9fe1f5ab16a2980")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bhaefaaaa"
  ],
  "CLASS": "2",
  "EN": "undo language virtually",
  "FR": "défaire le langage virtuellement",
  "IEML": "U:M:.b.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("56758f39b9fe1f5ab16a2985")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "chaefaaaa"
  ],
  "CLASS": "2",
  "EN": "undo language actually",
  "FR": "défaire le langage actuellement",
  "IEML": "A:M:.b.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("56758f73b9fe1f5ab16a298a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "deaefaaaa"
  ],
  "CLASS": "2",
  "EN": "undo language in an abstract way",
  "FR": "défaire le langage abstraitement",
  "IEML": "O:S:.b.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("56758fa8b9fe1f5ab16a298f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dfaefaaaa"
  ],
  "CLASS": "2",
  "EN": "undo language in an existential way",
  "FR": "défaire le langage existentiellement",
  "IEML": "O:B:.b.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("56758ff8b9fe1f5ab16a2994")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dgaefaaaa"
  ],
  "CLASS": "2",
  "EN": "undo language in a concrete way",
  "FR": "défaire le langage concrètement",
  "IEML": "O:T:.b.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("56759033b9fe1f5ab16a2999")
});
db.getCollection("terms").insert({
  "IEML": "U:M:.l.-",
  "FR": "détruire l'espace virtuellement",
  "EN": "destroy space virtually",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "bhaggaaaa"
  ],
  "_id": ObjectId("5675b33ab9fe1f5ab16a299e")
});
db.getCollection("terms").insert({
  "IEML": "A:M:.l.-",
  "FR": "détruire l'espace actuellement",
  "EN": "destroy space actually",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "chaggaaaa"
  ],
  "_id": ObjectId("5675b356b9fe1f5ab16a29a3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "deaggaaaa"
  ],
  "CLASS": "2",
  "EN": "destroy space in an abstract way",
  "FR": "détruire l'espace abstraitement",
  "IEML": "O:S:.l.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("5675b39db9fe1f5ab16a29a8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dfaggaaaa"
  ],
  "CLASS": "2",
  "EN": "destroy space in an existential way",
  "FR": "détruire l'espace existentiellement",
  "IEML": "O:B:.l.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("5675b3bfb9fe1f5ab16a29ad")
});
db.getCollection("terms").insert({
  "IEML": "O:T:.l.-",
  "FR": "détruire l'espace concrètement",
  "EN": "destroy space in a concrete way",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dgaggaaaa"
  ],
  "_id": ObjectId("5675b3e0b9fe1f5ab16a29b2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bhagfaaaa"
  ],
  "CLASS": "2",
  "EN": "weaken life virtually",
  "FR": "affaiblir la vie virtuellement",
  "IEML": "U:M:.f.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("5675b66ab9fe1f5ab16a29b7")
});
db.getCollection("terms").insert({
  "IEML": "A:M:.f.-",
  "FR": "affaiblir la vie actuellement",
  "EN": "weaken life actually",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "chagfaaaa"
  ],
  "_id": ObjectId("5675b687b9fe1f5ab16a29bc")
});
db.getCollection("terms").insert({
  "IEML": "O:S:.f.-",
  "FR": "affaiblir la vie abstraitement",
  "EN": "weaken life in an abstract way",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "deagfaaaa"
  ],
  "_id": ObjectId("5675b6dcb9fe1f5ab16a29c1")
});
db.getCollection("terms").insert({
  "IEML": "O:B:.f.-",
  "FR": "affaiblir la vie existentiellement",
  "EN": "weaken life existentially",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dfagfaaaa"
  ],
  "_id": ObjectId("5675b6f6b9fe1f5ab16a29c6")
});
db.getCollection("terms").insert({
  "IEML": "O:T:.f.-",
  "FR": "affaiblir la vie concrètement",
  "EN": "weaken life in a concrete way",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dgagfaaaa"
  ],
  "_id": ObjectId("5675b710b9fe1f5ab16a29cb")
});
db.getCollection("terms").insert({
  "IEML": "U:M:.d.-",
  "FR": "miner la vérité virtuellement",
  "EN": "undermine truth virtually",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "bhageaaaa"
  ],
  "_id": ObjectId("5675b796b9fe1f5ab16a29d0")
});
db.getCollection("terms").insert({
  "IEML": "A:M:.d.-",
  "FR": "miner la vérité actuellement",
  "EN": "undermine truth actually",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "chageaaaa"
  ],
  "_id": ObjectId("5675b7b0b9fe1f5ab16a29d5")
});
db.getCollection("terms").insert({
  "IEML": "O:S:.d.-",
  "FR": "miner la vérité abstraitement",
  "EN": "undermine truth in an abstract way",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "deageaaaa"
  ],
  "_id": ObjectId("5675b7e2b9fe1f5ab16a29da")
});
db.getCollection("terms").insert({
  "IEML": "O:B:.d.-",
  "FR": "miner la vérité existentiellement",
  "EN": "undermine truth in an existential way",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dfageaaaa"
  ],
  "_id": ObjectId("5675b7ffb9fe1f5ab16a29df")
});
db.getCollection("terms").insert({
  "IEML": "O:T:.d.-",
  "FR": "miner la vérité concrètement",
  "EN": "undermine truth in a concrete way",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dgageaaaa"
  ],
  "_id": ObjectId("5675b81ab9fe1f5ab16a29e4")
});
db.getCollection("terms").insert({
  "IEML": "U:M:.n.-",
  "FR": "défaire un monde virtuellement",
  "EN": "undo a world virtually",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "bhafgaaaa"
  ],
  "_id": ObjectId("5675b88db9fe1f5ab16a29e9")
});
db.getCollection("terms").insert({
  "IEML": "A:M:.n.-",
  "FR": "défaire un monde actuellement",
  "EN": "undo a world actually",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "chafgaaaa"
  ],
  "_id": ObjectId("5675b956b9fe1f5ab16a29ee")
});
db.getCollection("terms").insert({
  "IEML": "O:S:.n.-",
  "FR": "défaire un monde abstraitement",
  "EN": "undo a world in an abstract way",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "deafgaaaa"
  ],
  "_id": ObjectId("5675b977b9fe1f5ab16a29f3")
});
db.getCollection("terms").insert({
  "IEML": "O:B:.n.-",
  "FR": "défaire un monde existentiellement",
  "EN": "undo a world existentially",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dfafgaaaa"
  ],
  "_id": ObjectId("5675b991b9fe1f5ab16a29f8")
});
db.getCollection("terms").insert({
  "IEML": "O:T:.n.-",
  "FR": "défaire un monde concrètement",
  "EN": "undo a world in a concrete way",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dgafgaaaa"
  ],
  "_id": ObjectId("5675b9b4b9fe1f5ab16a29fd")
});
db.getCollection("terms").insert({
  "IEML": "U:M:.m.-",
  "FR": "défaire un lien affectif virtuellement",
  "EN": "undo an affective bon virtually",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "bhaffaaaa"
  ],
  "_id": ObjectId("5675bb03b9fe1f5ab16a2a02")
});
db.getCollection("terms").insert({
  "IEML": "A:M:.m.-",
  "FR": "défaire un lien affectif actuellement",
  "EN": "undo an affective bond actually",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "chaffaaaa"
  ],
  "_id": ObjectId("5675bb27b9fe1f5ab16a2a07")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "deaffaaaa"
  ],
  "CLASS": "2",
  "EN": "undo an affective bond in an abstract way",
  "FR": "défaire un lien affectif abstraitement",
  "IEML": "O:S:.m.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("5675bb53b9fe1f5ab16a2a0c")
});
db.getCollection("terms").insert({
  "IEML": "O:B:.m.-",
  "FR": "défaire un lien affectif existentiellement",
  "EN": "undo an affective bond in an existential way",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dfaffaaaa"
  ],
  "_id": ObjectId("5675bb80b9fe1f5ab16a2a11")
});
db.getCollection("terms").insert({
  "IEML": "O:T:.m.-",
  "FR": "défaire un lien affectif concrètement",
  "EN": "undo an affective bond in a concrete way",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dgaffaaaa"
  ],
  "_id": ObjectId("5675bba7b9fe1f5ab16a2a16")
});
db.getCollection("terms").insert({
  "IEML": "U:M:.k.-",
  "FR": "défaire la société virtuellement",
  "EN": "undo society virtually",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "bhafeaaaa"
  ],
  "_id": ObjectId("5675bc71b9fe1f5ab16a2a1b")
});
db.getCollection("terms").insert({
  "IEML": "A:M:.k.-",
  "FR": "défaire la société actuellement",
  "EN": "undo society actually",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "chafeaaaa"
  ],
  "_id": ObjectId("5675bc8db9fe1f5ab16a2a20")
});
db.getCollection("terms").insert({
  "IEML": "O:S:.k.-",
  "FR": "défaire la société abstaritement",
  "EN": "undo society in a n abstract way",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "deafeaaaa"
  ],
  "_id": ObjectId("5675bcb8b9fe1f5ab16a2a25")
});
db.getCollection("terms").insert({
  "IEML": "O:B:.k.-",
  "FR": "défaire la société existentiellement",
  "EN": "undo society in an existential way",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dfafeaaaa"
  ],
  "_id": ObjectId("5675bcdab9fe1f5ab16a2a2a")
});
db.getCollection("terms").insert({
  "IEML": "O:T:.k.-",
  "FR": "défaire la société concrètement",
  "EN": "undo society in a concrete way",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dgafeaaaa"
  ],
  "_id": ObjectId("5675bcf7b9fe1f5ab16a2a2f")
});
db.getCollection("terms").insert({
  "IEML": "U:M:.t.-",
  "FR": "détruire la mémoire virtuellement",
  "EN": "destroy memory virtually",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "bhaegaaaa"
  ],
  "_id": ObjectId("5675bd71b9fe1f5ab16a2a34")
});
db.getCollection("terms").insert({
  "IEML": "A:M:.t.-",
  "FR": "détruire la mémoire actuellement",
  "EN": "destroy memory actually",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "chaegaaaa"
  ],
  "_id": ObjectId("5675bd96b9fe1f5ab16a2a39")
});
db.getCollection("terms").insert({
  "IEML": "O:S:.t.-",
  "FR": "détruire la mémoire abstraitement",
  "EN": "destroy memory in an abstract way",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "deaegaaaa"
  ],
  "_id": ObjectId("5675bdbeb9fe1f5ab16a2a3e")
});
db.getCollection("terms").insert({
  "IEML": "O:B:.t.-",
  "FR": "détruire la mémoire existentiellement",
  "EN": "destroy memory in an existential way",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dfaegaaaa"
  ],
  "_id": ObjectId("5675bddeb9fe1f5ab16a2a43")
});
db.getCollection("terms").insert({
  "IEML": "O:T:.t.-",
  "FR": "détruire la mémoire concrètement",
  "EN": "destroy memory in a concrete way",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dgaegaaaa"
  ],
  "_id": ObjectId("5675be03b9fe1f5ab16a2a48")
});
db.getCollection("terms").insert({
  "IEML": "wo.S:M:.-",
  "FR": "cultiver la variation de l'expérience du signe",
  "EN": "cultivate the variation of sign experience",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "bbaehaaaa"
  ],
  "_id": ObjectId("56772418b9fe1f5ab16a2a4d")
});
db.getCollection("terms").insert({
  "IEML": "wo.B:M:.-",
  "FR": "cultiver la variation de l'expérience de l'être",
  "EN": "cultivate the variation of being experience",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "bbafhaaaa"
  ],
  "_id": ObjectId("5677244cb9fe1f5ab16a2a52")
});
db.getCollection("terms").insert({
  "IEML": "wo.T:M:.-",
  "FR": "cultiver la variation de l'expérience de la chose",
  "EN": "cultivate the variation of thing experience",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "bbaghaaaa"
  ],
  "_id": ObjectId("56772471b9fe1f5ab16a2a57")
});
db.getCollection("terms").insert({
  "IEML": "wo.M:S:.-",
  "FR": "cultiver le signe de la variation de l'expérience",
  "EN": "cultivate the sign of experience variation",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "bbaheaaaa"
  ],
  "_id": ObjectId("567724b3b9fe1f5ab16a2a5c")
});
db.getCollection("terms").insert({
  "IEML": "wo.M:B:.-",
  "FR": "cultiver l'être de la variation de l'expérience",
  "EN": "cultivate the being of experience variation",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "bbahfaaaa"
  ],
  "_id": ObjectId("567724d3b9fe1f5ab16a2a61")
});
db.getCollection("terms").insert({
  "IEML": "wo.M:T:.-",
  "FR": "cultiver la chose de la variation de l'expérience",
  "EN": "cultivate the thing of experience variation",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "bbahgaaaa"
  ],
  "_id": ObjectId("567724f1b9fe1f5ab16a2a66")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bcaehaaaa"
  ],
  "CLASS": "2",
  "EN": "cultivate the strength of the action of sign",
  "FR": "cultiver la force de l'action du signe",
  "IEML": "wa.S:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("56772549b9fe1f5ab16a2a6b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bcafhaaaa"
  ],
  "CLASS": "2",
  "EN": "cultivate the strength of the action of being",
  "FR": "cultiver la force de l'action de l'être",
  "IEML": "wa.B:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("56772568b9fe1f5ab16a2a70")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bcaghaaaa"
  ],
  "CLASS": "2",
  "EN": "cultivate the strength of the action of thing",
  "FR": "cultiver la force de l'action de la chose",
  "IEML": "wa.T:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("56772587b9fe1f5ab16a2a75")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bcaheaaaa"
  ],
  "CLASS": "2",
  "EN": "cultivate the sign of action strength",
  "FR": "cultiver le signe de la force de l'action",
  "IEML": "wa.M:S:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("567725b5b9fe1f5ab16a2a7a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bcahfaaaa"
  ],
  "CLASS": "2",
  "EN": "cultivate the being of action strength",
  "FR": "cultiver l'être de la force de l'action",
  "IEML": "wa.M:B:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("56772680b9fe1f5ab16a2a7f")
});
db.getCollection("terms").insert({
  "IEML": "wa.M:T:.-",
  "FR": "cultiver la chose de la force de l'action",
  "EN": "cultivate the thing of action strength",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "bcahgaaaa"
  ],
  "_id": ObjectId("567726bcb9fe1f5ab16a2a84")
});
db.getCollection("terms").insert({
  "IEML": "wu.S:M:.-",
  "FR": "cultiver la subtilité de la perception du signe",
  "EN": "cultivate the subtlety of sign perception",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "cbaehaaaa"
  ],
  "_id": ObjectId("5677272db9fe1f5ab16a2a89")
});
db.getCollection("terms").insert({
  "IEML": "wu.B:M:.-",
  "FR": "cultiver la subtilité de la perception de l'être",
  "EN": "cultivate the subtlety of being perception",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "cbafhaaaa"
  ],
  "_id": ObjectId("56772754b9fe1f5ab16a2a8e")
});
db.getCollection("terms").insert({
  "IEML": "wu.T:M:.-",
  "FR": "cultiver la subtilité de la perception de la chose",
  "EN": "cultivate the subtlety of thing perception",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "cbaghaaaa"
  ],
  "_id": ObjectId("5677277bb9fe1f5ab16a2a93")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cbaheaaaa"
  ],
  "CLASS": "2",
  "EN": "cultivate the subtle sign of perception",
  "FR": "cultiver le signe subtil de la perception",
  "IEML": "wu.M:S:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("5677289eb9fe1f5ab16a2a98")
});
db.getCollection("terms").insert({
  "IEML": "wu.M:B:.-",
  "FR": "cultiver l'être subtil de la perception",
  "EN": "cultivate the subtle being of perception",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "cbahfaaaa"
  ],
  "_id": ObjectId("567728c0b9fe1f5ab16a2a9d")
});
db.getCollection("terms").insert({
  "IEML": "wu.M:T:.-",
  "FR": "cultiver la chose subtile de la perception",
  "EN": "cultivate the subtle thing of perception",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "cbahgaaaa"
  ],
  "_id": ObjectId("567728f8b9fe1f5ab16a2aa2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ccaehaaaa"
  ],
  "CLASS": "2",
  "EN": "cultivate a sustainable balance of sign",
  "FR": "cultiver un équilibre durable du signe",
  "IEML": "we.S:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("56772969b9fe1f5ab16a2aa7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ccafhaaaa"
  ],
  "CLASS": "2",
  "EN": "cultivate a sustainable balance of being",
  "FR": "cultiver un équilibre durable de l'être",
  "IEML": "we.B:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("5677298cb9fe1f5ab16a2aac")
});
db.getCollection("terms").insert({
  "IEML": "we.T:M:.-",
  "FR": "cultiver un équilibre durable de la chose",
  "EN": "cultivate a sustainable balance of thing",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "ccaghaaaa"
  ],
  "_id": ObjectId("567729bbb9fe1f5ab16a2ab1")
});
db.getCollection("terms").insert({
  "IEML": "we.M:S:.-",
  "FR": "cultiver le signe de l'équilibre",
  "EN": "cultivate the sign of balance",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "ccaheaaaa"
  ],
  "_id": ObjectId("56772a1db9fe1f5ab16a2ab6")
});
db.getCollection("terms").insert({
  "IEML": "we.M:B:.-",
  "FR": "cultiver l'être de l'équilibre",
  "EN": "cultivate the being of balance",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "ccahfaaaa"
  ],
  "_id": ObjectId("56772a37b9fe1f5ab16a2abb")
});
db.getCollection("terms").insert({
  "IEML": "we.M:T:.-",
  "FR": "cultiver la chose de l'équilibre",
  "EN": "cultivate the thing of balance",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "ccahgaaaa"
  ],
  "_id": ObjectId("56772a4fb9fe1f5ab16a2ac0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bdaegaaaa"
  ],
  "CLASS": "2",
  "EN": "virtual mastering of time",
  "FR": "maîtrise virtuelle du temps",
  "IEML": "U:O:.t.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("56772b46b9fe1f5ab16a2ac5")
});
db.getCollection("terms").insert({
  "IEML": "A:O:.t.-",
  "FR": "maîtrise actuelle du temps",
  "EN": "actual mastering of time",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "cdaegaaaa"
  ],
  "_id": ObjectId("56772b7cb9fe1f5ab16a2aca")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dbaegaaaa"
  ],
  "CLASS": "2",
  "EN": "mastering virtual time",
  "FR": "maîtrise du temps virtuel",
  "IEML": "O:U:.t.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("56772b97b9fe1f5ab16a2acf")
});
db.getCollection("terms").insert({
  "IEML": "O:A:.t.-",
  "FR": "maîtrise du temps actuel",
  "EN": "mastering actual time",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dcaegaaaa"
  ],
  "_id": ObjectId("56772bcdb9fe1f5ab16a2ad4")
});
db.getCollection("terms").insert({
  "IEML": "U:O:.b.-",
  "FR": "jeux virtuels de langage",
  "EN": "virtual language games",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "bdaefaaaa"
  ],
  "_id": ObjectId("56772c30b9fe1f5ab16a2ad9")
});
db.getCollection("terms").insert({
  "IEML": "A:O:.b.-",
  "FR": "jeux actuels de langage",
  "EN": "actual language games",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "cdaefaaaa"
  ],
  "_id": ObjectId("56772c4cb9fe1f5ab16a2ade")
});
db.getCollection("terms").insert({
  "IEML": "O:U:.b.-",
  "FR": "jeux de langages virtuels",
  "EN": "games of virtual languages",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dbaefaaaa"
  ],
  "_id": ObjectId("56772c9eb9fe1f5ab16a2ae3")
});
db.getCollection("terms").insert({
  "IEML": "O:A:.b.-",
  "FR": "jeux de langages actuels",
  "EN": "games of actual languages",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dcaefaaaa"
  ],
  "_id": ObjectId("56772cc0b9fe1f5ab16a2ae8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bdaeeaaaa"
  ],
  "CLASS": "2",
  "EN": "virtual intellectual openness",
  "FR": "ouverture intellectuelle virtuelle",
  "IEML": "U:O:.s.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("56772d46b9fe1f5ab16a2aed")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cdaeeaaaa"
  ],
  "CLASS": "2",
  "EN": "actual intellectual openness",
  "FR": "ouverture intellectuelle actuelle",
  "IEML": "A:O:.s.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("56772d62b9fe1f5ab16a2af2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dbaeeaaaa"
  ],
  "CLASS": "2",
  "EN": "intellectual openness to the virtual",
  "FR": "ouverture intellectuelle au virtuel",
  "IEML": "O:U:.s.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("56772d88b9fe1f5ab16a2af7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dcaeeaaaa"
  ],
  "CLASS": "2",
  "EN": "intellectual openness to the actual",
  "FR": "ouverture intellectuelle à l'actuel",
  "IEML": "O:A:.s.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("56772da5b9fe1f5ab16a2afc")
});
db.getCollection("terms").insert({
  "IEML": "U:O:.k.-",
  "FR": "générosité virtuelle",
  "EN": "virtual generosity",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "bdafeaaaa"
  ],
  "_id": ObjectId("56772e8cb9fe1f5ab16a2b01")
});
db.getCollection("terms").insert({
  "IEML": "A:O:.k.-",
  "FR": "générosité actuelle",
  "EN": "actual generosity",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "cdafeaaaa"
  ],
  "_id": ObjectId("56772ea2b9fe1f5ab16a2b06")
});
db.getCollection("terms").insert({
  "IEML": "O:U:.k.-",
  "FR": "générosité pour le virtuel",
  "EN": "generosity for the virtual",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dbafeaaaa"
  ],
  "_id": ObjectId("56772edab9fe1f5ab16a2b0b")
});
db.getCollection("terms").insert({
  "IEML": "O:A:.k.-",
  "FR": "générosité pour l'actuel",
  "EN": "generosity for the actual",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dcafeaaaa"
  ],
  "_id": ObjectId("56772ef6b9fe1f5ab16a2b10")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bdaffaaaa"
  ],
  "CLASS": "2",
  "EN": "provide resources for action by virtualizing emotions",
  "FR": "fournir des ressources à l'action en virtualisant les émotions",
  "IEML": "U:O:.m.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("56772f6ab9fe1f5ab16a2b15")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cdaffaaaa"
  ],
  "CLASS": "2",
  "EN": "provide resources for action by actualizing emotions",
  "FR": "fournir des ressources à  l'action en actualisant les émotions",
  "IEML": "A:O:.m.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("56772f7fb9fe1f5ab16a2b1a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dcaffaaaa"
  ],
  "CLASS": "2",
  "EN": "provide resources for action through the actual fluidity of emotions",
  "FR": "fournir des ressources à l'action par la fluidité actuelle des émotions",
  "IEML": "O:A:.m.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("56772fd3b9fe1f5ab16a2b1f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dbaffaaaa"
  ],
  "CLASS": "2",
  "EN": "provide resources for action through the virtual fluidity of emotions",
  "FR": "fournir des ressources à l'action par la fluidité virtuelle des émotions",
  "IEML": "O:U:.m.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("56772ff5b9fe1f5ab16a2b24")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bdafgaaaa"
  ],
  "CLASS": "2",
  "EN": "virtual resonance with the cosmos",
  "FR": "résonance virtuelle avec le cosmos",
  "IEML": "U:O:.n.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("56773196b9fe1f5ab16a2b29")
});
db.getCollection("terms").insert({
  "IEML": "A:O:.n.-",
  "FR": "résonance actuelle avec le cosmos",
  "EN": "actual resonance with the cosmos",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "cdafgaaaa"
  ],
  "_id": ObjectId("567731d3b9fe1f5ab16a2b2e")
});
db.getCollection("terms").insert({
  "IEML": "O:U:.n.-",
  "FR": "résonance avec le cosmos virtuel",
  "EN": "resonance with the virtual cosmos",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dbafgaaaa"
  ],
  "_id": ObjectId("567731feb9fe1f5ab16a2b33")
});
db.getCollection("terms").insert({
  "IEML": "O:A:.n.-",
  "FR": "résonance avec le cosmos actuel",
  "EN": "resonance with the actual cosmos",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dcafgaaaa"
  ],
  "_id": ObjectId("56773221b9fe1f5ab16a2b38")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "bdageaaaa"
  ],
  "CLASS": "2",
  "EN": "provide resources for action through a virtual quest for truth",
  "FR": "fournir des ressources à  l'action par la quête virtuelle de vérité",
  "IEML": "U:O:.d.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("567733b4b9fe1f5ab16a2b3d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "cdageaaaa"
  ],
  "CLASS": "2",
  "EN": "provide resources for action through an actual quest of truth",
  "FR": "fournir des ressources à  l'action par la quête actuelle de vérité",
  "IEML": "A:O:.d.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("567733d2b9fe1f5ab16a2b42")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dbageaaaa"
  ],
  "CLASS": "2",
  "EN": "provide resources for action through a quest of virtual truth",
  "FR": "fournir des ressources à  l'action par la quête de vérité virtuelle",
  "IEML": "O:U:.d.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("56773404b9fe1f5ab16a2b47")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dcageaaaa"
  ],
  "CLASS": "2",
  "EN": "provide resources for action through a quest of actual truth",
  "FR": "fournir des ressources à  l'action par la quête de vérité actuelle",
  "IEML": "O:A:.d.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("5677341eb9fe1f5ab16a2b4c")
});
db.getCollection("terms").insert({
  "IEML": "U:O:.f.-",
  "FR": "rapport virtuel au corps",
  "EN": "virtual relation to the body",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "bdagfaaaa"
  ],
  "_id": ObjectId("567734f5b9fe1f5ab16a2b51")
});
db.getCollection("terms").insert({
  "IEML": "A:O:.f.-",
  "FR": "rapport actuel au corps",
  "EN": "actual relation to the body",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "cdagfaaaa"
  ],
  "_id": ObjectId("5677350db9fe1f5ab16a2b56")
});
db.getCollection("terms").insert({
  "IEML": "O:U:.f.-",
  "FR": "relation au corps virtuel",
  "EN": "relation to the virtual body",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dbagfaaaa"
  ],
  "_id": ObjectId("56773529b9fe1f5ab16a2b5b")
});
db.getCollection("terms").insert({
  "IEML": "O:A:.f.-",
  "FR": "relation au corps actuel",
  "EN": "relation to the actual body",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "dcagfaaaa"
  ],
  "_id": ObjectId("56773542b9fe1f5ab16a2b60")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dcaggaaaa"
  ],
  "CLASS": "2",
  "EN": "actual extension of the space",
  "FR": "extension actuelle de l'espace",
  "IEML": "O:A:.l.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("567735f7b9fe1f5ab16a2b65")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "dbaggaaaa"
  ],
  "CLASS": "2",
  "EN": "virtual extension of the space",
  "FR": "extension virtuelle de l'espace",
  "IEML": "O:U:.l.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("56773657b9fe1f5ab16a2b6a")
});
db.getCollection("terms").insert({
  "IEML": "A:O:.l.-",
  "FR": "extension de l'espace actuel",
  "EN": "extension of the actual space",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "cdaggaaaa"
  ],
  "_id": ObjectId("567736f6b9fe1f5ab16a2b6f")
});
db.getCollection("terms").insert({
  "IEML": "U:O:.l.-",
  "FR": "extension de l'espace virtuel",
  "EN": "extension of the virtual space",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "2",
  "TAILLE": "2",
  "CANONICAL": [
    "bdaggaaaa"
  ],
  "_id": ObjectId("5677370fb9fe1f5ab16a2b74")
});
db.getCollection("terms").insert({
  "IEML": "O:.-S:M:.e.-'",
  "FR": "acquérir le trivium du signe",
  "EN": "gain the trivium of the sign",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "2",
  "TAILLE": "6",
  "CANONICAL": [
    "daaaaaaaaehabgaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("56785cecb9fe1f5ab16a2b79")
});
db.getCollection("terms").insert({
  "IEML": "U:.-S:M:.e.-'",
  "FR": "acquérir les compétences virtuelles du trivium du signe",
  "EN": "gain the virtual skills of the trivium of sign",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "baaaaaaaaehabgaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("56785d77b9fe1f5ab16a2b7e")
});
db.getCollection("terms").insert({
  "IEML": "A:.-S:M:.e.-'",
  "FR": "acquérir les compétences actuelles du trivium du signe",
  "EN": "gain the actual skills of the trivium of sign",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "caaaaaaaaehabgaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("56785da8b9fe1f5ab16a2b83")
});
db.getCollection("terms").insert({
  "IEML": "O:.-B:M:.e.-'",
  "FR": "acquérir le trivium de l'être",
  "EN": "gain the trivium of being",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "2",
  "TAILLE": "6",
  "CANONICAL": [
    "daaaaaaaafhabgaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("56785e0eb9fe1f5ab16a2b88")
});
db.getCollection("terms").insert({
  "IEML": "U:.-B:M:.e.-'",
  "FR": "acquérir les compétences virtuelles du trivium de l'être",
  "EN": "gain the virtual skills of the trivium of being",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "baaaaaaaafhabgaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("56785e58b9fe1f5ab16a2b8d")
});
db.getCollection("terms").insert({
  "IEML": "A:.-B:M:.e.-'",
  "FR": "acquérir les compétences actuelles du trivium de l'être",
  "EN": "gain the actual skills of the trivium of being",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "caaaaaaaafhabgaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("56785e7cb9fe1f5ab16a2b92")
});
db.getCollection("terms").insert({
  "IEML": "O:.-T:M:.e.-'",
  "FR": "acquérir le trivium de la chose",
  "EN": "gain the trivium of the thing",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "2",
  "TAILLE": "6",
  "CANONICAL": [
    "daaaaaaaaghabgaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("56785f43b9fe1f5ab16a2b97")
});
db.getCollection("terms").insert({
  "IEML": "U:.-T:M:.e.-'",
  "FR": "acquérir les compétences virtuelles du trivium de la chose",
  "EN": "gain the virtual skills of the trivium of thing",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "baaaaaaaaghabgaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("56786095b9fe1f5ab16a2b9c")
});
db.getCollection("terms").insert({
  "IEML": "A:.-T:M:.e.-'",
  "FR": "acquérir les compétences actuelles du trivium de la chose",
  "EN": "gain the actual skills of the trivium of thing",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "caaaaaaaaghabgaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567860b8b9fe1f5ab16a2ba1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "daaaaaaaaheabgaaaaaaaaaaaaa"
  ],
  "CLASS": "2",
  "EN": "learn the grammar of the generalized trivium",
  "FR": "apprendre la grammaire du trivium généralisé",
  "IEML": "O:.-M:S:.e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("567860f7b9fe1f5ab16a2ba6")
});
db.getCollection("terms").insert({
  "IEML": "U:.-M:S:.e.-'",
  "FR": "apprendre la grammaire virtuelle du trivium généralisé",
  "EN": "learn the virtual grammar of the generalized trivium",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "baaaaaaaaheabgaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("56786179b9fe1f5ab16a2bab")
});
db.getCollection("terms").insert({
  "IEML": "A:.-M:S:.e.-'",
  "FR": "apprendre la grammaire actuelle du trivium généralisé",
  "EN": "learn the actual grammar of the generalized trivium",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "caaaaaaaaheabgaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567861a9b9fe1f5ab16a2bb0")
});
db.getCollection("terms").insert({
  "IEML": "O:.-M:B:.e.-'",
  "FR": "apprendre la dialectique du trivium généralisé",
  "EN": "learn the dialectic of the generalized trivium",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "2",
  "TAILLE": "6",
  "CANONICAL": [
    "daaaaaaaahfabgaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567861fbb9fe1f5ab16a2bb5")
});
db.getCollection("terms").insert({
  "IEML": "U:.-M:B:.e.-'",
  "FR": "apprendre la dialectique virtuelle du trivium généralisé",
  "EN": "learn the virtual dialectic of the generalized trivium",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "baaaaaaaahfabgaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567862d8b9fe1f5ab16a2bba")
});
db.getCollection("terms").insert({
  "IEML": "A:.-M:B:.e.-'",
  "FR": "apprendre la dialectique actuelle du trivium généralisé",
  "EN": "learn the actual dialectic of the generalized trivium",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "caaaaaaaahfabgaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("56786304b9fe1f5ab16a2bbf")
});
db.getCollection("terms").insert({
  "IEML": "O:.-M:T:.e.-'",
  "FR": "apprendre la rhétorique du trivium généralisé",
  "EN": "learn the rhetoric of the generalized trivium",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "2",
  "TAILLE": "6",
  "CANONICAL": [
    "daaaaaaaahgabgaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("5678634ab9fe1f5ab16a2bc4")
});
db.getCollection("terms").insert({
  "IEML": "U:.-M:T:.e.-'",
  "FR": "apprendre la rhétorique virtuelle du trivium généralisé",
  "EN": "learn the virtual rhetoric of the generalized trivium",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "baaaaaaaahgabgaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567863c4b9fe1f5ab16a2bc9")
});
db.getCollection("terms").insert({
  "IEML": "A:.-M:T:.e.-'",
  "FR": "apprendre la rhétorique actuelle du trivium généralisé",
  "EN": "learn the actual rhetoric of the generalized trivium",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "2",
  "TAILLE": "3",
  "CANONICAL": [
    "caaaaaaaahgabgaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567863edb9fe1f5ab16a2bce")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfaaaaaaahaadaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "tastes",
  "FR": "goûts",
  "IEML": "f.-M:.O:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("567869dab9fe1f5ab16a2bda")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaaaaaaahaadaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "visual qualities",
  "FR": "qualités visuelles",
  "IEML": "b.-M:.O:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("56787a0eb9fe1f5ab16a2bdf")
});
db.getCollection("terms").insert({
  "IEML": "k.-S:.U:.-'",
  "FR": "bruit auditif",
  "EN": "auditive noise",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "feaaaaaaaeaabaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("56787c77b9fe1f5ab16a2be4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hfadhaaaa"
  ],
  "CLASS": "4",
  "EN": "human development becoming being",
  "FR": "devenir être du développement humain",
  "IEML": "M:B:.O:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "18",
  "_id": ObjectId("5679a9adb9fe1f5ab16a2c0a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hgadhaaaa"
  ],
  "CLASS": "4",
  "EN": "human development becoming thing",
  "FR": "devenir chose du développement humain",
  "IEML": "M:T:.O:M:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "18",
  "_id": ObjectId("5679aa3fb9fe1f5ab16a2c0f")
});
db.getCollection("terms").insert({
  "IEML": "M:M:.O:B:.-",
  "FR": "développement humain de l'être",
  "EN": "human development of the being",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "18",
  "CANONICAL": [
    "hhadfaaaa"
  ],
  "_id": ObjectId("5679b550b9fe1f5ab16a2c1e")
});
db.getCollection("terms").insert({
  "IEML": "M:M:.O:T:.-",
  "FR": "développement humain de la chose",
  "EN": "human development of the thing",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "18",
  "CANONICAL": [
    "hhadgaaaa"
  ],
  "_id": ObjectId("5679b58eb9fe1f5ab16a2c23")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaaaaaaaeaacaaaaaaaaaaaaaaiaaiaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "colors",
  "FR": "couleurs",
  "IEML": "b.-S:.A:.-'F:.F:.-',",
  "LAYER": "4",
  "PARADIGM": "1",
  "TAILLE": "25",
  "_id": ObjectId("5679b9f9b9fe1f5ab16a2c28")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaaaaaaaeaacaaaaaaaaaaaaaaiaagaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "reddish",
  "FR": "tirant sur le rouge",
  "IEML": "b.-S:.A:.-'F:.T:.-',",
  "LAYER": "4",
  "PARADIGM": "0",
  "TAILLE": "5",
  "_id": ObjectId("5679bc45b9fe1f5ab16a2c52")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaaaaaaaeaacaaaaaaaaaaaaaaiaafaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "yellowish",
  "FR": "tirant sur le jaune",
  "IEML": "b.-S:.A:.-'F:.B:.-',",
  "LAYER": "4",
  "PARADIGM": "0",
  "TAILLE": "5",
  "_id": ObjectId("5679bc5cb9fe1f5ab16a2c59")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaaaaaaaeaacaaaaaaaaaaaaaaiaaeaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "blueish",
  "FR": "tirant sur le bleu",
  "IEML": "b.-S:.A:.-'F:.S:.-',",
  "LAYER": "4",
  "PARADIGM": "0",
  "TAILLE": "5",
  "_id": ObjectId("5679bc75b9fe1f5ab16a2c60")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaaaaaaaeaacaaaaaaaaaaaaaaiaabaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "white leaning",
  "FR": "tirant sur le blanc",
  "IEML": "b.-S:.A:.-'F:.U:.-',",
  "LAYER": "4",
  "PARADIGM": "0",
  "TAILLE": "5",
  "_id": ObjectId("5679bd14b9fe1f5ab16a2c67")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaaaaaaaeaacaaaaaaaaaaaaaaiaacaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "blackish",
  "FR": "tirant sur le noir",
  "IEML": "b.-S:.A:.-'F:.A:.-',",
  "LAYER": "4",
  "PARADIGM": "0",
  "TAILLE": "5",
  "_id": ObjectId("5679bd99b9fe1f5ab16a2c6e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaaaaaaaeaacaaaaaaaaaaaaaabaabaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "shining white",
  "FR": "blanc éclatant",
  "IEML": "b.-S:.A:.-'U:.U:.-',",
  "LAYER": "4",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("5679bdc7b9fe1f5ab16a2c75")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaaaaaaaeaacaaaaaaaaaaaaaabaacaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "clear grey",
  "FR": "gris clair",
  "IEML": "b.-S:.A:.-'U:.A:.-',",
  "LAYER": "4",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("5679be11b9fe1f5ab16a2c7c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaaaaaaaeaacaaaaaaaaaaaaaacaabaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "dark grey",
  "FR": "gris foncé",
  "IEML": "b.-S:.A:.-'A:.U:.-',",
  "LAYER": "4",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("5679be2bb9fe1f5ab16a2c83")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaaaaaaaeaacaaaaaaaaaaaaaacaacaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "ink black",
  "FR": "noir d'encre",
  "IEML": "b.-S:.A:.-'A:.A:.-',",
  "LAYER": "4",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("5679be4eb9fe1f5ab16a2c8a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaaaaaaaeaacaaaaaaaaaaaaaabaaeaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "blueish white",
  "FR": "blanc bleuté",
  "IEML": "b.-S:.A:.-'U:.S:.-',",
  "LAYER": "4",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("5679be7fb9fe1f5ab16a2c91")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaaaaaaaeaacaaaaaaaaaaaaaabaafaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "beige white",
  "FR": "blanc beige",
  "IEML": "b.-S:.A:.-'U:.B:.-',",
  "LAYER": "4",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("5679bea1b9fe1f5ab16a2c98")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaaaaaaaeaacaaaaaaaaaaaaaaeaaeaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "royal blue",
  "FR": "bleu roi",
  "IEML": "b.-S:.A:.-'S:.S:.-',",
  "LAYER": "4",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("5679c81db9fe1f5ab16a2ca6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaaaaaaaeaacaaaaaaaaaaaaaafaafaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "gold yellow",
  "FR": "jaune d'or",
  "IEML": "b.-S:.A:.-'B:.B:.-',",
  "LAYER": "4",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("5679c83bb9fe1f5ab16a2cad")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaaaaaaaeaacaaaaaaaaaaaaaagaagaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "vermilion red",
  "FR": "rouge vermillon",
  "IEML": "b.-S:.A:.-'T:.T:.-',",
  "LAYER": "4",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("5679c8feb9fe1f5ab16a2cb4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaaaaaaaeaacaaaaaaaaaaaaaaeaabaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "light blue",
  "FR": "bleu clair",
  "IEML": "b.-S:.A:.-'S:.U:.-',",
  "LAYER": "4",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("5679c97ab9fe1f5ab16a2cbb")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaaaaaaaeaacaaaaaaaaaaaaaafaabaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "light yellow",
  "FR": "jaune clair",
  "IEML": "b.-S:.A:.-'B:.U:.-',",
  "LAYER": "4",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("5679c9a8b9fe1f5ab16a2cc2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaaaaaaaeaacaaaaaaaaaaaaaagaabaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "pink",
  "FR": "rose",
  "IEML": "b.-S:.A:.-'T:.U:.-',",
  "LAYER": "4",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("5679c9c8b9fe1f5ab16a2cc9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaaaaaaaeaacaaaaaaaaaaaaaagaacaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "red brown",
  "FR": "brun rouge",
  "IEML": "b.-S:.A:.-'T:.A:.-',",
  "LAYER": "4",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("5679c9ecb9fe1f5ab16a2cd0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaaaaaaaeaacaaaaaaaaaaaaaagaaeaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "purple",
  "FR": "violet",
  "IEML": "b.-S:.A:.-'T:.S:.-',",
  "LAYER": "4",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("5679ca2bb9fe1f5ab16a2cd7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaaaaaaaeaacaaaaaaaaaaaaaagaafaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "orange red",
  "FR": "rouge orangé",
  "IEML": "b.-S:.A:.-'T:.B:.-',",
  "LAYER": "4",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("5679ca49b9fe1f5ab16a2cde")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaaaaaaaeaacaaaaaaaaaaaaaacaaeaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "blue-black",
  "FR": "noir bleuté",
  "IEML": "b.-S:.A:.-'A:.S:.-',",
  "LAYER": "4",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("5679cad6b9fe1f5ab16a2ce5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaaaaaaaeaacaaaaaaaaaaaaaafaaeaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "yellow green",
  "FR": "jaune vert",
  "IEML": "b.-S:.A:.-'B:.S:.-',",
  "LAYER": "4",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("5679cb06b9fe1f5ab16a2cec")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaaaaaaaeaacaaaaaaaaaaaaaaeaafaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "blue green",
  "FR": "bleu vert",
  "IEML": "b.-S:.A:.-'S:.B:.-',",
  "LAYER": "4",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("5679cb2db9fe1f5ab16a2cf3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaaaaaaaeaacaaaaaaaaaaaaaaeaagaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "indigo",
  "FR": "indigo",
  "IEML": "b.-S:.A:.-'S:.T:.-',",
  "LAYER": "4",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("5679cba0b9fe1f5ab16a2cfa")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaaaaaaaeaacaaaaaaaaaaaaaafaagaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "orange yellow",
  "FR": "jaune orangé",
  "IEML": "b.-S:.A:.-'B:.T:.-',",
  "LAYER": "4",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("5679cbc4b9fe1f5ab16a2d01")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaaaaaaaeaacaaaaaaaaaaaaaacaagaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "brown black",
  "FR": "noir brun",
  "IEML": "b.-S:.A:.-'A:.T:.-',",
  "LAYER": "4",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("5679cc13b9fe1f5ab16a2d08")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaaaaaaaeaacaaaaaaaaaaaaaafaacaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "dark beige",
  "FR": "beige foncé",
  "IEML": "b.-S:.A:.-'B:.A:.-',",
  "LAYER": "4",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("5679cd47b9fe1f5ab16a2d0f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaaaaaaaeaacaaaaaaaaaaaaaaeaacaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "night blue",
  "FR": "bleu nuit",
  "IEML": "b.-S:.A:.-'S:.A:.-',",
  "LAYER": "4",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("5679cf72b9fe1f5ab16a2d16")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaaaaaaaeaacaaaaaaaaaaaaaacaafaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "kaki black",
  "FR": "noir kaki",
  "IEML": "b.-S:.A:.-'A:.B:.-',",
  "LAYER": "4",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("5679cff4b9fe1f5ab16a2d1d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhaaaaaaadhaaaaaaaaaaaaaaaa",
    "hhaaaaaaadhaaaaaaaeeabeaaaa",
    "hhaaaaaaahdaaaaaaaaaaaaaaaa",
    "hhaaaaaaahdaaaaaaaeeabeaaaa"
  ],
  "CLASS": "4",
  "EN": "humanities, social sciences and their objects",
  "FR": "les sciences humaines et leurs objets",
  "IEML": "M:M:.-O:M:.-E:.-+s.y.-'+M:M:.-M:O:.-E:.-+s.y.-'",
  "LAYER": "3",
  "PARADIGM": "1",
  "TAILLE": "216",
  "_id": ObjectId("5679d984b9fe1f5ab16a2d24")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeaaaaaaadhaaaaaaaeeabeaaaa"
  ],
  "CLASS": "4",
  "EN": "reflexive studies (1)",
  "FR": "études réflexives (1)",
  "IEML": "s.-O:M:.-s.y.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("5679db40b9fe1f5ab16a2d25")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaaaaaaadhaaaaaaaeeabeaaaa"
  ],
  "CLASS": "4",
  "EN": "language studies (1)",
  "FR": "études du langage (1)",
  "IEML": "b.-O:M:.-s.y.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("5679db6db9fe1f5ab16a2d2c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egaaaaaaadhaaaaaaaeeabeaaaa"
  ],
  "CLASS": "4",
  "EN": "historical studies (1)",
  "FR": "études historiques (1)",
  "IEML": "t.-O:M:.-s.y.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("5679db87b9fe1f5ab16a2d33")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feaaaaaaadhaaaaaaaeeabeaaaa"
  ],
  "CLASS": "4",
  "EN": "social studies (1)",
  "FR": "études sociales (1)",
  "IEML": "k.-O:M:.-s.y.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("5679dbaab9fe1f5ab16a2d3a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffaaaaaaadhaaaaaaaeeabeaaaa"
  ],
  "CLASS": "4",
  "EN": "critical studies",
  "FR": "études critiques",
  "IEML": "m.-O:M:.-s.y.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("5679dbdcb9fe1f5ab16a2d41")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgaaaaaaadhaaaaaaaeeabeaaaa"
  ],
  "CLASS": "4",
  "EN": "cultural studies (1)",
  "FR": "études culturelles (1)",
  "IEML": "n.-O:M:.-s.y.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("5679dcc3b9fe1f5ab16a2d48")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geaaaaaaadhaaaaaaaeeabeaaaa"
  ],
  "CLASS": "4",
  "EN": "determination and measurement (1)",
  "FR": "détermination et mesure (1)",
  "IEML": "d.-O:M:.-s.y.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("5679dd63b9fe1f5ab16a2d4f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhaaaaaaadhaaaaaaaeeabeaaaa"
  ],
  "CLASS": "4",
  "EN": "human sciences (1)",
  "FR": "sciences humaines (1)",
  "IEML": "M:M:.-O:M:.-s.y.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "54",
  "_id": ObjectId("5679de54b9fe1f5ab16a2d56")
});
db.getCollection("terms").insert({
  "IEML": "M:M:.-M:O:.-s.y.-'",
  "FR": "sciences humaines (2)",
  "EN": "human sciences (2)",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "54",
  "CANONICAL": [
    "hhaaaaaaahdaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("5679ded4b9fe1f5ab16a2d5d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhaaaaaaabeaaaaaaaeeabeaaaa"
  ],
  "CLASS": "4",
  "EN": "knowledge studies",
  "FR": "études de la connaissance",
  "IEML": "M:M:.-y.-s.y.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("567b0163b83eaf1ceef1f34b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhaaaaaaabfaaaaaaaeeabeaaaa"
  ],
  "CLASS": "4",
  "EN": "political studies",
  "FR": "études politiques",
  "IEML": "M:M:.-o.-s.y.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("567b0204b83eaf1ceef1f355")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhaaaaaaabgaaaaaaaeeabeaaaa"
  ],
  "CLASS": "4",
  "EN": "economic studies",
  "FR": "études économiques",
  "IEML": "M:M:.-e.-s.y.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("567b0228b83eaf1ceef1f35f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhaaaaaaaceaaaaaaaeeabeaaaa"
  ],
  "CLASS": "4",
  "EN": "communication studies",
  "FR": "études de la communication",
  "IEML": "M:M:.-u.-s.y.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("567b0254b83eaf1ceef1f369")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhaaaaaaacfaaaaaaaeeabeaaaa"
  ],
  "CLASS": "4",
  "EN": "society studies",
  "FR": "études de la société",
  "IEML": "M:M:.-a.-s.y.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("567b027cb83eaf1ceef1f373")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhaaaaaaacgaaaaaaaeeabeaaaa"
  ],
  "CLASS": "4",
  "EN": "science and technology studies",
  "FR": "étude des sciences et technique",
  "IEML": "M:M:.-i.-s.y.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("567b02bcb83eaf1ceef1f37d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfaaaaaaadhaaaaaaaeeabeaaaa"
  ],
  "CLASS": "4",
  "EN": "life studies (1)",
  "FR": "études du vivant (1)",
  "IEML": "f.-O:M:.-s.y.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("567b0420b83eaf1ceef1f387")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggaaaaaaadhaaaaaaaeeabeaaaa"
  ],
  "CLASS": "4",
  "EN": "situated humanity studies (1)",
  "FR": "études de l'humanité située (1)",
  "IEML": "l.-O:M:.-s.y.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("567b0470b83eaf1ceef1f391")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeaaaaaaahdaaaaaaaeeabeaaaa"
  ],
  "CLASS": "4",
  "EN": "reflexive studies (2)",
  "FR": "études réflexives (2)",
  "IEML": "s.-M:O:.-s.y.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("567b04c0b83eaf1ceef1f39b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaaaaaaahdaaaaaaaeeabeaaaa"
  ],
  "CLASS": "4",
  "EN": "language studies (2)",
  "FR": "études du langage (2)",
  "IEML": "b.-M:O:.-s.y.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("567b04e4b83eaf1ceef1f3a5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egaaaaaaahdaaaaaaaeeabeaaaa"
  ],
  "CLASS": "4",
  "EN": "historical studies (2)",
  "FR": "études historiques (2)",
  "IEML": "t.-M:O:.-s.y.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("567b0500b83eaf1ceef1f3af")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feaaaaaaahdaaaaaaaeeabeaaaa"
  ],
  "CLASS": "4",
  "EN": "social studies (2)",
  "FR": "études sociales (2)",
  "IEML": "k.-M:O:.-s.y.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("567b0517b83eaf1ceef1f3b9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffaaaaaaahdaaaaaaaeeabeaaaa"
  ],
  "CLASS": "4",
  "EN": "affect studies",
  "FR": "étude des affects",
  "IEML": "m.-M:O:.-s.y.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("567b0530b83eaf1ceef1f3c3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgaaaaaaahdaaaaaaaeeabeaaaa"
  ],
  "CLASS": "4",
  "EN": "cultural studies (2)",
  "FR": "études culturelles (2)",
  "IEML": "n.-M:O:.-s.y.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("567b0554b83eaf1ceef1f3cd")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geaaaaaaahdaaaaaaaeeabeaaaa"
  ],
  "CLASS": "4",
  "EN": "determination and measurement (2)",
  "FR": "détermination et mesure (2)",
  "IEML": "d.-M:O:.-s.y.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("567b0567b83eaf1ceef1f3d7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfaaaaaaahdaaaaaaaeeabeaaaa"
  ],
  "CLASS": "4",
  "EN": "life studies (2)",
  "FR": "études du vivant (2)",
  "IEML": "f.-M:O:.-s.y.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("567b0579b83eaf1ceef1f3e1")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggaaaaaaahdaaaaaaaeeabeaaaa"
  ],
  "CLASS": "4",
  "EN": "situated humanity studies (2)",
  "FR": "études de l'humanité située (2)",
  "IEML": "l.-M:O:.-s.y.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("567b058cb83eaf1ceef1f3eb")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhaaaaaaaebaaaaaaaeeabeaaaa"
  ],
  "CLASS": "4",
  "EN": "art studies",
  "FR": "études des arts",
  "IEML": "M:M:.-j.-s.y.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("567b05efb83eaf1ceef1f3f5")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhaaaaaaaecaaaaaaaeeabeaaaa"
  ],
  "CLASS": "4",
  "EN": "methodology",
  "FR": "méthodologie",
  "IEML": "M:M:.-g.-s.y.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("567b0685b83eaf1ceef1f3ff")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhaaaaaaafbaaaaaaaeeabeaaaa"
  ],
  "CLASS": "4",
  "EN": "sacred | religion studies",
  "FR": "études du sacré | de la religion",
  "IEML": "M:M:.-h.-s.y.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("567b06b9b83eaf1ceef1f409")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhaaaaaaafcaaaaaaaeeabeaaaa"
  ],
  "CLASS": "4",
  "EN": "psyche studies",
  "FR": "études de la psychè",
  "IEML": "M:M:.-c.-s.y.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("567b06d2b83eaf1ceef1f413")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhaaaaaaagbaaaaaaaeeabeaaaa"
  ],
  "CLASS": "4",
  "EN": "law studies",
  "FR": "études juridiques",
  "IEML": "M:M:.-p.-s.y.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("567b06e8b83eaf1ceef1f41d")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhaaaaaaagcaaaaaaaeeabeaaaa"
  ],
  "CLASS": "4",
  "EN": "algorithmic studies (digital humanities)",
  "FR": "études algorithmiques (humanités digitales)",
  "IEML": "M:M:.-x.-s.y.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("567b070cb83eaf1ceef1f427")
});
db.getCollection("terms").insert({
  "IEML": "M:M:.o.-M:M:.o.-'",
  "FR": "fonctions anthropologiques",
  "EN": "anthropological functions",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "81",
  "CANONICAL": [
    "hhabfaaaahhabfaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567c38cfb83eaf1ceef1f431")
});
db.getCollection("terms").insert({
  "IEML": "s.-y.-s.y.-'",
  "FR": "épistémologie",
  "EN": "epistemology",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "eeaaaaaaabeaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567c73c2b83eaf1ceef1f442")
});
db.getCollection("terms").insert({
  "IEML": "s.-o.-s.y.-'",
  "FR": "philosophie politique",
  "EN": "political philosophy",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "eeaaaaaaabfaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567c73e0b83eaf1ceef1f44c")
});
db.getCollection("terms").insert({
  "IEML": "s.-e.-s.y.-'",
  "FR": "économie politique",
  "EN": "political economy",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "eeaaaaaaabgaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567c7405b83eaf1ceef1f456")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaaaaaaabeaaaaaaaeeabeaaaa"
  ],
  "CLASS": "4",
  "EN": "encyclopaedia, vulgarization",
  "FR": "encyclopédie, vulgarisation",
  "IEML": "b.-y.-s.y.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("567c742bb83eaf1ceef1f460")
});
db.getCollection("terms").insert({
  "IEML": "s.-u.-s.y.-'",
  "FR": "sémiologie",
  "EN": "semiology",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "eeaaaaaaaceaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567c746bb83eaf1ceef1f46a")
});
db.getCollection("terms").insert({
  "IEML": "s.-a.-s.y.-'",
  "FR": "sociologie générale",
  "EN": "general sociology",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "eeaaaaaaacfaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567c7489b83eaf1ceef1f474")
});
db.getCollection("terms").insert({
  "IEML": "s.-i.-s.y.-'",
  "FR": "philosophie de la technique",
  "EN": "philosophy of technology",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "eeaaaaaaacgaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567c74c0b83eaf1ceef1f47e")
});
db.getCollection("terms").insert({
  "IEML": "b.-o.-s.y.-'",
  "FR": "communication politique",
  "EN": "political communication",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "efaaaaaaabfaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567c7531b83eaf1ceef1f488")
});
db.getCollection("terms").insert({
  "IEML": "b.-e.-s.y.-'",
  "FR": "marketing, publicité",
  "EN": "marketing, advertisement",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "efaaaaaaabgaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567c7562b83eaf1ceef1f492")
});
db.getCollection("terms").insert({
  "IEML": "b.-u.-s.y.-'",
  "FR": "linguistique",
  "EN": "linguistics",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "efaaaaaaaceaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567c759fb83eaf1ceef1f49c")
});
db.getCollection("terms").insert({
  "IEML": "b.-a.-s.y.-'",
  "FR": "socio-linguistique, sociologie de la com.",
  "EN": "socio-linguistics, sociology of com.",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "efaaaaaaacfaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567c75e8b83eaf1ceef1f4a6")
});
db.getCollection("terms").insert({
  "IEML": "b.-i.-s.y.-'",
  "FR": "études techniques de communication",
  "EN": "communication technology studies",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "efaaaaaaacgaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567c763bb83eaf1ceef1f4b0")
});
db.getCollection("terms").insert({
  "IEML": "t.-y.-s.y.-'",
  "FR": "histoire des sciences",
  "EN": "history of sciences",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "egaaaaaaabeaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567c7688b83eaf1ceef1f4ba")
});
db.getCollection("terms").insert({
  "IEML": "t.-o.-s.y.-'",
  "FR": "histoire politique",
  "EN": "political history",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "egaaaaaaabfaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567c76abb83eaf1ceef1f4c4")
});
db.getCollection("terms").insert({
  "IEML": "t.-e.-s.y.-'",
  "FR": "histoire économique",
  "EN": "economic history",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "egaaaaaaabgaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567c76cab83eaf1ceef1f4ce")
});
db.getCollection("terms").insert({
  "IEML": "t.-u.-s.y.-'",
  "FR": "histoire de la communication",
  "EN": "history of communication",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "egaaaaaaaceaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567c76ebb83eaf1ceef1f4d8")
});
db.getCollection("terms").insert({
  "IEML": "t.-i.-s.y.-'",
  "FR": "histoire des techniques",
  "EN": "history of techniques",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "egaaaaaaacgaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567c772cb83eaf1ceef1f4ec")
});
db.getCollection("terms").insert({
  "IEML": "k.-y.-s.y.-'",
  "FR": "sociologie des sciences",
  "EN": "sociology of sciences",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "feaaaaaaabeaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567c7792b83eaf1ceef1f4f6")
});
db.getCollection("terms").insert({
  "IEML": "k.-o.-s.y.-'",
  "FR": "études mouvements socio-politiquess",
  "EN": "socio-political movements studies",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "feaaaaaaabfaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567c77d3b83eaf1ceef1f500")
});
db.getCollection("terms").insert({
  "IEML": "k.-u.-s.y.-'",
  "FR": "études des médias et de la communication sociale",
  "EN": "media studies | social communication studies",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "feaaaaaaaceaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567c784cb83eaf1ceef1f514")
});
db.getCollection("terms").insert({
  "IEML": "k.-a.-s.y.-'",
  "FR": "études de la société civile",
  "EN": "civil society studies",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "feaaaaaaacfaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567c7877b83eaf1ceef1f51e")
});
db.getCollection("terms").insert({
  "IEML": "m.-y.-s.y.-'",
  "FR": "critique scientifique",
  "EN": "scientific critique",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "ffaaaaaaabeaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567c79a8b83eaf1ceef1f532")
});
db.getCollection("terms").insert({
  "IEML": "m.-o.-s.y.-'",
  "FR": "critique politique",
  "EN": "political critique",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "ffaaaaaaabfaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567c79c7b83eaf1ceef1f53c")
});
db.getCollection("terms").insert({
  "IEML": "m.-e.-s.y.-'",
  "FR": "critique économique",
  "EN": "economic critique",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "ffaaaaaaabgaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567c79e0b83eaf1ceef1f546")
});
db.getCollection("terms").insert({
  "IEML": "m.-u.-s.y.-'",
  "FR": "critique des médias et de la communication",
  "EN": "media and communication critique",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "ffaaaaaaaceaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567c7a09b83eaf1ceef1f550")
});
db.getCollection("terms").insert({
  "IEML": "m.-a.-s.y.-'",
  "FR": "critique sociale",
  "EN": "social critique",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "ffaaaaaaacfaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567c7a32b83eaf1ceef1f55a")
});
db.getCollection("terms").insert({
  "IEML": "m.-i.-s.y.-'",
  "FR": "critique de la techno-science",
  "EN": "critique of techno-science",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "ffaaaaaaacgaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567c7a4bb83eaf1ceef1f564")
});
db.getCollection("terms").insert({
  "IEML": "n.-y.-s.y.-'",
  "FR": "cosmologie, astronomie",
  "EN": "cosmology, astronomy",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "fgaaaaaaabeaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567c7a79b83eaf1ceef1f56e")
});
db.getCollection("terms").insert({
  "IEML": "n.-e.-s.y.-'",
  "FR": "ergonomie",
  "EN": "ergonomy",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "fgaaaaaaabgaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567c7af8b83eaf1ceef1f582")
});
db.getCollection("terms").insert({
  "IEML": "n.-u.-s.y.-'",
  "FR": "lexicologie, classifications",
  "EN": "lexicology, classifications",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "fgaaaaaaaceaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567c7b37b83eaf1ceef1f58c")
});
db.getCollection("terms").insert({
  "IEML": "n.-a.-s.y.-'",
  "FR": "anthropologie",
  "EN": "anthropology",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "fgaaaaaaacfaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567c7b69b83eaf1ceef1f596")
});
db.getCollection("terms").insert({
  "IEML": "n.-i.-s.y.-'",
  "FR": "études R&D, innovation",
  "EN": "R&D, innovation studies",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "fgaaaaaaacgaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567c7bb0b83eaf1ceef1f5a0")
});
db.getCollection("terms").insert({
  "IEML": "d.-y.-s.y.-'",
  "FR": "mathématique, logique",
  "EN": "mathematics, logic",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "geaaaaaaabeaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567c7c24b83eaf1ceef1f5aa")
});
db.getCollection("terms").insert({
  "IEML": "d.-e.-s.y.-'",
  "FR": "finance, comptabilité",
  "EN": "finance, accountancy",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "geaaaaaaabgaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567c7c8bb83eaf1ceef1f5be")
});
db.getCollection("terms").insert({
  "IEML": "d.-u.-s.y.-'",
  "FR": "sciences de l'information et de la documentation",
  "EN": "information sciences, documentation sciences",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "geaaaaaaaceaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567c7cc6b83eaf1ceef1f5c8")
});
db.getCollection("terms").insert({
  "IEML": "d.-a.-s.y.-'",
  "FR": "études du capital social",
  "EN": "social capital studies",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "geaaaaaaacfaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567c7ce6b83eaf1ceef1f5d2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geaaaaaaacgaaaaaaaeeabeaaaa"
  ],
  "CLASS": "4",
  "EN": "computing studies",
  "FR": "études de l'informatique",
  "IEML": "d.-i.-s.y.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("567c7d6cb83eaf1ceef1f5dc")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfaaaaaaabeaaaaaaaeeabeaaaa"
  ],
  "CLASS": "4",
  "EN": "evolution | biological studies",
  "FR": "théories de l'évolution | du vivant",
  "IEML": "f.-y.-s.y.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("567c7db2b83eaf1ceef1f5e6")
});
db.getCollection("terms").insert({
  "IEML": "f.-o.-s.y.-'",
  "FR": "étude des genres",
  "EN": "gender studies",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "gfaaaaaaabfaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567c7e31b83eaf1ceef1f5f0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfaaaaaaaceaaaaaaaeeabeaaaa"
  ],
  "CLASS": "4",
  "EN": "éloquence studies",
  "FR": "études de l'éloquence",
  "IEML": "f.-u.-s.y.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("567c7eecb83eaf1ceef1f604")
});
db.getCollection("terms").insert({
  "IEML": "f.-a.-s.y.-'",
  "FR": "démographie",
  "EN": "demography",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "gfaaaaaaacfaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567c7f09b83eaf1ceef1f60e")
});
db.getCollection("terms").insert({
  "IEML": "f.-i.-s.y.-'",
  "FR": "études des biotechnologies",
  "EN": "biotechnology studies",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "gfaaaaaaacgaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567c7f56b83eaf1ceef1f618")
});
db.getCollection("terms").insert({
  "IEML": "l.-o.-s.y.-'",
  "FR": "relation internationales, géopolitique",
  "EN": "international relations, geopolitics",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "ggaaaaaaabfaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567c8034b83eaf1ceef1f62c")
});
db.getCollection("terms").insert({
  "IEML": "l.-e.-s.y.-'",
  "FR": "géographie économique, commerce international",
  "EN": "economic geography, international trade",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "ggaaaaaaabgaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567c806bb83eaf1ceef1f636")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggaaaaaaaceaaaaaaaeeabeaaaa"
  ],
  "CLASS": "4",
  "EN": "transcultural studies (communications)",
  "FR": "études transculturelles (communications)",
  "IEML": "l.-u.-s.y.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("567c80a8b83eaf1ceef1f640")
});
db.getCollection("terms").insert({
  "IEML": "l.-a.-s.y.-'",
  "FR": "cartographie des réseaux sociaux",
  "EN": "social networks mapping",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "ggaaaaaaacfaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567c81beb83eaf1ceef1f64a")
});
db.getCollection("terms").insert({
  "IEML": "l.-i.-s.y.-'",
  "FR": "études sciences physique et moléculaire",
  "EN": "studies in physics and molecular sciences",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "ggaaaaaaacgaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567c822bb83eaf1ceef1f654")
});
db.getCollection("terms").insert({
  "IEML": "s.-j.-s.y.-'",
  "FR": "esthétique",
  "EN": "aesthetics",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "eeaaaaaaaebaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567d9d62b83eaf1ceef1f65e")
});
db.getCollection("terms").insert({
  "IEML": "s.-h.-s.y.-'",
  "FR": "théologie",
  "EN": "theology",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "eeaaaaaaafbaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567da035b83eaf1ceef1f672")
});
db.getCollection("terms").insert({
  "IEML": "s.-c.-s.y.-'",
  "FR": "philosophie de l'esprit",
  "EN": "philosophy of mind",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "eeaaaaaaafcaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567da061b83eaf1ceef1f67c")
});
db.getCollection("terms").insert({
  "IEML": "s.-p.-s.y.-'",
  "FR": "philosophie du droit",
  "EN": "philosophy of law",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "eeaaaaaaagbaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567da094b83eaf1ceef1f686")
});
db.getCollection("terms").insert({
  "IEML": "s.-x.-s.y.-'",
  "FR": "philosophie du médium algorithmique",
  "EN": "algorithmic medium philosophy",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "eeaaaaaaagcaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567da0d9b83eaf1ceef1f690")
});
db.getCollection("terms").insert({
  "IEML": "b.-j.-s.y.-'",
  "FR": "études littérature, cinéma, musique",
  "EN": "literature, music, film studies",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "efaaaaaaaebaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567db053b83eaf1ceef1f69a")
});
db.getCollection("terms").insert({
  "IEML": "t.-j.-s.y.-'",
  "FR": "histoire de l'art | de la littérature",
  "EN": "art | literature history",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "egaaaaaaaebaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567db1abb83eaf1ceef1f6a4")
});
db.getCollection("terms").insert({
  "IEML": "k.-j.-s.y.-'",
  "FR": "sociologie de l'art | de la littérature",
  "EN": "art | literature sociology",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "feaaaaaaaebaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567db1e2b83eaf1ceef1f6ae")
});
db.getCollection("terms").insert({
  "IEML": "m.-j.-s.y.-'",
  "FR": "critique littérature | art",
  "EN": "art | literature critique",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "ffaaaaaaaebaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567db232b83eaf1ceef1f6b8")
});
db.getCollection("terms").insert({
  "IEML": "n.-j.-s.y.-'",
  "FR": "folklore, art | litterature comparée",
  "EN": "folklore, compared art | literature",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "fgaaaaaaaebaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567db281b83eaf1ceef1f6c2")
});
db.getCollection("terms").insert({
  "IEML": "d.-j.-s.y.-'",
  "FR": "muséologie",
  "EN": "museology",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "geaaaaaaaebaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567db301b83eaf1ceef1f6cc")
});
db.getCollection("terms").insert({
  "IEML": "f.-j.-s.y.-'",
  "FR": "études arts de la performance",
  "EN": "performing arts studies",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "gfaaaaaaaebaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567db325b83eaf1ceef1f6d6")
});
db.getCollection("terms").insert({
  "IEML": "t.-g.-s.y.-'",
  "FR": "études longitudinales",
  "EN": "longitudinal studies",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "egaaaaaaaecaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567db3efb83eaf1ceef1f6f4")
});
db.getCollection("terms").insert({
  "IEML": "k.-g.-s.y.-'",
  "FR": "enquêtes par groupes de discussion",
  "EN": "focus groups",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "feaaaaaaaecaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567db469b83eaf1ceef1f6fe")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feaaaaaaafbaaaaaaaeeabeaaaa"
  ],
  "CLASS": "4",
  "EN": "ecclesiology | religious communitity studies",
  "FR": "ecclésiologie | étude des communautés religieuse",
  "IEML": "k.-h.-s.y.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("567db4afb83eaf1ceef1f708")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feaaaaaaafcaaaaaaaeeabeaaaa"
  ],
  "CLASS": "4",
  "EN": "social psychology",
  "FR": "psychologie sociale",
  "IEML": "k.-c.-s.y.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("567db4cdb83eaf1ceef1f712")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feaaaaaaagbaaaaaaaeeabeaaaa"
  ],
  "CLASS": "4",
  "EN": "criminology",
  "FR": "criminologie",
  "IEML": "k.-p.-s.y.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("567db4e9b83eaf1ceef1f71c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "feaaaaaaagcaaaaaaaeeabeaaaa"
  ],
  "CLASS": "4",
  "EN": "conversation | recommandation (studies)",
  "FR": "conversation | recommandation (études)",
  "IEML": "k.-x.-s.y.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("567db543b83eaf1ceef1f726")
});
db.getCollection("terms").insert({
  "IEML": "m.-g.-s.y.-'",
  "FR": "sondages | enquêtes d'opinions",
  "EN": "surveys | opinion polls",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "ffaaaaaaaecaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567db583b83eaf1ceef1f730")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geaaaaaaaecaaaaaaaeeabeaaaa"
  ],
  "CLASS": "4",
  "EN": "quantitative | statistical methods",
  "FR": "méthodes quantitatives | statistiques",
  "IEML": "d.-g.-s.y.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("567db6c5b83eaf1ceef1f744")
});
db.getCollection("terms").insert({
  "IEML": "f.-g.-s.y.-'",
  "FR": "méthodes participatives, ethnométhodologie-",
  "EN": "participatory methods, ethnomethodology-",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "gfaaaaaaaecaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567db741b83eaf1ceef1f74e")
});
db.getCollection("terms").insert({
  "IEML": "b.-h.-s.y.-'",
  "FR": "herméneutique",
  "EN": "hermeneutics",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "efaaaaaaafbaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567db795b83eaf1ceef1f762")
});
db.getCollection("terms").insert({
  "IEML": "m.-h.-s.y.-'",
  "FR": "hagiographie | martyrologie",
  "EN": "hagiography | martyrology",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "ffaaaaaaafbaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567db884b83eaf1ceef1f776")
});
db.getCollection("terms").insert({
  "IEML": "d.-h.-s.y.-'",
  "FR": "études lois religieuses",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "geaaaaaaafbaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567db902b83eaf1ceef1f78a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfaaaaaaafbaaaaaaaeeabeaaaa"
  ],
  "CLASS": "4",
  "EN": "spiritual teaching",
  "FR": "enseignements spirituels",
  "IEML": "f.-h.-s.y.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("567dbaeab83eaf1ceef1f794")
});
db.getCollection("terms").insert({
  "IEML": "l.-h.-s.y.-'",
  "FR": "géographie sacrée",
  "EN": "sacred geography",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "ggaaaaaaafbaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567dbbc5b83eaf1ceef1f79e")
});
db.getCollection("terms").insert({
  "IEML": "t.-c.-s.y.-'",
  "FR": "études biographiques",
  "EN": "biographic studies",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "egaaaaaaafcaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567dbe56b83eaf1ceef1f7b2")
});
db.getCollection("terms").insert({
  "IEML": "n.-c.-s.y.-'",
  "FR": "psychologie des profondeurs, psychanalyse",
  "EN": "depth psychology, psychoanalysis",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "fgaaaaaaafcaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567dbfdeb83eaf1ceef1f7c6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geaaaaaaafcaaaaaaaeeabeaaaa"
  ],
  "CLASS": "4",
  "EN": "cognitive psychology",
  "FR": "psychologie cognitive",
  "IEML": "d.-c.-s.y.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("567dc084b83eaf1ceef1f7d0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfaaaaaaafcaaaaaaaeeabeaaaa"
  ],
  "CLASS": "4",
  "EN": "psychosomatic medicine",
  "FR": "médecine psychosomatique",
  "IEML": "f.-c.-s.y.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("567dc0aeb83eaf1ceef1f7da")
});
db.getCollection("terms").insert({
  "IEML": "l.-c.-s.y.-'",
  "FR": "études habitation | tourisme",
  "EN": "habitation | tourism studies",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "ggaaaaaaafcaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567dc0f8b83eaf1ceef1f7e4")
});
db.getCollection("terms").insert({
  "IEML": "b.-p.-s.y.-'",
  "FR": "études jurisprudence",
  "EN": "jurisprudence studies",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "efaaaaaaagbaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567dc1e8b83eaf1ceef1f7ee")
});
db.getCollection("terms").insert({
  "IEML": "t.-p.-s.y.-'",
  "FR": "histoire du droit",
  "EN": "history of law",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "egaaaaaaagbaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567dc219b83eaf1ceef1f7f8")
});
db.getCollection("terms").insert({
  "IEML": "m.-p.-s.y.-'",
  "FR": "sciences de la médiation",
  "EN": "mediation studies",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "ffaaaaaaagbaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567dc25bb83eaf1ceef1f802")
});
db.getCollection("terms").insert({
  "IEML": "n.-p.-s.y.-'",
  "FR": "éthique, déontologie, droits humains (études)",
  "EN": "ethics, deontology, human rights (studies)",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "fgaaaaaaagbaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567dc2a8b83eaf1ceef1f80c")
});
db.getCollection("terms").insert({
  "IEML": "d.-p.-s.y.-'",
  "FR": "sciences médico-légales",
  "EN": "forensic science",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "geaaaaaaagbaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567dc303b83eaf1ceef1f816")
});
db.getCollection("terms").insert({
  "IEML": "f.-p.-s.y.-'",
  "FR": "droit du vivant et de l'environnement",
  "EN": "life and environmental law",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "gfaaaaaaagbaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567dc33ab83eaf1ceef1f820")
});
db.getCollection("terms").insert({
  "IEML": "l.-p.-s.y.-'",
  "FR": "études droit international",
  "EN": "international law studies",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "ggaaaaaaagbaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567dc36cb83eaf1ceef1f82a")
});
db.getCollection("terms").insert({
  "IEML": "b.-x.-s.y.-'",
  "FR": "édition | traduction | publication (en ligne)",
  "EN": "edition | translation | publishing (on line)",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "efaaaaaaagcaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567dc40db83eaf1ceef1f834")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egaaaaaaagcaaaaaaaeeabeaaaa"
  ],
  "CLASS": "4",
  "EN": "data curation",
  "FR": "curation de données",
  "IEML": "t.-x.-s.y.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("567dc45eb83eaf1ceef1f83e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffaaaaaaagcaaaaaaaeeabeaaaa"
  ],
  "CLASS": "4",
  "EN": "emotions and engagement (study, measurement)",
  "FR": "émotions et engagement (études, mesures)",
  "IEML": "m.-x.-s.y.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("567dc598b83eaf1ceef1f848")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgaaaaaaagcaaaaaaaeeabeaaaa"
  ],
  "CLASS": "4",
  "EN": "game studies",
  "FR": "étude des jeux",
  "IEML": "n.-x.-s.y.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("567dc605b83eaf1ceef1f852")
});
db.getCollection("terms").insert({
  "IEML": "f.-x.-s.y.-'",
  "FR": "détection et quantification du vivant (étude)",
  "EN": "sensing and quantification of the living (study)",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "gfaaaaaaagcaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567dc785b83eaf1ceef1f866")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggaaaaaaagcaaaaaaaeeabeaaaa"
  ],
  "CLASS": "4",
  "EN": "smart territories | cities studies",
  "FR": "territoires | villes intelligentes (études)",
  "IEML": "l.-x.-s.y.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("567dc7ecb83eaf1ceef1f870")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeaaaaaaadhaaaaaaaeeabeaaaa",
    "eeaaaaaaahdaaaaaaaeeabeaaaa"
  ],
  "CLASS": "4",
  "EN": "reflexive studies",
  "FR": "études réflexives",
  "IEML": "s.-O:M:.-+M:O:.-s.y.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "12",
  "_id": ObjectId("567dca75b83eaf1ceef1f87a")
});
db.getCollection("terms").insert({
  "IEML": "t.-O:M:.-+M:O:.-s.y.-'",
  "FR": "études historiques",
  "EN": "historical studies",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "12",
  "CANONICAL": [
    "egaaaaaaadhaaaaaaaeeabeaaaa",
    "egaaaaaaahdaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567dcbfdb83eaf1ceef1f88c")
});
db.getCollection("terms").insert({
  "IEML": "k.-O:M:.-+M:O:.-s.y.-'",
  "FR": "études sociales",
  "EN": "social studies",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "12",
  "CANONICAL": [
    "feaaaaaaadhaaaaaaaeeabeaaaa",
    "feaaaaaaahdaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567dcc2bb83eaf1ceef1f895")
});
db.getCollection("terms").insert({
  "IEML": "n.-O:M:.-+M:O:.-s.y.-'",
  "FR": "études culturelles",
  "EN": "cultural studies",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "12",
  "CANONICAL": [
    "fgaaaaaaadhaaaaaaaeeabeaaaa",
    "fgaaaaaaahdaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567dcc75b83eaf1ceef1f89e")
});
db.getCollection("terms").insert({
  "IEML": "d.-+O:M:.-M:O:.-s.y.-'",
  "FR": "études de la détermination et de la mesure",
  "EN": "determination and measurement studies",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "42",
  "CANONICAL": [
    "geaaaaaaahdaaaaaaaeeabeaaaa",
    "dhaaaaaaahdaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567dccedb83eaf1ceef1f8a7")
});
db.getCollection("terms").insert({
  "IEML": "f.-O:M:.-+M:O:.-s.y.-'",
  "FR": "études vivantes et du vivant",
  "EN": "lively and life studies",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "12",
  "CANONICAL": [
    "gfaaaaaaadhaaaaaaaeeabeaaaa",
    "gfaaaaaaahdaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567dcd80b83eaf1ceef1f8b0")
});
db.getCollection("terms").insert({
  "IEML": "l.-O:M:.-+M:O:.-s.y.-'",
  "FR": "études de l'humanité située",
  "EN": "situated humanity studies",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "12",
  "CANONICAL": [
    "ggaaaaaaadhaaaaaaaeeabeaaaa",
    "ggaaaaaaahdaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567dcde2b83eaf1ceef1f8b9")
});
db.getCollection("terms").insert({
  "IEML": "m.-O:M:.-+M:O:.-s.y.-'",
  "FR": "études affectives et critiques",
  "EN": "critique and affect studies",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "12",
  "CANONICAL": [
    "ffaaaaaaadhaaaaaaaeeabeaaaa",
    "ffaaaaaaahdaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567dce37b83eaf1ceef1f8c2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhaaaaaaadhaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "objects of humanities and social sciences (1)",
  "FR": "objets des sciences humaines (1)",
  "IEML": "M:M:.-O:M:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "54",
  "_id": ObjectId("567f0438b83eaf1ceef1f8cb")
});
db.getCollection("terms").insert({
  "IEML": "M:M:.-M:O:.-'",
  "FR": "objets des sciences humaines (2)",
  "EN": "objects of humanities and social sciences (2)",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "54",
  "CANONICAL": [
    "hhaaaaaaahdaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567f0483b83eaf1ceef1f8d2")
});
db.getCollection("terms").insert({
  "IEML": "M:M:.-O:M:.-s.y.-'+M:M:.-M:O:.-s.y.-'",
  "FR": "sciences humaines",
  "EN": "humanities and social sciences",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "108",
  "CANONICAL": [
    "hhaaaaaaadhaaaaaaaeeabeaaaa",
    "hhaaaaaaahdaaaaaaaeeabeaaaa"
  ],
  "_id": ObjectId("567f0535b83eaf1ceef1f8da")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeaaaaaaadhaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "cultural structures (1)",
  "FR": "structures culturelles (1)",
  "IEML": "s.-O:M:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("567f07b4b83eaf1ceef1f8db")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egaaaaaaadhaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "dated phenomena (1)",
  "FR": "phénomènes datés (1)",
  "IEML": "t.-O:M:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("567f0812b83eaf1ceef1f8e2")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffaaaaaaadhaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "assessing phenomena",
  "FR": "phénomènes d'évaluation",
  "IEML": "m.-O:M:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("567f088fb83eaf1ceef1f8e9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggaaaaaaadhaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "spatial | topological phenomena (1)",
  "FR": "phénomènes spatiaux | topologiques (1)",
  "IEML": "l.-O:M:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("567f0904b83eaf1ceef1f8f0")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaaaaaaadhaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "communication phenomena (1)",
  "FR": "phénomènes de communication (1)",
  "IEML": "b.-O:M:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("567f097db83eaf1ceef1f8f7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgaaaaaaadhaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "cultural phenomena (1)",
  "FR": "phénomènes culturels (1)",
  "IEML": "n.-O:M:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("567f0a3fb83eaf1ceef1f905")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geaaaaaaadhaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "determined | measured phenomena (1)",
  "FR": "phénomènes déterminés | mesurés (1)",
  "IEML": "d.-O:M:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("567f0a8eb83eaf1ceef1f90c")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfaaaaaaadhaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "living phenomena (1)",
  "FR": "phénomènes vivants (1)",
  "IEML": "f.-O:M:.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "6",
  "_id": ObjectId("567f0ac7b83eaf1ceef1f913")
});
db.getCollection("terms").insert({
  "IEML": "M:M:.-y.-'",
  "FR": "phénomènes de connaissance",
  "EN": "knowledge phenomena",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "9",
  "CANONICAL": [
    "hhaaaaaaabeaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567f0b31b83eaf1ceef1f91a")
});
db.getCollection("terms").insert({
  "IEML": "M:M:.-o.-'",
  "FR": "phénomènes politiques",
  "EN": "political phenomena",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "9",
  "CANONICAL": [
    "hhaaaaaaabfaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567f0b58b83eaf1ceef1f921")
});
db.getCollection("terms").insert({
  "IEML": "M:M:.-e.-'",
  "FR": "phénomènes économiques",
  "EN": "economic phenomena",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "9",
  "CANONICAL": [
    "hhaaaaaaabgaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567f0b75b83eaf1ceef1f928")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhaaaaaaaceaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "communication vectors",
  "FR": "vecteurs de communication",
  "IEML": "M:M:.-u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("567f0bb9b83eaf1ceef1f92f")
});
db.getCollection("terms").insert({
  "IEML": "s.-y.-'",
  "FR": "organisation de la connaissance",
  "EN": "knowledge organization",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "eeaaaaaaabeaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567f0c68b83eaf1ceef1f944")
});
db.getCollection("terms").insert({
  "IEML": "s.-o.-'",
  "FR": "organisation politique",
  "EN": "political organization",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "eeaaaaaaabfaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567f0c87b83eaf1ceef1f94b")
});
db.getCollection("terms").insert({
  "IEML": "s.-e.-'",
  "FR": "organisation économique",
  "EN": "economic organization",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "eeaaaaaaabgaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567f0ca9b83eaf1ceef1f952")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "eeaaaaaaaceaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "meaning | semiosis organization",
  "FR": "organisation de la signification | sémiose",
  "IEML": "s.-u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("567f0cdfb83eaf1ceef1f959")
});
db.getCollection("terms").insert({
  "IEML": "s.-a.-'",
  "FR": "organisation sociale",
  "EN": "social organization",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "eeaaaaaaacfaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567f0d0bb83eaf1ceef1f960")
});
db.getCollection("terms").insert({
  "IEML": "b.-y.-'",
  "FR": "communication | vulgarisation scientifique",
  "EN": "scientific communication | vulgarization",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "efaaaaaaabeaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567f0da0b83eaf1ceef1f96e")
});
db.getCollection("terms").insert({
  "IEML": "b.-o.-'",
  "FR": "sphère publique",
  "EN": "public sphere",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "efaaaaaaabfaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567f0dc2b83eaf1ceef1f975")
});
db.getCollection("terms").insert({
  "IEML": "b.-u.-'",
  "FR": "langue naturelle",
  "EN": "natural language",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "efaaaaaaaceaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567f0e39b83eaf1ceef1f983")
});
db.getCollection("terms").insert({
  "IEML": "b.-a.-'",
  "FR": "parole en contexte",
  "EN": "speech in context",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "efaaaaaaacfaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567f0e65b83eaf1ceef1f98a")
});
db.getCollection("terms").insert({
  "IEML": "b.-i.-'",
  "FR": "technique de communication",
  "EN": "communication technique",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "efaaaaaaacgaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567f0e97b83eaf1ceef1f991")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egaaaaaaabfaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "political moment (epoch, conjuncture)",
  "FR": "moment politique (période, conjoncture)",
  "IEML": "t.-o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("567f0f7eb83eaf1ceef1f99f")
});
db.getCollection("terms").insert({
  "IEML": "t.-e.-'",
  "FR": "moment économique (phase, conjoncture)",
  "EN": "economic moment (phase, conjuncture)",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "egaaaaaaabgaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567f0fdcb83eaf1ceef1f9a6")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "egaaaaaaaceaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "communication phase | conjuncture",
  "FR": "phase | conjoncture de communication",
  "IEML": "t.-u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("567f1054b83eaf1ceef1f9ad")
});
db.getCollection("terms").insert({
  "IEML": "t.-a.-'",
  "FR": "moment social (période, conjoncture)",
  "EN": "social moment (period, conjuncture)",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "egaaaaaaacfaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567f10a2b83eaf1ceef1f9b4")
});
db.getCollection("terms").insert({
  "IEML": "k.-y.-'",
  "FR": "communauté scientifique",
  "EN": "scientific community",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "feaaaaaaabeaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567f11f9b83eaf1ceef1f9c2")
});
db.getCollection("terms").insert({
  "IEML": "k.-o.-'",
  "FR": "mouvement socio-politiques",
  "EN": "socio-political movements",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "feaaaaaaabfaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567f122db83eaf1ceef1f9c9")
});
db.getCollection("terms").insert({
  "IEML": "k.-e.-'",
  "FR": "administration, gestion",
  "EN": "administration, management",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "feaaaaaaabgaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567f126ab83eaf1ceef1f9d0")
});
db.getCollection("terms").insert({
  "IEML": "k.-u.-'",
  "FR": "communication publique",
  "EN": "public communication",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "feaaaaaaaceaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567f12afb83eaf1ceef1f9d7")
});
db.getCollection("terms").insert({
  "IEML": "k.-a.-'",
  "FR": "société civile",
  "EN": "civil society",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "feaaaaaaacfaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567f12fdb83eaf1ceef1f9de")
});
db.getCollection("terms").insert({
  "IEML": "k.-i.-'",
  "FR": "communauté technique (ingénieurs, techniciens)",
  "EN": "technical community (engineers, technicians)",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "feaaaaaaacgaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567f1352b83eaf1ceef1f9e5")
});
db.getCollection("terms").insert({
  "IEML": "m.-y.-'",
  "FR": "évaluation scientifique",
  "EN": "scientific evaluation",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "ffaaaaaaabeaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567f1389b83eaf1ceef1f9ec")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffaaaaaaabfaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "political evaluation",
  "FR": "évaluation politique",
  "IEML": "m.-o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("567f13a9b83eaf1ceef1f9f3")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ffaaaaaaabgaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "economic evaluation",
  "FR": "évaluation économique",
  "IEML": "m.-e.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("567f13f7b83eaf1ceef1f9fa")
});
db.getCollection("terms").insert({
  "IEML": "m.-u.-'",
  "FR": "évaluation de la communication",
  "EN": "communication evaluation",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "ffaaaaaaaceaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567f14e7b83eaf1ceef1fa01")
});
db.getCollection("terms").insert({
  "IEML": "m.-a.-'",
  "FR": "évaluation sociale",
  "EN": "social evaluation",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "ffaaaaaaacfaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567f1512b83eaf1ceef1fa08")
});
db.getCollection("terms").insert({
  "IEML": "m.-i.-'",
  "FR": "évaluation technique",
  "EN": "technical evaluation",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "ffaaaaaaacgaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567f1537b83eaf1ceef1fa0f")
});
db.getCollection("terms").insert({
  "IEML": "n.-y.-'",
  "FR": "univers, cosmos",
  "EN": "universe, cosmos",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "fgaaaaaaabeaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567f1586b83eaf1ceef1fa16")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgaaaaaaabfaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "cultural singularity | resistance",
  "FR": "singularité | résistance culturelle",
  "IEML": "n.-o.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("567f15c1b83eaf1ceef1fa1d")
});
db.getCollection("terms").insert({
  "IEML": "n.-e.-'",
  "FR": "division du travail",
  "EN": "division of labour",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "fgaaaaaaabgaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567f1630b83eaf1ceef1fa24")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgaaaaaaaceaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "taxon, category, paradigm",
  "FR": "taxon, catégorie, paradigme",
  "IEML": "n.-u.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("567f1683b83eaf1ceef1fa2b")
});
db.getCollection("terms").insert({
  "IEML": "n.-i.-'",
  "FR": "innovation, diffusion, désuétude",
  "EN": "innovation, diffusion, disuse",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "fgaaaaaaacgaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567f1905b83eaf1ceef1fa39")
});
db.getCollection("terms").insert({
  "IEML": "d.-y.-'",
  "FR": "structure formelle",
  "EN": "formal structure",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "geaaaaaaabeaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567f197fb83eaf1ceef1fa40")
});
db.getCollection("terms").insert({
  "IEML": "d.-o.-'",
  "FR": "constitution politique",
  "EN": "political constitution",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "geaaaaaaabfaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567f1995b83eaf1ceef1fa47")
});
db.getCollection("terms").insert({
  "IEML": "d.-e.-'",
  "FR": "opération | résultat financier | comptable",
  "EN": "financial | accounting operation | result",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "geaaaaaaabgaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567f1a0eb83eaf1ceef1fa4e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geaaaaaaacgaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "computing technology and science",
  "FR": "technosciences informatiques",
  "IEML": "d.-i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("567f1cf7b83eaf1ceef1fa63")
});
db.getCollection("terms").insert({
  "IEML": "f.-i.-'",
  "FR": "technosciences biologiques",
  "EN": "biological technoscience",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "gfaaaaaaacgaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567f1d5cb83eaf1ceef1fa6a")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggaaaaaaacgaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "physics | molecular technosciences",
  "FR": "technosciences physiques | moléculaires",
  "IEML": "l.-i.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("567f1d92b83eaf1ceef1fa71")
});
db.getCollection("terms").insert({
  "IEML": "f.-y.-'",
  "FR": "dynamique évolutive, modèle du vivant",
  "EN": "evolution dynamics, life modelling",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "gfaaaaaaabeaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567f1e41b83eaf1ceef1fa78")
});
db.getCollection("terms").insert({
  "IEML": "f.-o.-'",
  "FR": "relation de genre | de sexe",
  "EN": "gender | sexual relation",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "gfaaaaaaabfaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567f1e6db83eaf1ceef1fa7f")
});
db.getCollection("terms").insert({
  "IEML": "f.-e.-'",
  "FR": "marché des talents | de l'emploi",
  "EN": "talent | labour market",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "gfaaaaaaabgaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567f1ebdb83eaf1ceef1fa86")
});
db.getCollection("terms").insert({
  "IEML": "f.-a.-'",
  "FR": "population humaine",
  "EN": "human population",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "gfaaaaaaacfaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567f1f2bb83eaf1ceef1fa94")
});
db.getCollection("terms").insert({
  "IEML": "l.-y.-'",
  "FR": "la planète Terre",
  "EN": "planet Earth",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "ggaaaaaaabeaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567f1f58b83eaf1ceef1fa9b")
});
db.getCollection("terms").insert({
  "IEML": "l.-o.-'",
  "FR": "relations internationales",
  "EN": "international relations",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "ggaaaaaaabfaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567f1f88b83eaf1ceef1faa2")
});
db.getCollection("terms").insert({
  "IEML": "l.-e.-'",
  "FR": "commerce international",
  "EN": "international trade",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "ggaaaaaaabgaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567f1fa7b83eaf1ceef1faa9")
});
db.getCollection("terms").insert({
  "IEML": "l.-u.-'",
  "FR": "communication transculturelle",
  "EN": "transcultural communication",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "ggaaaaaaaceaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567f1fddb83eaf1ceef1fab0")
});
db.getCollection("terms").insert({
  "IEML": "l.-a.-'",
  "FR": "réseau social",
  "EN": "social network",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "ggaaaaaaacfaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("567f1fffb83eaf1ceef1fab7")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hhaaaaaaaecaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "methodological variables",
  "FR": "variables méthodologiques",
  "IEML": "M:M:.-g.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "9",
  "_id": ObjectId("568026e2b83eaf1ceef1fac5")
});
db.getCollection("terms").insert({
  "IEML": "M:M:.-h.-'",
  "FR": "sacré, religion",
  "EN": "sacred, religion",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "9",
  "CANONICAL": [
    "hhaaaaaaafbaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("568027b2b83eaf1ceef1facc")
});
db.getCollection("terms").insert({
  "IEML": "M:M:.-c.-'",
  "FR": "psychisme humain",
  "EN": "human psyche",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "9",
  "CANONICAL": [
    "hhaaaaaaafcaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("568027e9b83eaf1ceef1fad3")
});
db.getCollection("terms").insert({
  "IEML": "M:M:.-p.-'",
  "FR": "droit, justice",
  "EN": "law, justice",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "9",
  "CANONICAL": [
    "hhaaaaaaagbaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("56802822b83eaf1ceef1fada")
});
db.getCollection("terms").insert({
  "IEML": "M:M:.-x.-'",
  "FR": "outils algorithmiques",
  "EN": "algorithmic tools",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "9",
  "CANONICAL": [
    "hhaaaaaaagcaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("5680284db83eaf1ceef1fae1")
});
db.getCollection("terms").insert({
  "IEML": "s.-M:O:.-'",
  "FR": "structures culturelles (2)",
  "EN": "cultural structures (2)",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "6",
  "CANONICAL": [
    "eeaaaaaaahdaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("568028f8b83eaf1ceef1fae8")
});
db.getCollection("terms").insert({
  "IEML": "b.-M:O:.-'",
  "FR": "phénomènes de communication (2)",
  "EN": "communication phenomena (2)",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "6",
  "CANONICAL": [
    "efaaaaaaahdaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("56802a8bb83eaf1ceef1faef")
});
db.getCollection("terms").insert({
  "IEML": "t.-M:O:.-'",
  "FR": "phénomènes datés (2)",
  "EN": "dated phenomena (2)",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "6",
  "CANONICAL": [
    "egaaaaaaahdaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("56802b23b83eaf1ceef1faf6")
});
db.getCollection("terms").insert({
  "IEML": "k.-M:O:.-'",
  "FR": "phénomènes sociaux (2)",
  "EN": "social phenomena (2)",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "6",
  "CANONICAL": [
    "feaaaaaaahdaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("56802b46b83eaf1ceef1fafd")
});
db.getCollection("terms").insert({
  "IEML": "m.-M:O:.-'",
  "FR": "phénomènes émotionnels",
  "EN": "emotional phenomena",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "6",
  "CANONICAL": [
    "ffaaaaaaahdaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("56802bcdb83eaf1ceef1fb04")
});
db.getCollection("terms").insert({
  "IEML": "n.-M:O:.-'",
  "FR": "phénomènes symboliques",
  "EN": "symbolic phenomena",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "6",
  "CANONICAL": [
    "fgaaaaaaahdaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("56802bfcb83eaf1ceef1fb0b")
});
db.getCollection("terms").insert({
  "IEML": "d.-M:O:.-'",
  "FR": "phénomènes de détermination | mesure",
  "EN": "determination | measurement phenomena",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "6",
  "CANONICAL": [
    "geaaaaaaahdaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("56802d37b83eaf1ceef1fb12")
});
db.getCollection("terms").insert({
  "IEML": "f.-M:O:.-'",
  "FR": "phénomènes vivants (2)",
  "EN": "living phenomena (2)",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "6",
  "CANONICAL": [
    "gfaaaaaaahdaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("56802d6db83eaf1ceef1fb19")
});
db.getCollection("terms").insert({
  "IEML": "l.-M:O:.-'",
  "FR": "phénomènes spatiaux | topologiques (2)",
  "EN": "spatial | topological phenomena (2)",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "6",
  "CANONICAL": [
    "ggaaaaaaahdaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("56802e06b83eaf1ceef1fb20")
});
db.getCollection("terms").insert({
  "IEML": "s.-j.-'",
  "FR": "jugement esthétique",
  "EN": "aesthetic judgement",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "eeaaaaaaaebaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("5680300cb83eaf1ceef1fb27")
});
db.getCollection("terms").insert({
  "IEML": "b.-j.-'",
  "FR": "oeuvre littéraire | artistique",
  "EN": "literary | artistic work",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "efaaaaaaaebaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("56803048b83eaf1ceef1fb2e")
});
db.getCollection("terms").insert({
  "IEML": "t.-j.-'",
  "FR": "événement | période de l'histoire de l'art | de la littérature",
  "EN": "event | epoch of art | literary history",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "egaaaaaaaebaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("5680309eb83eaf1ceef1fb35")
});
db.getCollection("terms").insert({
  "IEML": "k.-j.-'",
  "FR": "communauté artistique | littéraire",
  "EN": "artistic | literary community",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "feaaaaaaaebaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("568030e6b83eaf1ceef1fb3c")
});
db.getCollection("terms").insert({
  "IEML": "m.-j.-'",
  "FR": "évaluation d'une oeuvre | d'un artiste",
  "EN": "assessment of a artwork | an artist",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "ffaaaaaaaebaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("56803159b83eaf1ceef1fb43")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgaaaaaaaebaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "artistic | literary genre in context",
  "FR": "genre artistique | littéraire en contexte",
  "IEML": "n.-j.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("568031cab83eaf1ceef1fb4a")
});
db.getCollection("terms").insert({
  "IEML": "d.-j.-'",
  "FR": "expertise, conservation, restauration (d'oeuvres | artefacts)",
  "EN": "expertise, conservation, restauration (of artworks | artifacts)",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "geaaaaaaaebaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("56804396b83eaf1ceef1fb51")
});
db.getCollection("terms").insert({
  "IEML": "f.-j.-'",
  "FR": "performance artistique",
  "EN": "artistic performance",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "gfaaaaaaaebaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("568043c2b83eaf1ceef1fb58")
});
db.getCollection("terms").insert({
  "IEML": "l.-j.-'",
  "FR": "oeuvre architecturale | urbaine",
  "EN": "architectural | urban artwork",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "ggaaaaaaaebaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("568043fdb83eaf1ceef1fb5f")
});
db.getCollection("terms").insert({
  "IEML": "s.-g.-'",
  "FR": "théorie",
  "EN": "theory",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "eeaaaaaaaecaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("5680442bb83eaf1ceef1fb66")
});
db.getCollection("terms").insert({
  "IEML": "b.-g.-'",
  "FR": "langue | écriture rare | ancienne",
  "EN": "ancient | rare language | script",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "efaaaaaaaecaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("5680446eb83eaf1ceef1fb6d")
});
db.getCollection("terms").insert({
  "IEML": "t.-g.-'",
  "FR": "série temporelle",
  "EN": "temporal series",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "egaaaaaaaecaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("5680448ab83eaf1ceef1fb74")
});
db.getCollection("terms").insert({
  "IEML": "k.-g.-'",
  "FR": "formation de consensus",
  "EN": "consensus formation",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "feaaaaaaaecaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("568044fab83eaf1ceef1fb7b")
});
db.getCollection("terms").insert({
  "IEML": "m.-g.-'",
  "FR": "tendance d'opinion",
  "EN": "opinion trend",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "ffaaaaaaaecaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("56804521b83eaf1ceef1fb82")
});
db.getCollection("terms").insert({
  "IEML": "n.-g.-'",
  "FR": "contenu discursif",
  "EN": "discursive content",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "fgaaaaaaaecaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("56804556b83eaf1ceef1fb89")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geaaaaaaaecaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "statistics",
  "FR": "statistiques",
  "IEML": "d.-g.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("568046f3b83eaf1ceef1fb90")
});
db.getCollection("terms").insert({
  "IEML": "f.-g.-'",
  "FR": "pratique sociale",
  "EN": "social practise",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "gfaaaaaaaecaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("568047dab83eaf1ceef1fb97")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "efaaaaaaafbaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "sacred literature",
  "FR": "littérature sacrée",
  "IEML": "b.-h.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("568048ccb83eaf1ceef1fbac")
});
db.getCollection("terms").insert({
  "IEML": "t.-h.-'",
  "FR": "histoire sacrée",
  "EN": "sacred history",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "egaaaaaaafbaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("568048fbb83eaf1ceef1fbb3")
});
db.getCollection("terms").insert({
  "IEML": "k.-h.-'",
  "FR": "institution | communauté religieuse",
  "EN": "religious institution | community",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "feaaaaaaafbaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("56804938b83eaf1ceef1fbba")
});
db.getCollection("terms").insert({
  "IEML": "m.-h.-'",
  "FR": "sage, saint, martyr",
  "EN": "sage, saint, martyr",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "ffaaaaaaafbaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("56804996b83eaf1ceef1fbc1")
});
db.getCollection("terms").insert({
  "IEML": "n.-h.-'",
  "FR": "art | architecture sacrée",
  "EN": "sacred art | architecture",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "fgaaaaaaafbaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("568049cfb83eaf1ceef1fbc8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geaaaaaaafbaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "religious prescription | interdiction, taboo",
  "FR": "interdiction | prescription religieuse, tabou",
  "IEML": "d.-h.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("56804a05b83eaf1ceef1fbcf")
});
db.getCollection("terms").insert({
  "IEML": "f.-h.-'",
  "FR": "pratique spirituelle, piété personnelle, intériorité",
  "EN": "spiritual practise, personal piety, interiority",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "gfaaaaaaafbaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("56804a6fb83eaf1ceef1fbd6")
});
db.getCollection("terms").insert({
  "IEML": "l.-h.-'",
  "FR": "lieu saint, pélerinage",
  "EN": "sacred place, pilgrimage",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "ggaaaaaaafbaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("56804aadb83eaf1ceef1fbdd")
});
db.getCollection("terms").insert({
  "IEML": "b.-c.-'",
  "FR": "chemin d'apprentissage",
  "EN": "journey of learning",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "efaaaaaaafcaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("56804bf6b83eaf1ceef1fbeb")
});
db.getCollection("terms").insert({
  "IEML": "t.-c.-'",
  "FR": "histoire personnelle",
  "EN": "personal history",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "egaaaaaaafcaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("56804c17b83eaf1ceef1fbf2")
});
db.getCollection("terms").insert({
  "IEML": "k.-c.-'",
  "FR": "interaction sociale",
  "EN": "social interaction",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "feaaaaaaafcaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("56804d4eb83eaf1ceef1fbf9")
});
db.getCollection("terms").insert({
  "IEML": "m.-c.-'",
  "FR": "croissance personnelle",
  "EN": "personal growth",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "ffaaaaaaafcaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("56804d84b83eaf1ceef1fc00")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "fgaaaaaaafcaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "unconscious | involuntary symbolic processes",
  "FR": "processus symboliques inconscients | involontaires",
  "IEML": "n.-c.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("56804e66b83eaf1ceef1fc07")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geaaaaaaafcaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "problem solving, learning process",
  "FR": "résolution de problème",
  "IEML": "d.-c.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("56805119b83eaf1ceef1fc0e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gfaaaaaaafcaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "cure, psychotherapy",
  "FR": "cure, psychothérapie",
  "IEML": "f.-c.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("568051c5b83eaf1ceef1fc15")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ggaaaaaaafcaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "home | residence | local roots",
  "FR": "foyer | residence | racines locales",
  "IEML": "l.-c.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("56805253b83eaf1ceef1fc1c")
});
db.getCollection("terms").insert({
  "IEML": "s.-p.-'",
  "FR": "principes juridiques",
  "EN": "legal principles",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "eeaaaaaaagbaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("568060adb83eaf1ceef1fc23")
});
db.getCollection("terms").insert({
  "IEML": "t.-p.-'",
  "FR": "événement | période du droit",
  "EN": "event | epoch of law",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "egaaaaaaagbaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("5680611fb83eaf1ceef1fc31")
});
db.getCollection("terms").insert({
  "IEML": "k.-p.-'",
  "FR": "crime | délit",
  "EN": "crime | offense",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "feaaaaaaagbaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("56806156b83eaf1ceef1fc38")
});
db.getCollection("terms").insert({
  "IEML": "m.-p.-'",
  "FR": "mediation | resolution de conflit",
  "EN": "mediation | conflict resolution",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "ffaaaaaaagbaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("56806183b83eaf1ceef1fc3f")
});
db.getCollection("terms").insert({
  "IEML": "n.-p.-'",
  "FR": "droits humains | déontologie (respect)",
  "EN": "human rights | deontology (respect)",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "fgaaaaaaagbaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("5680623cb83eaf1ceef1fc46")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "geaaaaaaagbaaaaaaaaaaaaaaaa"
  ],
  "CLASS": "4",
  "EN": "evidence",
  "FR": "preuve",
  "IEML": "d.-p.-'",
  "LAYER": "3",
  "PARADIGM": "0",
  "TAILLE": "1",
  "_id": ObjectId("568062a4b83eaf1ceef1fc4d")
});
db.getCollection("terms").insert({
  "IEML": "f.-p.-'",
  "FR": "droit du vivant | de l'environnement (respect)",
  "EN": "life | environmental law (respect)",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "gfaaaaaaagbaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("56806326b83eaf1ceef1fc54")
});
db.getCollection("terms").insert({
  "IEML": "l.-p.-'",
  "FR": "droit international",
  "EN": "international law",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "ggaaaaaaagbaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("56806352b83eaf1ceef1fc5b")
});
db.getCollection("terms").insert({
  "IEML": "b.-x.-'",
  "FR": "outil d'écriture | traduction | publication",
  "EN": "edition | translation | publishing tool",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "efaaaaaaagcaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("568064a0b83eaf1ceef1fc69")
});
db.getCollection("terms").insert({
  "IEML": "t.-x.-'",
  "FR": "outil de curation de données",
  "EN": "data curation tool",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "egaaaaaaagcaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("568064dbb83eaf1ceef1fc70")
});
db.getCollection("terms").insert({
  "IEML": "k.-x.-'",
  "FR": "outil de conversation | recommandation",
  "EN": "conversation | recommendation tool",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "feaaaaaaagcaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("56806569b83eaf1ceef1fc77")
});
db.getCollection("terms").insert({
  "IEML": "m.-x.-'",
  "FR": "outil de mesure de l'engagement",
  "EN": "engagement measurement tool",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "ffaaaaaaagcaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("56806b5fb83eaf1ceef1fc7e")
});
db.getCollection("terms").insert({
  "IEML": "n.-x.-'",
  "FR": "environnement de jeu",
  "EN": "game environment",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "fgaaaaaaagcaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("56806b92b83eaf1ceef1fc85")
});
db.getCollection("terms").insert({
  "IEML": "d.-x.-'",
  "FR": "outil de veille | de renseignement",
  "EN": "watch | intelligence tool",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "geaaaaaaagcaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("56806bd7b83eaf1ceef1fc8c")
});
db.getCollection("terms").insert({
  "IEML": "l.-x.-'",
  "FR": "géolocalisation | territoires intelligents",
  "EN": "geolocation | smart territories",
  "PARADIGM": "0",
  "LAYER": "3",
  "CLASS": "4",
  "TAILLE": "1",
  "CANONICAL": [
    "ggaaaaaaagcaaaaaaaaaaaaaaaa"
  ],
  "_id": ObjectId("56806d8ab83eaf1ceef1fc9a")
});
db.getCollection("terms").insert({
  "IEML": "j.A:O:.-",
  "FR": "changement actuel de langage",
  "EN": "actual language change",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "ebacdaaaa"
  ],
  "_id": ObjectId("5681b7d9b83eaf1ceef1fca8")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ebadbaaaa"
  ],
  "CLASS": "4",
  "EN": "abstract oriented change of language",
  "FR": "changement de langage orienté abstrait",
  "IEML": "j.O:U:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("5681b8e1b83eaf1ceef1fcaf")
});
db.getCollection("terms").insert({
  "IEML": "j.O:A:.-",
  "FR": "changement de langage orienté concret",
  "EN": "concrete oriented language change",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "ebadcaaaa"
  ],
  "_id": ObjectId("5681b98db83eaf1ceef1fcb6")
});
db.getCollection("terms").insert({
  "IEML": "g.U:O:.-",
  "FR": "changement virtuel de message",
  "EN": "virtual message change",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "ecabdaaaa"
  ],
  "_id": ObjectId("5681ba1cb83eaf1ceef1fcbd")
});
db.getCollection("terms").insert({
  "IEML": "g.A:O:.-",
  "FR": "changement actuel de message",
  "EN": "actual message change",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "ecacdaaaa"
  ],
  "_id": ObjectId("5681ba37b83eaf1ceef1fcc4")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "ecadbaaaa"
  ],
  "CLASS": "4",
  "EN": "inside message change",
  "FR": "changement de message intérieur",
  "IEML": "g.O:U:.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("5681ba6fb83eaf1ceef1fccb")
});
db.getCollection("terms").insert({
  "IEML": "g.O:A:.-",
  "FR": "changement de message extérieur",
  "EN": "outside message change",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "ecadcaaaa"
  ],
  "_id": ObjectId("5681baaab83eaf1ceef1fcd2")
});
db.getCollection("terms").insert({
  "IEML": "h.O:U:.-",
  "FR": "changement de sens intérieur",
  "EN": "inside change of meaning",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "fbadbaaaa"
  ],
  "_id": ObjectId("5681bb68b83eaf1ceef1fcd9")
});
db.getCollection("terms").insert({
  "IEML": "h.O:A:.-",
  "FR": "changement de sens extérieur",
  "EN": "outside change of meaning",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "fbadcaaaa"
  ],
  "_id": ObjectId("5681bb98b83eaf1ceef1fce0")
});
db.getCollection("terms").insert({
  "IEML": "h.U:O:.-",
  "FR": "changement virtuel de sens",
  "EN": "virtual change of meaning",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "fbabdaaaa"
  ],
  "_id": ObjectId("5681bcfeb83eaf1ceef1fce7")
});
db.getCollection("terms").insert({
  "IEML": "h.A:O:.-",
  "FR": "changement actuel de sens",
  "EN": "actual change of meaning",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "fbacdaaaa"
  ],
  "_id": ObjectId("5681bd1eb83eaf1ceef1fcee")
});
db.getCollection("terms").insert({
  "IEML": "c.U:O:.-",
  "FR": "changement personnel virtuel",
  "EN": "virtual personal change",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "fcabdaaaa"
  ],
  "_id": ObjectId("5681bd88b83eaf1ceef1fcf5")
});
db.getCollection("terms").insert({
  "IEML": "c.A:O:.-",
  "FR": "changement personnel actuel",
  "EN": "actual personal change",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "fcacdaaaa"
  ],
  "_id": ObjectId("5681bda1b83eaf1ceef1fcfc")
});
db.getCollection("terms").insert({
  "IEML": "c.O:U:.-",
  "FR": "changement personnel individuel",
  "EN": "individual personal change",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "fcadbaaaa"
  ],
  "_id": ObjectId("5681bdd9b83eaf1ceef1fd03")
});
db.getCollection("terms").insert({
  "IEML": "c.O:A:.-",
  "FR": "changement personnel orienté collectif",
  "EN": "collective oriented personal change",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "fcadcaaaa"
  ],
  "_id": ObjectId("5681be05b83eaf1ceef1fd0a")
});
db.getCollection("terms").insert({
  "IEML": "p.O:U:.-",
  "FR": "changement d'objet intérieur",
  "EN": "inside object change",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "gbadbaaaa"
  ],
  "_id": ObjectId("5681bed8b83eaf1ceef1fd1f")
});
db.getCollection("terms").insert({
  "IEML": "p.O:A:.-",
  "FR": "changement d'objet extérieur",
  "EN": "outside object change",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "gbadcaaaa"
  ],
  "_id": ObjectId("5681bef3b83eaf1ceef1fd26")
});
db.getCollection("terms").insert({
  "IEML": "x.U:O:.-",
  "FR": "changement matériel orienté-cause",
  "EN": "cause-oriented material change",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "gcabdaaaa"
  ],
  "_id": ObjectId("5681c0aeb83eaf1ceef1fd2d")
});
db.getCollection("terms").insert({
  "IEML": "x.A:O:.-",
  "FR": "changement matériel orienté-condition",
  "EN": "condition-oriented material change",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "gcacdaaaa"
  ],
  "_id": ObjectId("5681c0dbb83eaf1ceef1fd34")
});
db.getCollection("terms").insert({
  "IEML": "x.O:U:.-",
  "FR": "changement de virtualités matérielles",
  "EN": "material virtual change",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "gcadbaaaa"
  ],
  "_id": ObjectId("5681c170b83eaf1ceef1fd3b")
});
db.getCollection("terms").insert({
  "IEML": "x.O:A:.-",
  "FR": "changement d'actualités matérielles",
  "EN": "actual material change",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "gcadcaaaa"
  ],
  "_id": ObjectId("5681c1a1b83eaf1ceef1fd42")
});
db.getCollection("terms").insert({
  "IEML": "S:O:.wo.-",
  "FR": "mutation des possibles symboliques",
  "EN": "mutation of symbolic possibilities",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "edabbaaaa"
  ],
  "_id": ObjectId("5681c20bb83eaf1ceef1fd49")
});
db.getCollection("terms").insert({
  "IEML": "B:O:.wo.-",
  "FR": "mutation des possibles personnels",
  "EN": "personal possibilities mutation",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "fdabbaaaa"
  ],
  "_id": ObjectId("5681c22eb83eaf1ceef1fd50")
});
db.getCollection("terms").insert({
  "IEML": "T:O:.wo.-",
  "FR": "mutation des possibles objectifs",
  "EN": "mutation of objective possibilities",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "gdabbaaaa"
  ],
  "_id": ObjectId("5681c286b83eaf1ceef1fd57")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hbabbaaaa"
  ],
  "CLASS": "4",
  "EN": "virtual mutation of possibilities",
  "FR": "mutation virtuelle des possibles",
  "IEML": "M:U:.wo.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("5681c2cbb83eaf1ceef1fd5e")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hcabbaaaa"
  ],
  "CLASS": "4",
  "EN": "actual mutation of possibilities",
  "FR": "mutation actuelle des possibles",
  "IEML": "M:A:.wo.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("5681c30ab83eaf1ceef1fd65")
});
db.getCollection("terms").insert({
  "IEML": "M:U:.wa.-",
  "FR": "mutation des motifs de l'action",
  "EN": "mutation of grounds for action",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "3",
  "CANONICAL": [
    "hbabcaaaa"
  ],
  "_id": ObjectId("5681c3f8b83eaf1ceef1fd6c")
});
db.getCollection("terms").insert({
  "IEML": "M:A:.wa.-",
  "FR": "mutation des conditions de l'action",
  "EN": "mutation of the conditions for action",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "3",
  "CANONICAL": [
    "hcabcaaaa"
  ],
  "_id": ObjectId("5681c430b83eaf1ceef1fd73")
});
db.getCollection("terms").insert({
  "IEML": "B:O:.wa.-",
  "FR": "mutation psycho-sociale de l'action",
  "EN": "psycho-social mutation of the action",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "fdabcaaaa"
  ],
  "_id": ObjectId("5681c483b83eaf1ceef1fd7a")
});
db.getCollection("terms").insert({
  "IEML": "S:O:.wa.-",
  "FR": "mutation logique de l'action",
  "EN": "logical mutation of the action",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "edabcaaaa"
  ],
  "_id": ObjectId("5681c4a7b83eaf1ceef1fd81")
});
db.getCollection("terms").insert({
  "IEML": "T:O:.wa.-",
  "FR": "mutation objective de l'action",
  "EN": "objective mutation of the action",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "gdabcaaaa"
  ],
  "_id": ObjectId("5681c4ceb83eaf1ceef1fd88")
});
db.getCollection("terms").insert({
  "IEML": "T:O:.wu.-",
  "FR": "mutation objective de la perception",
  "EN": "objective mutation of the perception",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "gdacbaaaa"
  ],
  "_id": ObjectId("5681c528b83eaf1ceef1fd8f")
});
db.getCollection("terms").insert({
  "IEML": "B:O:.wu.-",
  "FR": "mutation personnelle de la perception",
  "EN": "personal mutation of the perception",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "fdacbaaaa"
  ],
  "_id": ObjectId("5681c55cb83eaf1ceef1fd96")
});
db.getCollection("terms").insert({
  "IEML": "S:O:.wu.-",
  "FR": "mutation symbolique de la perception",
  "EN": "symbolic mutation of the perception",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "edacbaaaa"
  ],
  "_id": ObjectId("5681c57fb83eaf1ceef1fd9d")
});
db.getCollection("terms").insert({
  "IEML": "M:U:.wu.-",
  "FR": "mutation virtuelle de la perception",
  "EN": "virtual mutation of the perception",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "3",
  "CANONICAL": [
    "hbacbaaaa"
  ],
  "_id": ObjectId("5681c5b3b83eaf1ceef1fda4")
});
db.getCollection("terms").insert({
  "IEML": "M:A:.wu.-",
  "FR": "mutation actuelle de la perception",
  "EN": "actual mutation of the perception",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "3",
  "CANONICAL": [
    "hcacbaaaa"
  ],
  "_id": ObjectId("5681c5cfb83eaf1ceef1fdab")
});
db.getCollection("terms").insert({
  "IEML": "M:U:.we.-",
  "FR": "mutation virtuelle de l'environnement",
  "EN": "virtual mutation of the environment",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "3",
  "CANONICAL": [
    "hbaccaaaa"
  ],
  "_id": ObjectId("5681c628b83eaf1ceef1fdb2")
});
db.getCollection("terms").insert({
  "IEML": "M:A:.we.-",
  "FR": "mutation actuelle de l'environnement",
  "EN": "actual mutation of the environment",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "3",
  "CANONICAL": [
    "hcaccaaaa"
  ],
  "_id": ObjectId("5681c64cb83eaf1ceef1fdb9")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gdaccaaaa"
  ],
  "CLASS": "4",
  "EN": "mutation of the objective environment",
  "FR": "mutation de l'environnement objectif",
  "IEML": "T:O:.we.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("5681c686b83eaf1ceef1fdc0")
});
db.getCollection("terms").insert({
  "IEML": "B:O:.we.-",
  "FR": "mutation de l'environnement social",
  "EN": "mutation of the social environment",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "fdaccaaaa"
  ],
  "_id": ObjectId("5681c6dbb83eaf1ceef1fdc7")
});
db.getCollection("terms").insert({
  "IEML": "S:O:.we.-",
  "FR": "mutation de l'environnement symbolique",
  "EN": "mutation of the symbolic environment",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "edaccaaaa"
  ],
  "_id": ObjectId("5681c725b83eaf1ceef1fdce")
});
db.getCollection("terms").insert({
  "IEML": "g.U:M:.-",
  "FR": "processus d'expression virtuel",
  "EN": "virtual process of expression",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "3",
  "CANONICAL": [
    "ecabhaaaa"
  ],
  "_id": ObjectId("56830fb6b83eaf1ceef1fdf8")
});
db.getCollection("terms").insert({
  "IEML": "g.O:S:.-",
  "FR": "processus d'expression abstrait",
  "EN": "abstract process of expression",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "ecadeaaaa"
  ],
  "_id": ObjectId("56830fffb83eaf1ceef1fe06")
});
db.getCollection("terms").insert({
  "IEML": "g.O:B:.-",
  "FR": "processus d'expression affective",
  "EN": "affective process of expression",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "ecadfaaaa"
  ],
  "_id": ObjectId("5683101ab83eaf1ceef1fe0d")
});
db.getCollection("terms").insert({
  "IEML": "g.O:T:.-",
  "FR": "processus d'expression concret",
  "EN": "concrete process of expression",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "ecadgaaaa"
  ],
  "_id": ObjectId("56831036b83eaf1ceef1fe14")
});
db.getCollection("terms").insert({
  "IEML": "c.U:M:.-",
  "FR": "processus personnel virtuel",
  "EN": "virtual personal process",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "3",
  "CANONICAL": [
    "fcabhaaaa"
  ],
  "_id": ObjectId("56831154b83eaf1ceef1fe3e")
});
db.getCollection("terms").insert({
  "IEML": "c.A:M:.-",
  "FR": "processus personnel actuel",
  "EN": "actual personal process",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "3",
  "CANONICAL": [
    "fcachaaaa"
  ],
  "_id": ObjectId("56831179b83eaf1ceef1fe45")
});
db.getCollection("terms").insert({
  "IEML": "c.O:S:.-",
  "FR": "processus personnel abstrait",
  "EN": "abstract personal process",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "fcadeaaaa"
  ],
  "_id": ObjectId("5683119fb83eaf1ceef1fe4c")
});
db.getCollection("terms").insert({
  "IEML": "c.O:B:.-",
  "FR": "processus personnel affectif",
  "EN": "affective personal process",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "fcadfaaaa"
  ],
  "_id": ObjectId("568311b9b83eaf1ceef1fe53")
});
db.getCollection("terms").insert({
  "IEML": "c.O:T:.-",
  "FR": "processus personnel concret",
  "EN": "concrete personal process",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "fcadgaaaa"
  ],
  "_id": ObjectId("568311d1b83eaf1ceef1fe5a")
});
db.getCollection("terms").insert({
  "IEML": "p.U:M:.-",
  "FR": "cadre référentiel virtuel",
  "EN": "virtual referential framework",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "3",
  "CANONICAL": [
    "gbabhaaaa"
  ],
  "_id": ObjectId("56831216b83eaf1ceef1fe61")
});
db.getCollection("terms").insert({
  "IEML": "p.A:M:.-",
  "FR": "cadre référentiel actuel",
  "EN": "actual referential framework",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "3",
  "CANONICAL": [
    "gbachaaaa"
  ],
  "_id": ObjectId("56831233b83eaf1ceef1fe68")
});
db.getCollection("terms").insert({
  "IEML": "p.O:S:.-",
  "FR": "cadre référentiel abstrait",
  "EN": "abstract referential framwork",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "gbadeaaaa"
  ],
  "_id": ObjectId("56831262b83eaf1ceef1fe6f")
});
db.getCollection("terms").insert({
  "IEML": "p.O:B:.-",
  "FR": "cadre référentiel affectif",
  "EN": "affective referential framework",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "gbadfaaaa"
  ],
  "_id": ObjectId("5683127fb83eaf1ceef1fe76")
});
db.getCollection("terms").insert({
  "IEML": "p.O:T:.-",
  "FR": "cadre référentiel concret",
  "EN": "concrete referential framework",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "gbadgaaaa"
  ],
  "_id": ObjectId("56831297b83eaf1ceef1fe7d")
});
db.getCollection("terms").insert({
  "IEML": "x.U:M:.-",
  "FR": "processus matériel virtuel",
  "EN": "virtual material process",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "3",
  "CANONICAL": [
    "gcabhaaaa"
  ],
  "_id": ObjectId("568312dcb83eaf1ceef1fe84")
});
db.getCollection("terms").insert({
  "IEML": "x.A:M:.-",
  "FR": "processus matériel actuel",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "3",
  "CANONICAL": [
    "gcachaaaa"
  ],
  "_id": ObjectId("568312fab83eaf1ceef1fe8b")
});
db.getCollection("terms").insert({
  "IEML": "x.O:S:.-",
  "FR": "processus matériel abstrait",
  "EN": "abstract material process",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "gcadeaaaa"
  ],
  "_id": ObjectId("56831335b83eaf1ceef1fe92")
});
db.getCollection("terms").insert({
  "IEML": "x.O:B:.-",
  "FR": "processus matériel affectif",
  "EN": "affective material process",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "gcadfaaaa"
  ],
  "_id": ObjectId("5683135cb83eaf1ceef1fe99")
});
db.getCollection("terms").insert({
  "IEML": "x.O:T:.-",
  "FR": "processus matériel concret",
  "EN": "concrete material process",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "gcadgaaaa"
  ],
  "_id": ObjectId("5683137eb83eaf1ceef1fea0")
});
db.getCollection("terms").insert({
  "IEML": "S:O:.y.-",
  "FR": "conditions intellectuelles du savoir",
  "EN": "intellectual conditions of knowledge",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "edabeaaaa"
  ],
  "_id": ObjectId("568313dfb83eaf1ceef1fea7")
});
db.getCollection("terms").insert({
  "IEML": "B:O:.y.-",
  "FR": "conditions sociales du savoir",
  "EN": "social conditions of knowledge",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "fdabeaaaa"
  ],
  "_id": ObjectId("568313feb83eaf1ceef1feae")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gdabeaaaa"
  ],
  "CLASS": "4",
  "EN": "empirical conditions of knowledge",
  "FR": "conditions empiriques du savoir",
  "IEML": "T:O:.y.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("5683141cb83eaf1ceef1feb5")
});
db.getCollection("terms").insert({
  "IEML": "M:U:.y.-",
  "FR": "conditions virtuelles du savoir",
  "EN": "virtual conditions of knowledge",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "3",
  "CANONICAL": [
    "hbabeaaaa"
  ],
  "_id": ObjectId("56840e4bb83eaf1ceef1febc")
});
db.getCollection("terms").insert({
  "IEML": "M:A:.y.-",
  "FR": "conditions actuelles du savoir",
  "EN": "actual conditions of knowledge",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "3",
  "CANONICAL": [
    "hcabeaaaa"
  ],
  "_id": ObjectId("56840e69b83eaf1ceef1fec3")
});
db.getCollection("terms").insert({
  "IEML": "S:O:.o.-",
  "FR": "conditions inconscientes du désir",
  "EN": "unconscious conditions of desire",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "edabfaaaa"
  ],
  "_id": ObjectId("56840f19b83eaf1ceef1feca")
});
db.getCollection("terms").insert({
  "IEML": "B:O:.o.-",
  "FR": "conditions énergétiques du désir",
  "EN": "energetic conditions of desire",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "fdabfaaaa"
  ],
  "_id": ObjectId("56840f48b83eaf1ceef1fed1")
});
db.getCollection("terms").insert({
  "IEML": "T:O:.o.-",
  "FR": "conditions d'accomplissement du désir",
  "EN": "conditions of desire fulfillment",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "gdabfaaaa"
  ],
  "_id": ObjectId("56840fdab83eaf1ceef1fed8")
});
db.getCollection("terms").insert({
  "IEML": "M:U:.o.-",
  "FR": "conditions virtuelles du désir",
  "EN": "virtual conditions of desire",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "3",
  "CANONICAL": [
    "hbabfaaaa"
  ],
  "_id": ObjectId("56840fffb83eaf1ceef1fedf")
});
db.getCollection("terms").insert({
  "IEML": "M:A:.o.-",
  "FR": "conditions actuelles du désir",
  "EN": "actual conditions of desire",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "3",
  "CANONICAL": [
    "hcabfaaaa"
  ],
  "_id": ObjectId("5684101bb83eaf1ceef1fee6")
});
db.getCollection("terms").insert({
  "IEML": "M:U:.e.-",
  "FR": "conditions virtuelles du pouvoir",
  "EN": "virtual conditions of power",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "3",
  "CANONICAL": [
    "hbabgaaaa"
  ],
  "_id": ObjectId("5684107fb83eaf1ceef1feed")
});
db.getCollection("terms").insert({
  "IEML": "M:A:.e.-",
  "FR": "conditions actuelles du pouvoir",
  "EN": "actual conditions of power",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "3",
  "CANONICAL": [
    "hcabgaaaa"
  ],
  "_id": ObjectId("56841098b83eaf1ceef1fef4")
});
db.getCollection("terms").insert({
  "IEML": "T:O:.e.-",
  "FR": "conditions concrètes du pouvoir",
  "EN": "concrete conditions of power",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "gdabgaaaa"
  ],
  "_id": ObjectId("568410e6b83eaf1ceef1fefb")
});
db.getCollection("terms").insert({
  "IEML": "B:O:.e.-",
  "FR": "conditions énergétique du pouvoir",
  "EN": "energetic conditions of power",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "fdabgaaaa"
  ],
  "_id": ObjectId("56841134b83eaf1ceef1ff02")
});
db.getCollection("terms").insert({
  "IEML": "S:O:.e.-",
  "FR": "conditions du pouvoir dans la communication",
  "EN": "conditions of power in the communication",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "edabgaaaa"
  ],
  "_id": ObjectId("568411b6b83eaf1ceef1ff09")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "gdaceaaaa"
  ],
  "CLASS": "4",
  "EN": "concrete conditions of the enunciation",
  "FR": "conditions concrètes de l'énonciation",
  "IEML": "T:O:.u.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("5684122eb83eaf1ceef1ff10")
});
db.getCollection("terms").insert({
  "IEML": "S:O:.u.-",
  "FR": "conditions idéales de l'énonciation",
  "EN": "ideal conditions of the enunciation",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "edaceaaaa"
  ],
  "_id": ObjectId("56841271b83eaf1ceef1ff17")
});
db.getCollection("terms").insert({
  "IEML": "M:U:.u.-",
  "FR": "conditions virtuelles de l'énonciation",
  "EN": "virtual conditions of the enunciation",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "3",
  "CANONICAL": [
    "hbaceaaaa"
  ],
  "_id": ObjectId("568412b9b83eaf1ceef1ff1e")
});
db.getCollection("terms").insert({
  "IEML": "M:A:.u.-",
  "FR": "conditions actuelles de l'énonciation",
  "EN": "actual conditions of the enunciation",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "3",
  "CANONICAL": [
    "hcaceaaaa"
  ],
  "_id": ObjectId("568412f7b83eaf1ceef1ff25")
});
db.getCollection("terms").insert({
  "IEML": "B:O:.u.-",
  "FR": "contenu de l'énonciation",
  "EN": "enunciation content",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "fdaceaaaa"
  ],
  "_id": ObjectId("568413deb83eaf1ceef1ff2c")
});
db.getCollection("terms").insert({
  "IEML": "S:O:.a.-",
  "FR": "conditions communicationnelles de l'intégration",
  "EN": "conditions of the integration in communication",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "edacfaaaa"
  ],
  "_id": ObjectId("568414ccb83eaf1ceef1ff33")
});
db.getCollection("terms").insert({
  "IEML": "B:O:.a.-",
  "FR": "conditions affectives de l'intégration",
  "EN": "affective conditions of the integration",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "fdacfaaaa"
  ],
  "_id": ObjectId("568414f2b83eaf1ceef1ff3a")
});
db.getCollection("terms").insert({
  "IEML": "T:O:.a.-",
  "FR": "conditions concrètes de l'intégration",
  "EN": "concrete conditions of the integration",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "gdacfaaaa"
  ],
  "_id": ObjectId("56841545b83eaf1ceef1ff41")
});
db.getCollection("terms").insert({
  "IEML": "M:U:.a.-",
  "FR": "conditions virtuelles de l'intégration",
  "EN": "virtual conditions of the integration",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "3",
  "CANONICAL": [
    "hbacfaaaa"
  ],
  "_id": ObjectId("5684156db83eaf1ceef1ff48")
});
db.getCollection("terms").insert({
  "IEML": "M:A:.a.-",
  "FR": "conditions actuelles de l'intégration",
  "EN": "actual conditions of the integration",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "3",
  "CANONICAL": [
    "hcacfaaaa"
  ],
  "_id": ObjectId("5684158cb83eaf1ceef1ff4f")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "edacgaaaa"
  ],
  "CLASS": "4",
  "EN": "intellectual conditions of the efficiency",
  "FR": "conditions intellectuelles de l'efficacité",
  "IEML": "S:O:.i.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "2",
  "_id": ObjectId("56841600b83eaf1ceef1ff56")
});
db.getCollection("terms").insert({
  "IEML": "B:O:.i.-",
  "FR": "conditions affectives de l'efficacité",
  "EN": "affective conditions of the efficiency",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "fdacgaaaa"
  ],
  "_id": ObjectId("56841627b83eaf1ceef1ff5d")
});
db.getCollection("terms").insert({
  "IEML": "T:O:.i.-",
  "FR": "conditions concrètes de l'efficacité",
  "EN": "concrete conditions of the efficiency",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "2",
  "CANONICAL": [
    "gdacgaaaa"
  ],
  "_id": ObjectId("5684164eb83eaf1ceef1ff64")
});
db.getCollection("terms").insert({
  "IEML": "M:U:.i.-",
  "FR": "conditions virtuelles de l'efficacité",
  "EN": "virtual conditions of the efficiency",
  "PARADIGM": "0",
  "LAYER": "2",
  "CLASS": "4",
  "TAILLE": "3",
  "CANONICAL": [
    "hbacgaaaa"
  ],
  "_id": ObjectId("5684167eb83eaf1ceef1ff6b")
});
db.getCollection("terms").insert({
  "CANONICAL": [
    "hcacgaaaa"
  ],
  "CLASS": "4",
  "EN": "actual conditions of the efficiency",
  "FR": "conditions actuelles de l'efficacité",
  "IEML": "M:A:.i.-",
  "LAYER": "2",
  "PARADIGM": "0",
  "TAILLE": "3",
  "_id": ObjectId("568416b9b83eaf1ceef1ff72")
});
